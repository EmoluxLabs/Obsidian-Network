/**
 * VALIDATOR — registration and bonding for consensus participation.
 *
 * A validator bonds exactly params.consensus.validatorBond OBS. Bonded OBS
 * is locked value: it leaves the spendable balance, and it is counted by the
 * supply invariant while bonded. Unbonding takes params.consensus.unbondingBlocks
 * blocks, after which the bond returns to the owner's balance.
 *
 * Bonded stake is the *only* role it plays here: it does not vote on consensus
 * outcomes, and no validator can mint, alter balances, or rewrite history. It
 * establishes who may propose blocks in rotation (see consensus/proposer.ts).
 */
import { type TxEnvelope, type ValidatorBody } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeValidatorBody(body: Uint8Array): ValidatorBody;
export declare function encodeValidatorBody(body: ValidatorBody): Uint8Array;
export declare function executeValidator(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * Per-block validator bookkeeping: jail validators that keep missing their slot
 * and release jails whose term has ended. Deterministic and height-driven — no
 * administrator, no dashboard action.
 *
 * The counter is a LEAKY one:
 *   - a slot the chain records as missed adds 1;
 *   - a block the validator itself produces subtracts 1 (floor 0);
 *   - more than `maxMissedSlotsPerWindow` net misses jails it.
 *
 * It used to subtract 1 on every block the validator was not named in. That can
 * never jail anyone in a set of three or more: a validator that is absent is
 * the round-0 proposer of only one block in n, so it earned +1 once and -1
 * for each of the other n-1 blocks and sat at zero for ever. Decay now has to
 * be earned by actually producing, so an absent validator's count only goes
 * one way.
 */
export declare function processValidatorBookkeeping(ctx: ExecutorContext, missedBy: string[]): void;
