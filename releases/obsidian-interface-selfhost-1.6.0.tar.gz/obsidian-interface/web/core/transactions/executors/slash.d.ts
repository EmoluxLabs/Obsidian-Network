/**
 * SLASH — the equivocation penalty, applied inside the state transition.
 *
 * WHY THIS IS A TRANSACTION
 *
 *   The penalty has to be identical on every honest node, so it cannot be an
 *   RPC action, a dashboard button or a node-local decision. A transaction is
 *   the protocol's existing machinery for "something happened at a height, in a
 *   canonical order, verified by everyone": the block carring it is validated by
 *   every node, the effect is committed in the state root, and a reorg removes
 *   it exactly the way it removes any other transaction.
 *
 * THE SUBMITTER CHOOSES NOTHING
 *
 *   Anyone may submit: an operator, a node, a wallet, a script. The submitter
 *   cannot name the offender (the evidence does), cannot name an amount (the
 *   consensus ratio over the validator's own bond does), cannot name a
 *   destination (the Mining Pool is fixed by consensus) and cannot make a
 *   second slash happen (the evidence id is recorded, and the registration
 *   closes). Paying for the transaction is the only thing they contribute.
 *
 *   The transaction carries no value and pays no gas: it moves no funds of its
 *   own, and pricing it would create a reason not to report equivocation. Its
 *   cost is block space, bounded by the ordinary transaction limits.
 */
import { type SlashBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeSlashBody(body: Uint8Array): SlashBody;
export declare function encodeSlashBody(body: SlashBody): Uint8Array;
export declare function executeSlash(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
