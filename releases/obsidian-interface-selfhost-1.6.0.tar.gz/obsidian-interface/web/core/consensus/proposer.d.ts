/**
 * Proposer selection and fork choice — the mechanical heart of Proof of Time.
 *
 * There is no hash-puzzle race, no nonce search and no competition to spend
 * computation. Authority to produce a block is a function of TIME and of the
 * validator schedule:
 *
 *   - the proposer of a height is the validator whose slot the protocol clock
 *     hands the turn to;
 *   - a block may only be produced once protocol time has advanced past its
 *     parent (median time past, plus PoT Difficulty — see src/consensus/time.ts);
 *   - the chain a node adopts is the one carrying the most verified state and
 *     the most verified time (PoT Weight, then height), never the one that
 *     burned the most computation.
 *
 * Any node with the chain can recompute every one of those decisions, and a
 * node that lies about time is rejected the same way a forged signature would be.
 *
 * PROPOSER SELECTION
 *   Deterministic round-robin over the active validator set, sorted by address,
 *   offset by the ROUND — how many slots have elapsed since the parent block:
 *       round(parent, block) = max(0, floor((block.ts - parent.ts) / targetBlockSeconds) - 1)
 *       proposer(height, round) = activeValidators[(height + round) mod validatorCount]
 *
 *   Round 0 is the common case and reduces to the plain `height mod count`
 *   rotation. The round exists so that a validator which does not show up costs
 *   the network one slot instead of the chain: once its slot has elapsed the
 *   turn passes to the next active validator. The rotation remains validator-
 *   only in every round; it never opens block production to an unbonded node.
 *   If every registered validator is offline the chain deliberately stops
 *   rather than trading safety for unauthenticated block production.
 *
 *   The round is derived from the parent timestamp and the block's own
 *   timestamp — both already committed to the header — so every node computes
 *   the same answer from the block alone, with no extra header field and no
 *   out-of-band round negotiation. A proposer cannot claim an arbitrary round:
 *   the timestamp rules in src/consensus/time.ts bound how far into the future
 *   a block may be dated (maxFutureDriftSeconds) and require it to exceed the
 *   median time past, so the reachable round range is small and verifiable.
 *
 *   There is no randomness to grind, no leader election race and no committee
 *   that can be bribed into silence beyond the round-robin schedule. Jailed
 *   validators are skipped by construction because they are not in the active
 *   set.
 *
 *   HONEST LIMIT. The schedule is a rule about WHEN a block may carry a given
 *   validator's name, enforced through timestamps; it is not a vote or a
 *   finality gadget. A block may be dated up to `maxFutureDriftSeconds` ahead of
 *   a node's clock, so a validator can claim a later round than real elapsed
 *   time supports — at most (drift / targetBlockSeconds) rounds ahead. It still
 *   cannot escape the bonded validator set. While NO validator is registered
 *   the network is in "genesis open" mode, where any node may propose; the first
 *   registered validator closes open mode for every round.
 *
 * FORK CHOICE
 *   The chain with the greatest PoT Weight wins, then the greatest height, then
 *   the lowest block hash (a fully deterministic tie-break, so two honest nodes
 *   holding the same candidates agree about the head). Every valid block adds
 *   exactly one weight unit. Transactions never buy fork-choice authority.
 */
import type { WorldState } from '../blockchain/state.js';
import type { Block } from '../protocol/types.js';
import { medianTimePast } from './time.js';
export { medianTimePast };
/**
 * How many proposer slots elapsed between a block and its parent.
 *
 * A block produced on schedule (one target interval after its parent) is round
 * 0. Each further whole interval of delay advances the round by one, handing
 * the turn to the next validator in the rotation. Derived purely from two
 * timestamps that are already committed to the headers, so it is identical on
 * every node that has the blocks.
 */
export declare function proposerRound(parentTimestamp: number, blockTimestamp: number): number;
/**
 * Address scheduled to propose at `height` in `round`, or null only when no
 * validator is registered (genesis-open mode).
 *
 * Rounds cycle through the active set. They never fall through to arbitrary
 * nodes: that old fallback let any unbonded key wait `validatorCount` slots (or
 * immediately future-date within the drift allowance) and bypass validator
 * admission entirely.
 */
export declare function scheduledProposer(state: WorldState, height: number, round?: number): string | null;
/**
 * Validators to be recorded as having missed their slot for a block.
 *
 * Exactly one validator can ever be named: the ROUND-0 proposer of the height,
 * and only when the block that was finally produced belongs to a later round
 * (the round-0 validator had its whole window and a block still did not come
 * from it). Naming only the first slot-holder is deliberate. Timestamps can be
 * nudged inside the drift window, so a rule that blamed every validator the
 * round skipped would let one future-dated block frame many of them at once;
 * one name per block bounds that to a single validator per block, which the
 * leaky counter in processValidatorBookkeeping then absorbs.
 *
 * Pure function of (parent state, height, parent timestamp, block timestamp,
 * producer), so every node computes the same list from the block alone.
 */
export declare function missedProposersFor(parentState: WorldState, height: number, parentTimestamp: number, blockTimestamp: number, producer: string): string[];
export interface ForkChoiceInput {
    height: number;
    cumulativePotWeight: bigint;
    hash: string;
}
/** Compare tips by PoT weight, height, then the lexicographically lowest block hash. */
export declare function compareTips(a: ForkChoiceInput, b: ForkChoiceInput): number;
export declare function tipOf(block: Block): ForkChoiceInput;
export declare function assertProposerAllowed(state: WorldState, block: Block, parentTimestamp: number): void;
export declare function isProposerAllowed(state: WorldState, producer: string, height: number, round?: number): boolean;
export interface TimestampCheck {
    ok: boolean;
    reason?: string;
    medianTimePast: number;
    /** Minimum timestamp the protocol would accept for this position. */
    minimumTimestamp?: number;
}
/**
 * Timestamp validity for a candidate block: Proof of Time, expressed as a rule.
 *
 *   timestamp >  median time past of the last `medianTimePastWindow` ancestors
 *   timestamp >= parent timestamp + PoT Difficulty spacing (seconds)
 *   timestamp <= this node's clock + maxFutureDriftSeconds
 *
 * The first two clauses are derived entirely from chain data, so every node
 * computes the same answer. The third is the only place a validating node's own
 * clock appears, and it can only reject a block that claims the future: a node
 * with a broken clock cannot make an old block acceptable, it can only fall
 * behind honest peers. That asymmetry is what stops "my device clock says it is
 * 3am" from ever mattering to consensus.
 *
 * Delegates to src/consensus/time.ts so the rule lives in exactly one place.
 */
export declare function checkBlockTimestamp(timestamp: number, ancestorTimestamps: number[], localTimeSeconds: number): TimestampCheck;
