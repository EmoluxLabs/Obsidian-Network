/**
 * Proposer selection and fork choice — the mechanical heart of Proof of Time.
 *
 * There is no hash-puzzle race, no nonce search and no competition to spend
 * computation. Authority to produce a block is a function of TIME and of the
 * validator schedule:
 *
 *   - the proposer of a height is the validator whose slot the protocol clock
 *     hands the turn to;
 *   - a block may only be produced once protocol time has advanced past its
 *     parent (median time past, plus PoT Difficulty — see src/consensus/time.ts);
 *   - the chain a node adopts is the one carrying the most verified state and
 *     the most verified time (PoT Weight, then height), never the one that
 *     burned the most computation.
 *
 * Any node with the chain can recompute every one of those decisions, and a
 * node that lies about time is rejected the same way a forged signature would be.
 *
 * PROPOSER SELECTION
 *   Deterministic round-robin over the active validator set, sorted by address,
 *   offset by the ROUND — how many slots have elapsed since the parent block:
 *       round(parent, block) = max(0, floor((block.ts - parent.ts) / targetBlockSeconds) - 1)
 *       proposer(height, round) = activeValidators[(height + round) mod validatorCount]
 *
 *   Round 0 is the common case and reduces to the plain `height mod count`
 *   rotation. The round exists so that a validator which does not show up costs
 *   the network one slot instead of the chain: once its slot has elapsed the
 *   turn passes to the next active validator. The rotation remains validator-
 *   only in every round; it never opens block production to an unbonded node.
 *   If every registered validator is offline the chain deliberately stops
 *   rather than trading safety for unauthenticated block production.
 *
 *   The round is derived from the parent timestamp and the block's own
 *   timestamp — both already committed to the header — so every node computes
 *   the same answer from the block alone, with no extra header field and no
 *   out-of-band round negotiation. A proposer cannot claim an arbitrary round:
 *   the timestamp rules in src/consensus/time.ts bound how far into the future
 *   a block may be dated (maxFutureDriftSeconds) and require it to exceed the
 *   median time past, so the reachable round range is small and verifiable.
 *
 *   There is no randomness to grind, no leader election race and no committee
 *   that can be bribed into silence beyond the round-robin schedule. Jailed
 *   validators are skipped by construction because they are not in the active
 *   set.
 *
 *   HONEST LIMIT. The schedule is a rule about WHEN a block may carry a given
 *   validator's name, enforced through timestamps; it is not a vote or a
 *   finality gadget. A block may be dated up to `maxFutureDriftSeconds` ahead of
 *   a node's clock, so a validator can claim a later round than real elapsed
 *   time supports — at most (drift / targetBlockSeconds) rounds ahead. It still
 *   cannot escape the bonded validator set. While NO validator is registered
 *   the network is in "genesis open" mode, where any node may propose; the first
 *   registered validator closes open mode for every round.
 *
 * FORK CHOICE
 *   The chain with the greatest PoT Weight wins, then the greatest height, then
 *   the lowest block hash (a fully deterministic tie-break, so two honest nodes
 *   holding the same candidates agree about the head). Every valid block adds
 *   exactly one weight unit. Transactions never buy fork-choice authority.
 */
import { blockHash } from '../blockchain/block.js';
import { CONSENSUS_PARAMS } from '../protocol/params.js';
import { medianTimePast, validateBlockTime } from './time.js';
export { medianTimePast };
/**
 * How many proposer slots elapsed between a block and its parent.
 *
 * A block produced on schedule (one target interval after its parent) is round
 * 0. Each further whole interval of delay advances the round by one, handing
 * the turn to the next validator in the rotation. Derived purely from two
 * timestamps that are already committed to the headers, so it is identical on
 * every node that has the blocks.
 */
export function proposerRound(parentTimestamp, blockTimestamp) {
    const elapsed = blockTimestamp - parentTimestamp;
    if (!Number.isFinite(elapsed) || elapsed <= 0)
        return 0;
    const slots = Math.floor(elapsed / CONSENSUS_PARAMS.block.targetBlockSeconds);
    return Math.max(0, slots - 1);
}
/**
 * Address scheduled to propose at `height` in `round`, or null only when no
 * validator is registered (genesis-open mode).
 *
 * Rounds cycle through the active set. They never fall through to arbitrary
 * nodes: that old fallback let any unbonded key wait `validatorCount` slots (or
 * immediately future-date within the drift allowance) and bypass validator
 * admission entirely.
 */
export function scheduledProposer(state, height, round = 0) {
    const active = state.activeValidators();
    if (active.length === 0)
        return null;
    const safeRound = Number.isSafeInteger(round) && round >= 0 ? round : 0;
    return active[(height + safeRound) % active.length];
}
/**
 * Validators to be recorded as having missed their slot for a block.
 *
 * Exactly one validator can ever be named: the ROUND-0 proposer of the height,
 * and only when the block that was finally produced belongs to a later round
 * (the round-0 validator had its whole window and a block still did not come
 * from it). Naming only the first slot-holder is deliberate. Timestamps can be
 * nudged inside the drift window, so a rule that blamed every validator the
 * round skipped would let one future-dated block frame many of them at once;
 * one name per block bounds that to a single validator per block, which the
 * leaky counter in processValidatorBookkeeping then absorbs.
 *
 * Pure function of (parent state, height, parent timestamp, block timestamp,
 * producer), so every node computes the same list from the block alone.
 */
export function missedProposersFor(parentState, height, parentTimestamp, blockTimestamp, producer) {
    if (proposerRound(parentTimestamp, blockTimestamp) === 0)
        return [];
    const first = scheduledProposer(parentState, height, 0);
    if (first === null || first === producer)
        return [];
    return [first];
}
/** Compare tips by PoT weight, height, then the lexicographically lowest block hash. */
export function compareTips(a, b) {
    if (a.hash === b.hash)
        return 0;
    if (a.cumulativePotWeight !== b.cumulativePotWeight)
        return a.cumulativePotWeight > b.cumulativePotWeight ? 1 : -1;
    if (a.height !== b.height)
        return a.height > b.height ? 1 : -1;
    return a.hash < b.hash ? 1 : -1;
}
export function tipOf(block) {
    return {
        height: block.header.height,
        cumulativePotWeight: block.header.cumulativePotWeight,
        hash: blockHash(block.header),
    };
}
export function assertProposerAllowed(state, block, parentTimestamp) {
    const round = proposerRound(parentTimestamp, block.header.timestamp);
    const scheduled = scheduledProposer(state, block.header.height, round);
    if (scheduled === null)
        return; // genesis-open mode only
    if (block.header.producer !== scheduled) {
        const error = new Error(`proposer for height ${block.header.height} round ${round} must be ${scheduled}, ` +
            `received ${block.header.producer}`);
        error.code = 'ERR_NOT_PRODUCER_TURN';
        throw error;
    }
}
export function isProposerAllowed(state, producer, height, round = 0) {
    const scheduled = scheduledProposer(state, height, round);
    return scheduled === null || scheduled === producer;
}
/**
 * Timestamp validity for a candidate block: Proof of Time, expressed as a rule.
 *
 *   timestamp >  median time past of the last `medianTimePastWindow` ancestors
 *   timestamp >= parent timestamp + PoT Difficulty spacing (seconds)
 *   timestamp <= this node's clock + maxFutureDriftSeconds
 *
 * The first two clauses are derived entirely from chain data, so every node
 * computes the same answer. The third is the only place a validating node's own
 * clock appears, and it can only reject a block that claims the future: a node
 * with a broken clock cannot make an old block acceptable, it can only fall
 * behind honest peers. That asymmetry is what stops "my device clock says it is
 * 3am" from ever mattering to consensus.
 *
 * Delegates to src/consensus/time.ts so the rule lives in exactly one place.
 */
export function checkBlockTimestamp(timestamp, ancestorTimestamps, localTimeSeconds) {
    const ancestors = ancestorTimestamps.map((value) => ({ timestamp: value }));
    const verdict = validateBlockTime({ timestamp }, ancestors, localTimeSeconds);
    if (verdict.ok) {
        return { ok: true, medianTimePast: verdict.medianTimePast, minimumTimestamp: verdict.minimumTimestamp };
    }
    return {
        ok: false,
        reason: verdict.reason,
        medianTimePast: verdict.medianTimePast,
        minimumTimestamp: verdict.minimumTimestamp,
    };
}
//# sourceMappingURL=proposer.js.map