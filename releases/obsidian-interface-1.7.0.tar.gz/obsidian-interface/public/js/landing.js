// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function rewardLine(schedule) {
  return `${obs(schedule.dailyRewardObs ?? schedule.dailyRewardSeals ?? schedule.rewardPerDayObs)} OBS`;
}
function rewardPerClaim(schedule) {
  return `${obs(schedule.claimRewardObs ?? schedule.claimRewardSeals ?? schedule.rewardPerClaimObs)} OBS`;
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  /** One page of the name registry. The node returns at most 500 records per call (default 200); `hasMore` says to ask again. */
  names(prefix = "", page = {}) {
    const q = [];
    if (prefix) q.push(`prefix=${encodeURIComponent(prefix)}`);
    if (page.limit !== void 0) q.push(`limit=${encodeURIComponent(String(page.limit))}`);
    if (page.offset !== void 0) q.push(`offset=${encodeURIComponent(String(page.offset))}`);
    return this.request(`/names${q.length ? `?${q.join("&")}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  /**
   * Register. The response is the ONLY time the recovery codes exist — they
   * are not stored in recoverable form and can never be shown again.
   */
  register(input) {
    return api("/api/auth/register", { method: "POST", body: JSON.stringify(input) });
  },
  signIn(input) {
    return api("/api/auth/login", { method: "POST", body: JSON.stringify(input) });
  },
  startMfa() {
    return api("/api/auth/mfa/setup", { method: "POST", body: "{}" });
  },
  confirmMfa(totp) {
    return api("/api/auth/mfa/confirm", { method: "POST", body: JSON.stringify({ totp }) });
  },
  recover(input) {
    return api("/api/auth/recover", { method: "POST", body: JSON.stringify(input) });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  /**
   * Ask the platform for the mining gate certificate the chain requires on a claim. The platform issues it only
   * for the wallet linked to THIS signed-in, second-factor-confirmed account; it expires in minutes.
   */
  async miningCertificate(address, claimId) {
    const { gate } = await api("/api/mining/certificate", {
      method: "POST",
      body: JSON.stringify({ address, claimId })
    });
    return gate;
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  /**
   * Link `address` to the account — once, for good. The server issues a challenge; `sign` signs it
   * on this device (the key never leaves); the server checks the signature and links. Linking the
   * wallet the account already has is a no-op that succeeds.
   */
  async linkWallet(address, sign) {
    const challenge = await api(
      "/api/wallet/link/challenge",
      { method: "POST", body: JSON.stringify({ address }) }
    );
    if (challenge.alreadyLinked) return { linked: true, address, account: challenge.account };
    if (!challenge.message) throw new Error("the interface sent no link challenge");
    const proof = sign(challenge.message);
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address, ...proof }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const isLanding = options.current === "landing";
  const nav = el(
    "nav",
    { class: "nav", id: "site-nav", "aria-label": "All products" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const navToggle = el(
    "button",
    {
      type: "button",
      class: "nav-toggle",
      id: "nav-toggle",
      "aria-expanded": "false",
      "aria-controls": "site-nav",
      "aria-label": "Open menu"
    },
    el("span", { class: "nav-toggle-bars", "aria-hidden": "true" }),
    el("span", { class: "nav-toggle-text" }, "Menu")
  );
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      el("div", { class: "masthead-actions" }, accountSlot, navToggle)
    ),
    banner,
    nav
  );
  header.classList.add("masthead");
  if (isLanding) header.classList.add("landing");
  const setOpen = (open) => {
    header.classList.toggle("menu-open", open);
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  navToggle.addEventListener("click", () => setOpen(!header.classList.contains("menu-open")));
  nav.addEventListener("click", (event) => {
    if (event.target.closest("a")) setOpen(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && header.classList.contains("menu-open")) {
      setOpen(false);
      navToggle.focus();
    }
  });
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/pages/landing.ts
var client = new ObsidianClient();
function cta(href, label, kind) {
  return el("a", { class: `cta cta-${kind}`, href }, label);
}
var hero = el(
  "section",
  { class: "hero" },
  el("p", { class: "eyebrow" }, "Proof of Time \xB7 21,000,000 OBS hard cap \xB7 no company in the middle"),
  el("h2", {}, "A public ledger you can verify yourself,", el("br"), "and the products built on it."),
  el(
    "p",
    { class: "lede" },
    "Obsidian Network is an independent blockchain. Mining, payments, .obs names and validator bonds live inside the chain \u2014 not in a database owned by a company. Any node can be deleted; the chain survives, because consensus does not live in a server."
  ),
  el(
    "div",
    { class: "cta-row" },
    cta("/mine/", "Start Mining", "primary"),
    cta("/wallet/", "Create Wallet", "secondary"),
    cta("/explorer/", "Explorer", "quiet")
  ),
  el(
    "div",
    { class: "cta-row cta-row-app" },
    // `latest/download/<asset>` always resolves to that asset in the newest
    // release, so this link stays valid as new versions ship. It is a real file
    // on a real release: OBSIDIAN-debug.apk, published by the Android workflow
    // from a commit whose tests, lint and assembly were green.
    el(
      "a",
      {
        class: "cta cta-secondary",
        href: "https://github.com/EmoluxLabs/Obsidian-Network/releases/latest/download/OBSIDIAN-debug.apk",
        rel: "noopener"
      },
      "Download Obsidian App"
    ),
    el(
      "span",
      { class: "cta-note" },
      "Android \xB7 debug-signed APK. The release build ships unsigned until a signing key is configured."
    )
  ),
  el(
    "p",
    { class: "fineprint" },
    "Wallets are generated in your browser and never leave it. Mining pays 0.001 OBS a day at launch, never more than 21,000,000 OBS in total, and withdrawals need no KYC and no third-party token."
  )
);
var stats = el("section", { class: "stat-grid", id: "stats" }, spinner("reading the chain\u2026"));
var pillars = el(
  "section",
  { class: "pillars" },
  el(
    "article",
    { class: "pillar" },
    el("h3", {}, "Proof of Time, not Proof of Work"),
    el(
      "p",
      {},
      "Obsidian secures itself with verifiable time, not with a computational race. Blocks are produced on a validator schedule and accepted only when protocol time has genuinely advanced, so nobody buys authority with electricity. Mining is a claim every four hours, six a day, on a fixed schedule that falls with adoption and never below 0.0002 OBS a day \u2014 and eligibility comes from block timestamps, never from your device clock."
    )
  ),
  el(
    "article",
    { class: "pillar" },
    el("h3", {}, "Money that stays in the chain"),
    el(
      "p",
      {},
      "Every payment carries a 0.02% gas fee capped at 0.01 OBS, and every seal of it returns to the Mining Pool. Nothing is minted by an admin: the only issuance paths are the one-time genesis allocation and mining rewards."
    )
  ),
  el(
    "article",
    { class: "pillar" },
    el("h3", {}, "Products on real state"),
    el(
      "p",
      {},
      "Names, balances, mining claims and validator bonds are chain state with a Merkle root every node recomputes. Their prices are consensus parameters denominated in OBS, so the protocol needs no exchange rate and no price source to function. The interface here is a window; it can be replaced by any node operator."
    )
  ),
  el(
    "article",
    { class: "pillar" },
    el("h3", {}, "The nodes get paid"),
    el(
      "p",
      {},
      "90% of ONS revenue goes to independent node runners and 10% to the protocol treasury \u2014 split inside the state transition, not by an invoice. A node earns from uptime, participation and reliability that other nodes attested; it cannot report its own numbers."
    )
  ),
  el(
    "article",
    { class: "pillar" },
    el("h3", {}, "No custody, no gatekeeping"),
    el(
      "p",
      {},
      "Nobody \u2014 including the people who wrote this page \u2014 can move your OBS. Keys are created in your browser, signed in your browser, and never transmitted. There is no admin mint, no $5 activation and no inside exchange."
    )
  )
);
var how = el(
  "section",
  { class: "how" },
  el("h3", {}, "What happens when you press a button"),
  el(
    "ol",
    {},
    el("li", {}, el("strong", {}, "Your browser signs."), " The private key is used locally to sign canonical bytes \u2014 the same encoder the node runs, shipped as the same module."),
    el("li", {}, el("strong", {}, "A node checks."), " The signed transaction is handed to an Obsidian Core node, which validates signatures, nonce, gas, balances and protocol rules."),
    el("li", {}, el("strong", {}, "The network decides."), " If the rules pass, miners include it in a block. If they do not, no amount of website design can override it.")
  )
);
var chains = el("section", { class: "chains", id: "network" }, spinner());
layout({
  current: "landing",
  title: "Obsidian Network",
  tagline: "A decentralised ledger and the apps that run on it \u2014 verified, not promised.",
  children: [hero, stats, pillars, how, chains]
});
void (async () => {
  try {
    const [status, schedule, params] = await Promise.all([
      client.status(),
      client.miningSchedule().catch(() => void 0),
      client.params().catch(() => void 0)
    ]);
    stats.replaceChildren(
      stat("Blocks", status.height.toLocaleString()),
      stat("Supply", `${obs(status.supplyObs)} OBS`, `of 21,000,000`),
      stat("Peers", String(status.peers)),
      stat("Reward / day", schedule ? rewardLine(schedule) : "\u2014", schedule ? `${rewardPerClaim(schedule)} per claim` : ""),
      stat("Active miners", String(schedule?.activeMiners ?? 0)),
      // Every protocol fee is denominated in OBS, so there is nothing on this
      // page that depends on a price feed. What a market pays for OBS is a
      // market's business, not the chain's.
      stat("Name registration", `${params?.ons.registrationFeeObs ?? "\u2014"} OBS`, "a consensus parameter, not a conversion")
    );
    chains.replaceChildren(
      el("h3", {}, "Networks"),
      el(
        "p",
        { class: "muted" },
        `Four independent chains ship with the node software. This deployment reads ${status.networkId} (chain id ${status.chainId}), genesis ${status.genesisId.slice(0, 16)}\u2026`
      ),
      el(
        "div",
        { class: "chain-list" },
        ...[
          ["Mainnet", 7777, "obs", "8630/8631"],
          ["Testnet", 7778, "tobs", "18630/18631"],
          ["Staging", 7779, "sobs", "28630/28631"],
          ["Devnet", 7780, "dobs", "38630/38631"]
        ].map(
          ([name, id, hrp, ports]) => el(
            "div",
            { class: "chain-card" },
            el("strong", {}, String(name)),
            el("span", {}, `chain ${id}`),
            el("span", { class: "mono" }, `${hrp}1\u2026`),
            el("span", { class: "muted" }, `rpc/p2p ${ports}`)
          )
        )
      ),
      el(
        "p",
        { class: "fineprint" },
        badge("NO PRICE ORACLE", "ok"),
        " Every protocol fee \u2014 name registration and renewal, and the validator bond \u2014 is denominated in OBS and fixed by consensus. Nothing on this chain consults an external price source, so no feed can fail, stall or be manipulated into changing what anything costs. What OBS trades for elsewhere is a matter for those markets."
      )
    );
  } catch (error) {
    stats.replaceChildren(el("p", { class: "error" }, `Could not read the chain: ${error.message}`));
    chains.replaceChildren();
  }
})();
function stat(label, value, sub) {
  return el("div", { class: "stat" }, el("span", { class: "stat-label" }, label), el("strong", {}, value), sub ? el("span", { class: "stat-sub" }, sub) : null);
}
//# sourceMappingURL=landing.js.map
