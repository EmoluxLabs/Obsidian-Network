// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function duration(seconds) {
  if (seconds <= 0) return "now";
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds % 86400 / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  const secs = Math.floor(seconds % 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${secs}s`;
  return `${secs}s`;
}
function when(timestampSeconds) {
  if (!timestampSeconds) return "\u2014";
  return new Date(timestampSeconds * 1e3).toLocaleString();
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
function pct(value, digits = 2) {
  return `${value.toFixed(digits)}%`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
async function copy(value, label = "Copied") {
  try {
    await navigator.clipboard.writeText(value);
    toast(`${label} to clipboard`, "success");
  } catch {
    toast("Clipboard access was blocked by the browser", "error");
  }
}
function copyButton(value, label = "Copy") {
  const button = el("button", { class: "ghost small", type: "button" }, label);
  button.addEventListener("click", () => void copy(typeof value === "function" ? value() : value));
  return button;
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  /** One page of the name registry. The node returns at most 500 records per call (default 200); `hasMore` says to ask again. */
  names(prefix = "", page = {}) {
    const q = [];
    if (prefix) q.push(`prefix=${encodeURIComponent(prefix)}`);
    if (page.limit !== void 0) q.push(`limit=${encodeURIComponent(String(page.limit))}`);
    if (page.offset !== void 0) q.push(`offset=${encodeURIComponent(String(page.offset))}`);
    return this.request(`/names${q.length ? `?${q.join("&")}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  /**
   * Register. The response is the ONLY time the recovery codes exist — they
   * are not stored in recoverable form and can never be shown again.
   */
  register(input) {
    return api("/api/auth/register", { method: "POST", body: JSON.stringify(input) });
  },
  signIn(input) {
    return api("/api/auth/login", { method: "POST", body: JSON.stringify(input) });
  },
  startMfa() {
    return api("/api/auth/mfa/setup", { method: "POST", body: "{}" });
  },
  confirmMfa(totp) {
    return api("/api/auth/mfa/confirm", { method: "POST", body: JSON.stringify({ totp }) });
  },
  recover(input) {
    return api("/api/auth/recover", { method: "POST", body: JSON.stringify(input) });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  /**
   * Ask the platform for the mining gate certificate the chain requires on a claim. The platform issues it only
   * for the wallet linked to THIS signed-in, second-factor-confirmed account; it expires in minutes.
   */
  async miningCertificate(address, claimId) {
    const { gate } = await api("/api/mining/certificate", {
      method: "POST",
      body: JSON.stringify({ address, claimId })
    });
    return gate;
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  /**
   * Link `address` to the account — once, for good. The server issues a challenge; `sign` signs it
   * on this device (the key never leaves); the server checks the signature and links. Linking the
   * wallet the account already has is a no-op that succeeds.
   */
  async linkWallet(address, sign) {
    const challenge = await api(
      "/api/wallet/link/challenge",
      { method: "POST", body: JSON.stringify({ address }) }
    );
    if (challenge.alreadyLinked) return { linked: true, address, account: challenge.account };
    if (!challenge.message) throw new Error("the interface sent no link challenge");
    const proof = sign(challenge.message);
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address, ...proof }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const isLanding = options.current === "landing";
  const nav = el(
    "nav",
    { class: "nav", id: "site-nav", "aria-label": "All products" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const navToggle = el(
    "button",
    {
      type: "button",
      class: "nav-toggle",
      id: "nav-toggle",
      "aria-expanded": "false",
      "aria-controls": "site-nav",
      "aria-label": "Open menu"
    },
    el("span", { class: "nav-toggle-bars", "aria-hidden": "true" }),
    el("span", { class: "nav-toggle-text" }, "Menu")
  );
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      el("div", { class: "masthead-actions" }, accountSlot, navToggle)
    ),
    banner,
    nav
  );
  header.classList.add("masthead");
  if (isLanding) header.classList.add("landing");
  const setOpen = (open) => {
    header.classList.toggle("menu-open", open);
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  navToggle.addEventListener("click", () => setOpen(!header.classList.contains("menu-open")));
  nav.addEventListener("click", (event) => {
    if (event.target.closest("a")) setOpen(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && header.classList.contains("menu-open")) {
      setOpen(false);
      navToggle.focus();
    }
  });
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/lib/revenue.ts
function revenueTimingRows(revenue) {
  const rows = [];
  const wallet = revenue.treasury?.wallet ?? revenue.accounts.treasuryWallet;
  rows.push([
    "Treasury wallet",
    wallet ? el("span", {}, el("span", { class: "mono", id: "treasury-wallet" }, wallet), " ", copyButton(wallet, "Copy address")) : "not designated yet \u2014 the first valid mining claim designates it"
  ]);
  if (revenue.treasury) {
    rows.push(["Treasury share credited so far", `${obs(revenue.split.treasuryCreditedObs)} OBS \u2014 credited in the same block as each ONS fee once a treasury is designated`]);
    rows.push(["Treasury share still owed", `${obs(revenue.split.treasuryUnclaimedObs)} OBS \u2014 held as an explicit protocol obligation until a treasury wallet exists`]);
  }
  const timing = revenue.timing;
  if (!timing) {
    rows.push(["When it is paid", "this node does not report a payment schedule"]);
    return rows;
  }
  rows.push([
    `Treasury share (${pct(timing.treasuryShare.bps / 100, 0)})`,
    `${timing.treasuryShare.paid}.`
  ]);
  const nodes = timing.nodeRunnerShare;
  rows.push([
    `Node-runner share (${pct(nodes.bps / 100, 0)})`,
    `Held in the Node Runner Reward Pool and paid ${nodes.paid} \u2014 every ${duration(nodes.periodSeconds)} \u2014 to registered nodes in proportion to the score their recorded evidence earned.`
  ]);
  rows.push(["Next node-runner payout", `${when(nodes.nextSettlementAt)} \u2014 in ${duration(nodes.secondsUntilNextSettlement)}`]);
  rows.push(["Waiting in the pool", `${obs(nodes.poolBalanceObs)} OBS`]);
  rows.push([
    "Registered node runners",
    nodes.carriedWhenNoNodes ? el("span", {}, "0 ", badge("pool is carried forward", "warn"), " ", nodes.note) : `${nodes.registeredNodes} \u2014 ${nodes.note}`
  ]);
  return rows;
}

// web/src/pages/node.ts
var client = new ObsidianClient();
var economics = el("section", { class: "card" }, spinner("reading protocol revenue\u2026"));
var registry = el("section", { class: "card" }, spinner("reading the node registry\u2026"));
var settlements = el("section", { class: "card" }, spinner("reading settled reward periods\u2026"));
var lookupResult = el("div", {});
var lookupInput = el("input", {
  type: "text",
  id: "node-id",
  placeholder: "20 bytes of hex, printed by your node at startup",
  autocomplete: "off",
  spellcheck: "false",
  class: "mono"
});
var lookupForm = el(
  "form",
  { class: "stack" },
  el("label", { for: "node-id" }, "Node ID"),
  lookupInput,
  el("button", { type: "submit", class: "primary" }, "Look up this node")
);
function pct2(bps) {
  return `${(bps / 100).toFixed(bps % 100 === 0 ? 0 : 2)}%`;
}
function scoreBar(label, bps, weightBps) {
  const width = Math.max(0, Math.min(100, bps / 100));
  return el(
    "div",
    { class: "score-row" },
    el("span", { class: "score-label" }, `${label} \xB7 ${pct2(weightBps)} of the score`),
    el("span", { class: "score-track" }, el("span", { class: "score-fill", style: `width:${width}%` })),
    el("span", { class: "mono score-value" }, pct2(bps))
  );
}
layout({
  current: "node",
  title: "Node runners",
  tagline: "90% of ONS revenue, paid to the nodes that actually carry the network.",
  children: [
    el(
      "section",
      { class: "notice" },
      el("strong", {}, "Nothing on this page is self-reported. "),
      "A node cannot tell the protocol it was online: its uptime is counted from heartbeats that other registered nodes attested, ",
      "its participation from blocks the chain shows it produced, and its reliability from faults independent peers corroborated. ",
      "Every node recomputes the same score from the same evidence, which is why the payout can be verified without trusting this website."
    ),
    economics,
    settlements,
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Look up a node"),
      el("p", { class: "muted" }, "Operators: paste your node id to see the evidence recorded about it in the current period."),
      lookupForm,
      lookupResult
    ),
    registry,
    el(
      "section",
      { class: "card" },
      el("h2", {}, "How to become a reward-eligible node"),
      el(
        "ol",
        { class: "steps" },
        el("li", {}, el("strong", {}, "Run Obsidian Core. "), "It generates a node identity key on first start and prints the node id."),
        el("li", {}, el("strong", {}, "Sync and peer. "), "A node that is behind or unreachable scores nothing, whatever it claims."),
        el(
          "li",
          {},
          el("strong", {}, "Register a reward wallet. "),
          "Your node signs a registration statement and the reward wallet signs the transaction. It moves no funds: ",
          "there is no registration deposit. That pair of signatures is what proves the operator controls both \u2014 ",
          "nobody can point your wallet at their node, or their wallet at yours."
        ),
        el("li", {}, el("strong", {}, "Stay up. "), "Heartbeat each period, attest the peers you can see, and keep in sync."),
        el(
          "li",
          {},
          el("strong", {}, "Get paid. "),
          "At the end of each period the protocol settles inside a block \u2014 no service, no operator and no administrator has to run anything."
        )
      ),
      el(
        "p",
        { class: "muted" },
        "Nothing is locked and nothing is charged to register. What keeps the registry honest is what a node cannot fake: ",
        "an identity bound to a wallet by two signatures, one node per wallet, attestations that must come from other nodes, ",
        "and a cap on any single node\u2019s share of a period. The protocol\u2019s only bond is the validator\u2019s 20,000 OBS."
      )
    )
  ]
});
function renderScore(status, scoring) {
  const score = status.score;
  return el(
    "div",
    { class: "stack" },
    el(
      "div",
      { class: "score-head" },
      el("span", { class: "mono big" }, pct2(score.scoreBps)),
      score.eligible ? badge("eligible this period", "ok") : badge("not eligible this period", "warn")
    ),
    scoreBar("Uptime", score.uptimeBps, scoring.scoreWeights.uptimeBps),
    scoreBar("Participation", score.participationBps, scoring.scoreWeights.participationBps),
    scoreBar("Reliability", score.reliabilityBps, scoring.scoreWeights.reliabilityBps),
    scoreBar("Responsiveness", score.responsivenessBps, scoring.scoreWeights.responsivenessBps),
    score.reasons.length ? el("ul", { class: "reasons" }, ...score.reasons.map((reason) => el("li", {}, reason))) : el("p", { class: "muted" }, "The protocol recorded no penalties or shortfalls for this node in this period.")
  );
}
async function lookup(nodeId) {
  lookupResult.replaceChildren(spinner("reading this node\u2019s evidence\u2026"));
  try {
    const [status, rewards] = await Promise.all([client.nodeStatus(nodeId), client.nodeRewards(10)]);
    const settled = status.settledRewards;
    lookupResult.replaceChildren(
      el("h3", {}, "Identity"),
      kv([
        ["Node ID", el("span", { class: "mono" }, status.nodeId)],
        ["Reward wallet", el("span", { class: "mono" }, status.rewardWallet)],
        ["Registered", status.registered ? badge("yes", "ok") : badge(`deregistered at height ${status.deregisteredAtHeight}`, "warn")],
        ["Registered at height", String(status.registeredAtHeight)],
        ["Endpoint hint", status.endpoint ?? "\u2014 (an endpoint is a hint, never the identity)"],
        ["Lifetime rewards", obs(status.lifetimeRewardObs)],
        [
          "Pending wallet change",
          status.pendingWalletChange ? `${status.pendingWalletChange.wallet} \u2014 effective in period ${status.pendingWalletChange.effectivePeriod}` : "none"
        ]
      ]),
      el("h3", {}, `Score \u2014 period ${status.currentPeriod}`),
      renderScore(status, rewards.scoring),
      el("h3", {}, "Evidence the network recorded"),
      kv([
        ["Heartbeats", `${status.evidence.heartbeats} of ${status.evidence.expectedHeartbeats} expected`],
        [
          "Independent attesters",
          status.evidence.attesters.length ? el("span", { class: "mono" }, status.evidence.attesters.join(", ")) : "none yet \u2014 uptime cannot be credited without another node observing this one"
        ],
        ["Blocks produced", String(status.evidence.blocksProduced)],
        ["Peers this node attested", String(status.evidence.attestationsMade)],
        ["Faults reported against it", `${status.evidence.faults} (reporters: ${status.evidence.faultReporters.length || "none"})`],
        ["Heartbeats out of sync", String(status.evidence.staleHeartbeats)],
        ["Last reported height", String(status.evidence.lastReportedHeight)]
      ]),
      el("h3", {}, "Settled rewards"),
      settled.length ? table(
        ["Period", "Height", "Score", "Share", "Paid", "Wallet"],
        settled.map((entry) => [
          String(entry.period),
          String(entry.atHeight),
          pct2(entry.scoreBps),
          pct2(entry.shareBps),
          obs(entry.amountObs),
          el("span", { class: "mono" }, entry.rewardWallet)
        ])
      ) : el("p", { class: "muted" }, "No period has settled for this node yet."),
      el("p", { class: "muted" }, status.note)
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    lookupResult.replaceChildren(
      el("p", { class: "error" }, `Could not read that node: ${message}`),
      el("p", { class: "muted" }, "A node id is 40 hex characters. Unregistered nodes have no record until they register a reward wallet.")
    );
  }
}
lookupForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const value = lookupInput.value.trim().toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(value)) {
    toast("A node id is exactly 40 hexadecimal characters.", "error");
    return;
  }
  void lookup(value);
});
void (async () => {
  try {
    const [revenue, rewards] = await Promise.all([client.revenue(), client.nodeRewards(10)]);
    economics.replaceChildren(
      el("h2", {}, "Where ONS revenue goes"),
      el("p", { class: "muted" }, "ONS registration and renewal fees are the protocol\u2019s only revenue source. Gas, issuance, the genesis allocation, mining rewards and validator bonds are not revenue and are never counted here."),
      el(
        "div",
        { class: "split-flow" },
        el("div", { class: "flow-node" }, el("span", { class: "flow-label" }, "ONS revenue"), el("span", { class: "mono big" }, obs(revenue.onsRevenueObs))),
        el(
          "div",
          { class: "flow-branches" },
          el(
            "div",
            { class: "flow-branch" },
            el("span", { class: "flow-share" }, pct2(revenue.split.nodePoolBps)),
            el("span", { class: "flow-label" }, "Node Runner Reward Pool"),
            el("span", { class: "mono" }, obs(revenue.split.nodeRunnerPoolObs))
          ),
          el(
            "div",
            { class: "flow-branch" },
            el("span", { class: "flow-share" }, pct2(revenue.split.treasuryBps)),
            el("span", { class: "flow-label" }, "Treasury"),
            el("span", { class: "mono" }, obs(revenue.split.treasuryObs)),
            el("span", { class: "muted fineprint" }, `${obs(revenue.split.treasuryCreditedObs)} credited \xB7 ${obs(revenue.split.treasuryUnclaimedObs)} unclaimed`)
          )
        )
      ),
      kv([
        ["Split adds back to the whole", revenue.split.sumsBack ? badge("verified", "ok") : badge("MISMATCH \u2014 do not trust this node", "bad")],
        ["Treasury share already credited", obs(revenue.split.treasuryCreditedObs)],
        ["Treasury share still owed", obs(revenue.split.treasuryUnclaimedObs)],
        ["Pool balance now", obs(revenue.accounts.nodeRunnerPoolObs)],
        ["Bonds held for operators", obs(revenue.accounts.nodeBondsObs)],
        ["Mining Pool (gas and mining inflows)", obs(revenue.accounts.miningPoolObs)]
      ]),
      el("h3", {}, "When each share is paid"),
      kv(revenueTimingRows(revenue)),
      el("h3", {}, "By source"),
      revenue.bySource.length ? table(["Source", "Lifetime"], revenue.bySource.map((entry) => [el("span", { class: "mono" }, entry.source), obs(entry.totalObs)])) : el("p", { class: "muted" }, "No ONS revenue has been recorded on this chain yet."),
      el("h3", {}, "What is deliberately NOT ONS revenue"),
      table(
        ["Flow", "Why it is excluded"],
        revenue.notOnsRevenue.map((entry) => [entry.kind, entry.because])
      ),
      el("p", { class: "muted" }, `${revenue.gas.note} Lifetime gas to the Mining Pool: ${revenue.gas.lifetimeObs} OBS.`)
    );
    settlements.replaceChildren(
      el("h2", {}, "Settled reward periods"),
      kv([
        ["Current period", String(rewards.pool.currentPeriod)],
        ["Last settled period", rewards.pool.lastSettledPeriod ? String(rewards.pool.lastSettledPeriod) : "none yet"],
        ["Period length", `${rewards.pool.periodSeconds / 3600} hours of protocol time`],
        ["Paid out so far", obs(rewards.pool.lifetimeDistributedObs)],
        ["Maximum one node may take from a period", pct2(rewards.scoring.maxNodeShareBps)],
        ["Minimum uptime to earn", pct2(rewards.scoring.minUptimeBps)],
        ["Independent attesters required", String(rewards.scoring.minAttesters)],
        ["Reward wallet changes take effect after", `${rewards.scoring.walletChangeDelayPeriods} period(s)`]
      ]),
      rewards.settlements.length ? el(
        "div",
        {},
        ...rewards.settlements.map(
          (settlement) => el(
            "div",
            { class: "settlement" },
            el("h3", {}, `Period ${settlement.period}`),
            kv([
              ["Settled at height", String(settlement.atHeight)],
              ["Pool at settlement", obs(settlement.poolObs)],
              ["Distributed", obs(settlement.distributedObs)],
              ["Carried to the next period", obs(settlement.carriedObs)],
              ["Nodes paid", `${settlement.eligibleNodes} of ${settlement.scoredNodes} scored`]
            ]),
            settlement.payouts.length ? table(
              ["Node", "Wallet", "Score", "Share", "Paid"],
              settlement.payouts.map((payout) => [
                el("span", { class: "mono" }, payout.nodeId),
                el("span", { class: "mono" }, payout.rewardWallet),
                pct2(payout.scoreBps),
                pct2(payout.shareBps),
                obs(payout.amountObs)
              ])
            ) : el("p", { class: "muted" }, "No node qualified in this period; the whole pool was carried forward.")
          )
        )
      ) : el("p", { class: "muted" }, "No reward period has closed on this chain yet. Settlement happens inside a block, with no operator involved.")
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    economics.replaceChildren(el("p", { class: "error" }, `Could not read the reward economics: ${message}`));
    settlements.replaceChildren(el("p", { class: "muted" }, "Settlement history is unavailable while the node is unreachable."));
  }
  try {
    const response = await client.nodeRegistry(100);
    registry.replaceChildren(
      el("h2", {}, `Registered nodes (${response.registeredNodes})`),
      response.nodes.length ? table(
        ["Node", "Reward wallet", "Heartbeats", "Attesters", "Blocks", "Attested", "Faults"],
        response.nodes.map((node) => [
          el("span", { class: "mono" }, node.nodeId),
          el("span", { class: "mono" }, node.rewardWallet),
          String(node.currentPeriod.heartbeats),
          String(node.currentPeriod.attesters),
          String(node.currentPeriod.blocksProduced),
          String(node.currentPeriod.attestationsMade),
          node.currentPeriod.faults > 0 ? badge(String(node.currentPeriod.faults), "warn") : "0"
        ])
      ) : el("p", { class: "muted" }, "No node runner has registered a reward wallet on this chain yet."),
      el("p", { class: "muted" }, response.note)
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    registry.replaceChildren(el("p", { class: "error" }, `Could not read the node registry: ${message}`));
  }
})();
//# sourceMappingURL=node.js.map
