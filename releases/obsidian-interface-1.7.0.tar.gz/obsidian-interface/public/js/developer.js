// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
async function copy(value, label = "Copied") {
  try {
    await navigator.clipboard.writeText(value);
    toast(`${label} to clipboard`, "success");
  } catch {
    toast("Clipboard access was blocked by the browser", "error");
  }
}
function copyButton(value, label = "Copy") {
  const button = el("button", { class: "ghost small", type: "button" }, label);
  button.addEventListener("click", () => void copy(typeof value === "function" ? value() : value));
  return button;
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  /** One page of the name registry. The node returns at most 500 records per call (default 200); `hasMore` says to ask again. */
  names(prefix = "", page = {}) {
    const q = [];
    if (prefix) q.push(`prefix=${encodeURIComponent(prefix)}`);
    if (page.limit !== void 0) q.push(`limit=${encodeURIComponent(String(page.limit))}`);
    if (page.offset !== void 0) q.push(`offset=${encodeURIComponent(String(page.offset))}`);
    return this.request(`/names${q.length ? `?${q.join("&")}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  /**
   * Register. The response is the ONLY time the recovery codes exist — they
   * are not stored in recoverable form and can never be shown again.
   */
  register(input) {
    return api("/api/auth/register", { method: "POST", body: JSON.stringify(input) });
  },
  signIn(input) {
    return api("/api/auth/login", { method: "POST", body: JSON.stringify(input) });
  },
  startMfa() {
    return api("/api/auth/mfa/setup", { method: "POST", body: "{}" });
  },
  confirmMfa(totp) {
    return api("/api/auth/mfa/confirm", { method: "POST", body: JSON.stringify({ totp }) });
  },
  recover(input) {
    return api("/api/auth/recover", { method: "POST", body: JSON.stringify(input) });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  /**
   * Ask the platform for the mining gate certificate the chain requires on a claim. The platform issues it only
   * for the wallet linked to THIS signed-in, second-factor-confirmed account; it expires in minutes.
   */
  async miningCertificate(address, claimId) {
    const { gate } = await api("/api/mining/certificate", {
      method: "POST",
      body: JSON.stringify({ address, claimId })
    });
    return gate;
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  /**
   * Link `address` to the account — once, for good. The server issues a challenge; `sign` signs it
   * on this device (the key never leaves); the server checks the signature and links. Linking the
   * wallet the account already has is a no-op that succeeds.
   */
  async linkWallet(address, sign) {
    const challenge = await api(
      "/api/wallet/link/challenge",
      { method: "POST", body: JSON.stringify({ address }) }
    );
    if (challenge.alreadyLinked) return { linked: true, address, account: challenge.account };
    if (!challenge.message) throw new Error("the interface sent no link challenge");
    const proof = sign(challenge.message);
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address, ...proof }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const isLanding = options.current === "landing";
  const nav = el(
    "nav",
    { class: "nav", id: "site-nav", "aria-label": "All products" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const navToggle = el(
    "button",
    {
      type: "button",
      class: "nav-toggle",
      id: "nav-toggle",
      "aria-expanded": "false",
      "aria-controls": "site-nav",
      "aria-label": "Open menu"
    },
    el("span", { class: "nav-toggle-bars", "aria-hidden": "true" }),
    el("span", { class: "nav-toggle-text" }, "Menu")
  );
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      el("div", { class: "masthead-actions" }, accountSlot, navToggle)
    ),
    banner,
    nav
  );
  header.classList.add("masthead");
  if (isLanding) header.classList.add("landing");
  const setOpen = (open) => {
    header.classList.toggle("menu-open", open);
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  navToggle.addEventListener("click", () => setOpen(!header.classList.contains("menu-open")));
  nav.addEventListener("click", (event) => {
    if (event.target.closest("a")) setOpen(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && header.classList.contains("menu-open")) {
      setOpen(false);
      navToggle.focus();
    }
  });
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/pages/developer.ts
var client = new ObsidianClient();
var live = el("section", { class: "card" }, spinner("asking the nodes\u2026"));
layout({
  current: "developer",
  title: "Developers",
  tagline: "Run a node, read the RPC, host the interface yourself. Everything here is verifiable on a laptop.",
  children: [
    live,
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Run a node"),
      el(
        "pre",
        { class: "code" },
        [
          "git clone https://github.com/EmoluxLabs/Obsidian-Network.git",
          "cd Obsidian-Network/obsidian-core",
          "npm ci && npm run build",
          'OBSIDIAN_KEYSTORE_PASSPHRASE="a-strong-passphrase" \\',
          "  node dist/index.js start --network devnet --port-offset 1000 \\",
          "    --mine --seeds obs1seed.example:38631"
        ].join("\n")
      ),
      el("div", { class: "row" }, copyButton(() => "node dist/index.js start --network devnet --port-offset 1000 --mine", "Copy start command")),
      el("p", { class: "fineprint" }, "A node reconstructs state from blocks and validates every transaction. It needs no account, no database server and no permission from anyone.")
    ),
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Read a node"),
      el("p", {}, "The RPC surface is plain JSON over HTTP. Reads are safe to cache; writes require a signed transaction."),
      table(
        ["Method", "Route", "Purpose"],
        [
          ["GET", el("span", { class: "mono" }, "/status"), "height, head, supply, peers, genesis allocation state"],
          ["GET", el("span", { class: "mono" }, "/mining/status?address=\u2026"), "eligibility, next claim id, reward per claim (protocol time)"],
          ["POST", el("span", { class: "mono" }, "/tx/submit"), "submit signed transaction bytes"],
          ["POST", el("span", { class: "mono" }, "/wallet/balance"), "balance of an address you already know"],
          ["GET", el("span", { class: "mono" }, "/blocks?limit="), "recent blocks"],
          ["GET", el("span", { class: "mono" }, "/names, /nodes/registry, /nodes/rewards"), "application and node-runner state straight from chain data"],
          ["GET", el("span", { class: "mono" }, "/audit/{decentralization,compliance}"), "mining distribution and the compliance report"]
        ]
      ),
      el("p", { class: "fineprint" }, "Error codes are protocol codes (`ERR_INSUFFICIENT_FUNDS`, `ERR_BAD_NONCE`, `ERR_MINING_TOO_SOON`, \u2026). They are stable, and a client should display them rather than guess.")
    ),
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Self-host this interface"),
      el(
        "pre",
        { class: "code" },
        [
          "git clone https://github.com/EmoluxLabs/Obsidian-Network.git",
          "cd Obsidian-Network/obsidian-interface",
          "npm ci && npm run build",
          'OBSIDIAN_NODE_URLS="http://127.0.0.1:8630,http://node2.example:8630" \\',
          "  node dist/server/index.js --port 8788"
        ].join("\n")
      ),
      el(
        "p",
        {},
        "The interface keeps no chain state of its own: it proxies reads to whichever node is healthiest and fails over automatically. It stores only the accounts it invited (no keys, ever) and serves the browser bundle it just built."
      ),
      el("p", { class: "fineprint" }, "Cloudflare is not part of consensus. If every CDN in the world went down, the nodes would keep producing blocks and any operator could serve this same bundle from a laptop.")
    ),
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Release integrity"),
      el("p", {}, "Each release in /releases is an archive with a SHA-256 checksum list. Verify before you run a binary that will hold keys:"),
      el("pre", { class: "code" }, "sha256sum --check SHA256SUMS   # verifies every published archive at once"),
      el("p", { class: "fineprint" }, "Nodes also compare core version, protocol version, network id and genesis id when they handshake, so a mismatched binary is rejected instead of corrupting your view of the chain.")
    ),
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Prices"),
      el(
        "p",
        {},
        "Every protocol fee is denominated in OBS and fixed by consensus: name registration and renewal, and the validator bond are entries in the parameter table, readable at GET /params and covered by the params hash. Nothing converts through an exchange rate, so no price feed can be stale, thin or manipulated into changing what anything costs, and a chain that has never seen a price submission prices every feature correctly."
      ),
      el(
        "p",
        { class: "fineprint" },
        "Nodes can still publish an OBS/USD observation on chain for reporting, and GET /oracle serves it, but no fee and no state transition reads it. What OBS trades for is a matter for the markets that trade it."
      )
    )
  ]
});
void (async () => {
  try {
    const [status, network, peers] = await Promise.all([client.status(), client.network(), client.peers().catch(() => void 0)]);
    live.replaceChildren(
      el("h2", {}, "This deployment"),
      kv([
        ["Node it is reading", "chosen by health and height among the configured nodes"],
        ["Network", `${status.networkId} \xB7 chain ${status.chainId} \xB7 hrp ${network.network?.addressHrp ?? "obs"}`],
        ["Genesis id", el("span", { class: "mono" }, status.genesisId)],
        ["Params hash", el("span", { class: "mono" }, status.paramsHash)],
        ["Protocol version", status.protocolVersion],
        ["Height", status.height.toLocaleString()],
        ["Peers", String(status.peers)],
        ["Peer detail", peers ? Object.keys(peers).join(", ") : "unavailable"]
      ]),
      el("div", { class: "row" }, badge("self-hostable", "ok"), badge("no key custody", "ok"), badge("no admin mint", "ok")),
      el("div", { class: "row" }, copyButton(() => window.location.origin, "Copy this interface URL"))
    );
  } catch (error) {
    live.replaceChildren(el("h2", {}, "This deployment"), el("p", { class: "error" }, error.message));
    toast(error.message, "error");
  }
})();
//# sourceMappingURL=developer.js.map
