/**
 * THE canonical validity predicate for a Proof-of-Time finality vote.
 *
 * A finality vote moves value: three of four signatures certify a block, that
 * certificate becomes the anchor fork choice may not cross, and two conflicting
 * votes are the evidence that confiscates half a validator's bond. One question
 * therefore has to have exactly one answer everywhere it is asked — in P2P
 * admission, in ordinary vote processing, in certificate construction and
 * verification, in crash recovery, in vote restoration after a restart, in
 * equivocation detection and in slash-evidence verification.
 *
 * Until 1.6.1 that question was answered in several places: a private method on
 * the chain manager for votes, a second, shorter list of checks inside the
 * certificate envelope validator, a third inside the evidence verifier and a
 * fourth inside the evidence detector on the P2P path. They agreed by luck. Any
 * rule added to one and not the others turned a message that one code path
 * accepted into a message another refused — and for slash evidence, "accepted by
 * the detector, refused by the verifier" is exactly the gap that lets a peer
 * relay an accusation no node can act on, or act on one no node would accept.
 *
 * So this file holds the whole rule set, and every caller supplies the same
 * `ConsensusEvidenceContext` of historical lookups. The predicate is pure: it
 * mutates nothing, it takes no clock of its own, and it never substitutes the
 * validating node's current state for the state that was in force when the vote
 * was cast. A lookup it cannot answer comes back null and is reported as such —
 * consensus paths fail closed, an admission path may treat it as "unknown".
 *
 * THE RULES, in the order they are applied (cheapest first, so a peer cannot
 * buy public-key work with garbage):
 *
 *   1. SHAPE. Bounded integers, exact field set, well-formed hashes and keys,
 *      target strictly above the anchor. No unknown fields: a vote carrying
 *      fields this build does not sign is refused rather than truncated.
 *   2. IDENTITY. protocolVersion, networkId, chainId, genesisId and paramsHash
 *      must all be this node's. A vote signed under other rules is not a vote
 *      here, which is what makes "same protocol id, different consensus rules"
 *      impossible to express as a finality message.
 *   3. LOCAL ANCHOR (opt-in). Admission of a new vote additionally requires it
 *      to extend THIS node's own finalized anchor.
 *   4. PARENT. The parent the vote names must exist, and the target height must
 *      be exactly one above it.
 *   5. COMMITTEE. The validator set hash must equal the hash of the committee
 *      that was in force at that parent, and the signer must be a member of it
 *      with the very key it registered under. This is the eligibility check, and
 *      it is a state lookup, so it runs BEFORE any signature arithmetic.
 *   6. SIGNATURE. Valid over the protocol's own finality domain, by the public
 *      key named in the vote, from the address named in the vote.
 *   7. TARGET. The block the vote points at must exist when the caller requires
 *      it, and must agree with the vote on height, parent hash and round. It
 *      must also have been produced by the address the schedule named.
 *   8. EXTENSION. Either the target is the ordinary next block above the anchor
 *      (height = anchor + 1 and parent = anchor hash), or — only while nothing
 *      is finalized yet and only for the bootstrap form the caller allows — the
 *      target sits above a stable genesis-committed committee.
 */
import type { ConsensusEvidenceContext, FinalityVote } from '../protocol/types.js';
/** Which of the caller-dependent rules apply to this particular question. */
export interface FinalityVoteRules {
    /**
     * Refuse a vote that does not extend this node's own finalized anchor. Vote
     * admission needs it; a vote carried inside evidence or a certificate is
     * judged on its own terms, because the offence may predate this node's anchor.
     */
    requireLocalAnchor?: {
        height: number;
        hash: string;
    } | false;
    /**
     * Refuse a vote whose target block this node does not hold. True for anything
     * that acts on the vote (certifying, finalizing). Evidence verification sets
     * it false: the offence is proven by the two signatures and the committee,
     * and a node that never saw the equivocated block must still be able to
     * recognise the offence — otherwise an attacker escapes slashing by hiding the
     * block from some peers.
     */
    requireTargetBlock?: boolean;
    /** Report an unavailable target as `unknown` rather than as a plain refusal. */
    allowUnknownTarget?: boolean;
    /** Accept the bootstrap form of a target (a pre-committee chain). */
    allowBootstrapTarget?: boolean;
}
export type FinalityVoteVerdict = {
    ok: true;
} | {
    ok: false;
    message: string;
    unknown?: boolean;
};
/**
 * Is `vote` a valid consensus vote for the chain `context` describes?
 *
 * Pure and deterministic: the same vote against the same context and rules
 * gives the same verdict on every node. It never mutates the context, never
 * reads a clock, and never falls back to current state when a historical lookup
 * comes back empty.
 */
export declare function validateCanonicalFinalityVote(vote: FinalityVote, context: ConsensusEvidenceContext, rules?: FinalityVoteRules): FinalityVoteVerdict;
