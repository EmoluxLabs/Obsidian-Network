/** Native equal-membership checkpoint finality for Proof of Time. */
import type { WorldState } from '../blockchain/state.js';
import type { EquivocationEvidence, FinalityCertificate, FinalityVote, ProposerEquivocationEvidence, VoteEquivocationEvidence } from '../protocol/types.js';
export interface FinalityValidator {
    address: string;
    publicKey: string;
}
/** Active registry records with the exact protocol bond, sorted and equally weighted. */
export declare function finalityValidators(state: WorldState): FinalityValidator[];
/**
 * Initial finality committee: exactly the keys committed by this network's
 * genesis, and only after every committed key has registered and bonded through
 * the ordinary validator transaction. Additional registrations are excluded
 * until the bootstrap committee certifies the first checkpoint.
 */
export declare function bootstrapFinalityValidators(state: WorldState, genesisKeys: readonly string[]): FinalityValidator[];
export declare function finalityQuorum(count: number): number;
export declare function validatorSetHash(validators: FinalityValidator[]): string;
export declare function encodeFinalityVoteForSigning(vote: Omit<FinalityVote, 'signature'> | FinalityVote): Uint8Array;
export declare function finalityVoteDigest(vote: Omit<FinalityVote, 'signature'> | FinalityVote): Uint8Array;
export declare function finalityVoteId(vote: FinalityVote): string;
export declare function signFinalityVote(unsigned: Omit<FinalityVote, 'signature'>, privateKey: string): FinalityVote;
export declare function verifyFinalityVoteSignature(vote: FinalityVote, hrp: string): boolean;
export declare function finalityVoteShape(vote: FinalityVote): {
    ok: true;
} | {
    ok: false;
    reason: string;
};
export declare function certificateShape(c: FinalityCertificate): {
    ok: true;
} | {
    ok: false;
    reason: string;
};
export declare function makeProposerEvidence(input: Omit<ProposerEquivocationEvidence, 'version' | 'id' | 'type' | 'messageType'>): ProposerEquivocationEvidence;
export declare function makeVoteEvidence(first: FinalityVote, second: FinalityVote): VoteEquivocationEvidence;
export declare function evidenceSerializedBytes(e: EquivocationEvidence): number;
export declare function digestBytes(hex: string): Uint8Array | null;
