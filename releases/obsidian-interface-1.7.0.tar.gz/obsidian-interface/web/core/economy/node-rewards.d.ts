/**
 * Node Runner rewards — who gets the ONS-funded 90% share, measured how, and why.
 *
 * THE ECONOMIC POINT
 *   Independent nodes are the network. The protocol therefore pays for the
 *   things that make independent nodes useful — being reachable, being in sync,
 *   relaying and validating, staying up across time — and pays for nothing else.
 *   Latency alone is not virtue, expensive hardware is not virtue and an
 *   operator's own opinion of its node is not evidence.
 *
 * THE RULE OF EVIDENCE
 *   Every number that decides a payout is computed by each node from chain
 *   state: blocks actually produced, attestations actually signed and
 *   countersigned by other nodes, faults reported by peers. A node cannot send
 *   the protocol "I was online 99%" — there is no field for it. The only thing a
 *   node may assert is a signed statement about *other* nodes' liveness, and
 *   that statement is worthless unless independent nodes make compatible ones.
 *
 * SCORING (all integer, all deterministic, all in basis points)
 *
 *   uptimeBps        = heartbeats seen in the period / heartbeats expected
 *                      (capped at 10_000)
 *   participationBps = mean of
 *                        producedBps = blocks produced / blocks expected for
 *                                      the node's scheduled slots
 *                        coverageBps = peers this node attested / peers that
 *                                      existed for most of the period
 *   reliabilityBps   = 10_000 − penalties, where each fault attributable to the
 *                      node by `minReporters` distinct reporters costs
 *                      `faultPenaltyBps`, and an invalid/conflicting attestation
 *                      costs the same
 *   responsivenessBps= share of this node's heartbeats that arrived while its
 *                      reported height was within `responsiveHeightLag` of the
 *                      network's, i.e. verification stayed current
 *
 *   scoreBps = (uptime*wU + participation*wP + reliability*wR + responsive*wS) / 10_000
 *
 *   weight   = scoreBps − minScoreBps, when uptime ≥ minUptimeBps and the node
 *              is registered and its height was recent at period close; else 0.
 *
 * SYBIL RESISTANCE (no administrator, no allowlist)
 *   - One reward identity may be registered per reward wallet, and one identity
 *     per reward wallet: an operator that splits a machine into ten nodes must
 *     present ten distinct identities and ten distinct reward wallets, and the
 *     protocol binds each to the other.
 *   - Registration itself moves no funds. The protocol's capital requirement is
 *     the validator bond (20,000 OBS, src/protocol/params.ts) — one bond, one
 *     rule, enforced in one place — and node rewards are capped per node
 *     (`maxNodeShareBps`) so no fleet can take a period.
 *   - Rewards are capped per node (`maxNodeShareBps`), so one operator's fleet
 *     cannot take a period.
 *   - Uptime requires attestations from *other* nodes, so ten nodes on one
 *     laptop attest ten nodes on one laptop: the protocol counts what honest
 *     peers observed, and a fleet that is one point of failure scores like one.
 *
 * WALLET CHANGES
 *   A reward wallet change requires a signature from the NEW wallet over
 *   a domain-separated message (see `walletChangeMessage`) and takes effect
 *   `walletChangeDelayPeriods` periods later. Rewards already accrued stay with
 *   the wallet that accrued them; only future periods follow the new wallet. A
 *   stolen node key therefore cannot redirect a single seal that has not been
 *   earned yet, and an operator cannot be locked out of their own node forever.
 */
export interface NodeRewardParamsSummary {
    nodePoolBps: number;
    treasuryBps: number;
    periodSeconds: number;
    minUptimeBps: number;
    minScoreBps: number;
    maxNodeShareBps: number;
    minAttesters: number;
    walletChangeDelayPeriods: number;
    evidenceWindowPeriods: number;
    scoreWeights: {
        uptimeBps: number;
        participationBps: number;
        reliabilityBps: number;
        responsivenessBps: number;
    };
}
/** Period index that contains a protocol timestamp. Deterministic, no clock. */
export declare function rewardPeriodAt(timestamp: number): number;
/** Start timestamp of a period. */
export declare function rewardPeriodStart(period: number): number;
/** End timestamp (exclusive) of a period. */
export declare function rewardPeriodEnd(period: number): number;
export interface NodeLivenessEvidence {
    registered: boolean;
    /** Heartbeats from this node inside the period. */
    heartbeats: number;
    /** Distinct nodes that attested this node inside the period. */
    distinctAttesters: number;
    /** Nodes that existed for most of the period (the attestation universe). */
    peerUniverse: number;
}
export interface NodeParticipationEvidence {
    /** Blocks this node produced inside the period that are in the canonical chain. */
    blocksProduced: number;
    /** Blocks the protocol scheduled for this node's slots inside the period. */
    blocksExpected: number;
    /** Distinct peers this node attested inside the period. */
    attestationsMade: number;
}
export interface NodeReliabilityEvidence {
    /** Corroborated fault reports attributed to this node. */
    faults: number;
    /** Attestations from this node that contradicted the protocol (duplicates, lies). */
    invalidAttestations: number;
}
export interface NodeResponsivenessEvidence {
    /** Heartbeats that carried a height within tolerance of the network's. */
    responsiveHeartbeats: number;
    /** Heartbeats that carried a stale height. */
    staleHeartbeats: number;
}
export interface NodeEvidence {
    liveness: NodeLivenessEvidence;
    participation: NodeParticipationEvidence;
    reliability: NodeReliabilityEvidence;
    responsiveness: NodeResponsivenessEvidence;
}
export interface NodeScore {
    /** Uptime component, basis points. */
    uptimeBps: number;
    participationBps: number;
    reliabilityBps: number;
    responsivenessBps: number;
    /** Weighted total, basis points. */
    scoreBps: number;
    /** Score above the floor that earns a share; 0 when ineligible. */
    weight: number;
    eligible: boolean;
    /** Machine-readable explanation, recomputed identically by every node. */
    reasons: string[];
}
export declare function constantTimeEqual(a: string, b: string): boolean;
/**
 * Score one node from verified evidence. Pure function: the same evidence must
 * produce the same score on every node, so this takes no clock, no randomness
 * and no configuration beyond the consensus parameters.
 */
export declare function scoreNode(evidence: NodeEvidence): NodeScore;
export interface RewardAllocation {
    nodeId: string;
    rewardWallet: string;
    scoreBps: number;
    weight: number;
    /** Share of the period pool, basis points of the whole pool. */
    shareBps: number;
    /** Amount credited to `rewardWallet`, in seals. */
    amount: bigint;
}
export interface RewardSettlement {
    period: number;
    poolSeals: bigint;
    allocations: RewardAllocation[];
    /** Sum of allocated amounts. Equals `poolSeals` unless capped or nobody qualified. */
    distributedSeals: bigint;
    /** Remainder left in the pool for the next period (rounding and caps). */
    carriedSeals: bigint;
    eligibleNodes: number;
    scoredNodes: number;
    /** Machine-readable policy line, identical on every node. */
    method: string;
}
/**
 * Distribute a period's Node Runner Reward Pool.
 *
 * Deterministic algorithm, exact integer arithmetic throughout:
 *
 *   1. Score every registered node from verified evidence (scoreNode).
 *   2. weight_n = scoreBps_n − minScoreBps for eligible nodes, else 0. A node
 *      that produced nothing and attested nobody has weight 0, so standing
 *      still earns nothing no matter how long it has been registered.
 *   3. shareBps_n = floor(weight_n * 10_000 / Σweight), then no single node may
 *      exceed maxNodeShareBps; excess is left in the pool (cap, not a re-run).
 *   4. amount_n = floor(poolSeals * shareBps_n / 10_000). The rounding remainder
 *      is carried in the pool: `Σamount + carried == poolSeals` always holds.
 *
 * `nodes` must be sorted by nodeId by the caller (chain state is iterated in
 * lexicographic order), so the result does not depend on iteration order.
 */
export declare function settleNodeRewards(input: {
    period: number;
    poolSeals: bigint;
    nodes: Array<{
        nodeId: string;
        evidence: NodeEvidence;
    }>;
}): RewardSettlement;
/**
 * Domain-separated messages the node identity and the reward wallet sign.
 *
 * Signed with the protocol's own primitive — secp256k1 ECDSA, RFC 6979
 * deterministic nonces, 64-byte compact low-S, exactly as transactions and
 * blocks are signed (see src/crypto/keys.ts). Each message carries its own
 * `OBSIDIAN:NODE_*` domain tag and both the network id and chain id, so a
 * signature made for one network, one chain, or one purpose can never be
 * replayed as another: a heartbeat cannot be re-submitted as a registration,
 * and a testnet proof is worthless on mainnet.
 */
export declare function nodeRegistrationMessage(input: {
    networkId: string;
    chainId: number;
    nodeId: string;
    rewardWallet: string;
    endpoint: string;
    issuedAt: number;
    expiresAt: number;
}): string;
export declare function walletChangeMessage(input: {
    networkId: string;
    chainId: number;
    nodeId: string;
    currentWallet: string;
    newWallet: string;
    requestedAt: number;
}): string;
export declare function deregistrationMessage(input: {
    networkId: string;
    chainId: number;
    nodeId: string;
    rewardWallet: string;
    requestedAt: number;
}): string;
export interface NodeRewardStatusView {
    nodeId: string;
    rewardWallet: string;
    registered: boolean;
    registeredAtHeight: number;
    period: number;
    score: NodeScore | null;
    paidObs: string;
    pendingObs: string;
    claimablePeriods: number[];
    pendingWalletChange: {
        wallet: string;
        effectivePeriod: number;
    } | null;
    facts: {
        heartbeats: number;
        attesters: number;
        peerUniverse: number;
        blocksProduced: number;
        blocksExpected: number;
        attestationsMade: number;
        faults: number;
        invalidAttestations: number;
        staleHeartbeats: number;
    };
}
/** Parameters a node operator needs, published by every node identically. */
export declare function nodeRewardParams(): NodeRewardParamsSummary;
