/**
 * Deterministic accounting rules for protocol-held OBS.
 *
 * ONS registration and renewal fees are the only protocol-revenue sources.
 * At receipt, each fee is split in integer base units: floor(90% of the fee) to
 * the Node Runner Reward Pool and the exact remainder to the genesis-designated
 * treasury wallet (or recorded as unclaimed until that wallet exists).
 *
 * Gas, issuance, validator bonds, mining rewards, treasury grants and
 * user-to-user transfers are separate accounting categories and are never
 * counted as ONS revenue.
 */
import type { TxType } from '../protocol/types.js';
export declare enum AccountingCategory {
    MINING_POOL = "MINING_POOL",
    TREASURY = "TREASURY",
    NODE_RUNNER_POOL = "NODE_RUNNER_POOL",
    USER_FUNDS = "USER_FUNDS",
    UNCLAIMED_REVENUE = "UNCLAIMED_REVENUE"
}
/** The complete, closed set of protocol-revenue sources. */
export declare enum RevenueSource {
    ONS_REGISTRATION = "ONS_REGISTRATION",
    ONS_RENEWAL = "ONS_RENEWAL"
}
/** Value that is explicitly NOT ONS revenue, with the reason attached. */
export declare const NOT_ONS_REVENUE: ReadonlyArray<{
    txType: TxType;
    name: string;
    because: string;
}>;
export interface RevenueSplit {
    /** Total ONS revenue received. */
    total: bigint;
    /** 90% target share → Node Runner Reward Pool (floored in base units). */
    nodeRunnerPool: bigint;
    /** Exact remainder → treasury, preserving every base unit. */
    treasury: bigint;
    totalBps: number;
    nodePoolBps: number;
    treasuryBps: number;
}
/** Split ONS revenue without rounding loss or duplicated allocation. */
export declare function splitOnsRevenue(total: bigint, source: RevenueSource): RevenueSplit;
/** The invariant every ONS fee transition must satisfy. */
export declare function assertSplitInvariant(split: RevenueSplit): void;
