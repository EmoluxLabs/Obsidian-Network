/**
 * Bech32 / Bech32m reference implementation (BIP-0173 / BIP-0350).
 *
 * Obsidian uses bech32 (not bech32m) with human-readable part "obs" for wallet
 * addresses, and bech32m for on-chain .obs name identifiers.
 * This is a well-specified public encoding, not a bespoke primitive: the
 * payload is always the SHA-256/RIPEMD-160 digest of a secp256k1 public key.
 */
export declare const BECH32_CONST = 1;
export declare const BECH32M_CONST = 734539939;
export declare function convertBits(data: number[], from: number, to: number, pad: boolean): number[];
export declare function bech32Encode(hrp: string, data: number[], encoding?: number): string;
export declare function bech32Decode(str: string, expectedEncoding?: number): {
    hrp: string;
    data: number[];
    encoding: number;
};
export declare function encodePayload(hrp: string, payload: Uint8Array, encoding?: number): string;
export declare function decodePayload(hrp: string, str: string, encoding?: number): Uint8Array;
