/**
 * Protocol time helpers.
 *
 * Protocol time is the timestamp of the block currently being applied. It is
 * NEVER read from the local clock inside a state transition: doing so would
 * make the state root differ between nodes.
 */
export declare const ONE_MINUTE = 60;
export declare const ONE_HOUR: number;
export declare const ONE_DAY: number;
export declare function formatIso(seconds: number): string;
/** Deterministic pseudo-identifier derived from a seed and a counter. */
export declare function deriveId(seed: string, counter: number): string;
