/**
 * NODE_REGISTRY — the on-chain registry of node runners and the evidence they
 * submit for their Proof of Time rewards (spec: node runner reward pool).
 *
 * DESIGN RULES
 *
 *   1. THE PROTOCOL PAYS FOR VERIFIED FACTS, NEVER FOR CLAIMS.
 *      Nothing in this executor accepts an amount, an uptime percentage, a
 *      hashrate, a CPU benchmark or "I was online". What is recorded is: this
 *      node identity exists, it sent its heartbeat for this period, this other
 *      registered node attested it, this node produced these blocks. Every one
 *      of those facts is a signed statement from a key that had to exist and pay
 *      gas to make it, and every payout is computed later from the recorded
 *      facts (src/economy/node-rewards.ts).
 *
 *   2. TWO KEYS, TWO JOBS.
 *      - The NODE IDENTITY key (nodePublicKey → nodeId) is generated on the node
 *        runner and never leaves it. It signs heartbeats, attestations and fault
 *        reports, plus the consent on registration, wallet change and exit.
 *      - The REWARD WALLET key signs the transaction itself (so the protocol's
 *        ordinary transaction-signature verification already proves the operator
 *        controls the payout address) and holds the bond.
 *      An attacker with one key cannot do anything alone: the wallet holder
 *      cannot move someone else's node identity to their address, and the node
 *      key holder cannot spend a bond or redirect accrued rewards without the
 *      wallet's own signature.
 *
 *   3. NO OPERATOR-SUPPLIED TIME.
 *      Every statement carries an issued-at/expires-at window that is checked
 *      against protocol time in the block that includes it, and heartbeats are
 *      keyed to the reward period derived from that same block. A node cannot
 *      send fourteen heartbeats "for last week" or backdate an attestation: the
 *      block decides when the statement happened.
 *
 *   4. NO REGISTRATION DEPOSIT.
 *      Registering a node runner moves no funds: there was once a 100 OBS
 *      registration bond, and it was removed as a mechanism rather than set to
 *      zero. The protocol has exactly one bond — the validator bond — because
 *      two bonds with one name is exactly how an economic rule ends up applied
 *      in one place and not the other. What keeps the registry honest is the
 *      things a node cannot fake: one reward wallet behind one node identity,
 *      attestations that come from other nodes, and payouts computed only from
 *      recorded, verified evidence.
 */
import { type NodeRegistryBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeNodeRegistryBody(body: Uint8Array): NodeRegistryBody;
export declare function encodeNodeRegistryBody(body: NodeRegistryBody): Uint8Array;
export declare function executeNodeRegistry(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
export declare function heartbeatMessage(input: {
    networkId: string;
    chainId: number;
    nodeId: string;
    period: number;
    reportedHeight: number;
    endpoint: string;
}): string;
export declare function attestationMessage(input: {
    networkId: string;
    chainId: number;
    observer: string;
    subject: string;
    period: number;
    reportedHeight: number;
}): string;
export declare function faultReportMessage(input: {
    networkId: string;
    chainId: number;
    reporter: string;
    subject: string;
    period: number;
    reason: string;
}): string;
/** Registered node runner count, for the interface. */
export declare function registeredNodeCount(ctx: ExecutorContext): number;
