/**
 * TREASURY — signed grants from the existing treasury balance.
 *
 * A GRANT moves existing funds from the designated treasury wallet to a
 * recipient and must be signed by the treasury key. It never mints and is not
 * protocol revenue; ONS fees are the only revenue flows.
 */
import { type TreasuryBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeTreasuryBody(body: Uint8Array): TreasuryBody;
export declare function encodeTreasuryBody(body: TreasuryBody): Uint8Array;
export declare function executeTreasury(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * GOVERNANCE transactions are reserved and always rejected in this protocol version.
 * Parameter changes require a documented protocol version upgrade because every
 * consensus parameter participates in PARAMS_HASH, which peers verify during
 * the handshake. This is deliberate: no transaction, and no administrator, can
 * silently change consensus rules at runtime.
 */
export declare function executeGovernance(tx: TxEnvelope): never;
