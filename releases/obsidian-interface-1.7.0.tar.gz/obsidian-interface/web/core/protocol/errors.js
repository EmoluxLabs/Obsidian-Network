/**
 * Protocol error codes.
 *
 * Every rejection carries a stable machine code so that nodes, explorers and
 * the interface can reason about failures without parsing prose. Codes are part
 * of the protocol surface and must not be renumbered.
 */
export var ErrCode;
(function (ErrCode) {
    ErrCode["OK"] = "OK";
    // Structural / encoding
    ErrCode["MALFORMED"] = "ERR_MALFORMED";
    ErrCode["VERSION_MISMATCH"] = "ERR_VERSION_MISMATCH";
    ErrCode["WRONG_NETWORK"] = "ERR_WRONG_NETWORK";
    ErrCode["WRONG_CHAIN_ID"] = "ERR_WRONG_CHAIN_ID";
    ErrCode["TRAILING_BYTES"] = "ERR_TRAILING_BYTES";
    // Signature / authorisation
    ErrCode["BAD_SIGNATURE"] = "ERR_BAD_SIGNATURE";
    ErrCode["BAD_SENDER"] = "ERR_BAD_SENDER";
    ErrCode["BAD_ADDRESS"] = "ERR_BAD_ADDRESS";
    ErrCode["UNAUTHORIZED"] = "ERR_UNAUTHORIZED";
    // Replay / ordering
    ErrCode["BAD_NONCE"] = "ERR_BAD_NONCE";
    ErrCode["DUPLICATE_TX"] = "ERR_DUPLICATE_TX";
    ErrCode["REPLAY"] = "ERR_REPLAY";
    ErrCode["EXPIRED"] = "ERR_EXPIRED";
    ErrCode["NOT_YET_VALID"] = "ERR_NOT_YET_VALID";
    /** Another transaction with this sender and nonce is already waiting for a block. */
    ErrCode["NONCE_PENDING"] = "ERR_NONCE_PENDING";
    // Value
    ErrCode["INSUFFICIENT_FUNDS"] = "ERR_INSUFFICIENT_FUNDS";
    ErrCode["AMOUNT_ZERO"] = "ERR_AMOUNT_ZERO";
    ErrCode["AMOUNT_NEGATIVE"] = "ERR_AMOUNT_NEGATIVE";
    ErrCode["BAD_GAS"] = "ERR_BAD_GAS";
    ErrCode["SUPPLY_EXCEEDED"] = "ERR_SUPPLY_EXCEEDED";
    // Mining
    ErrCode["MINING_NOT_ELIGIBLE"] = "ERR_MINING_NOT_ELIGIBLE";
    ErrCode["MINING_TOO_SOON"] = "ERR_MINING_TOO_SOON";
    ErrCode["MINING_CYCLE_LIMIT"] = "ERR_MINING_CYCLE_LIMIT";
    /** A block carries more equivocation evidence than the per-block budget. */
    ErrCode["EVIDENCE_LIMIT"] = "ERR_EVIDENCE_LIMIT";
    ErrCode["MINING_BAD_PROOF"] = "ERR_MINING_BAD_PROOF";
    ErrCode["MINING_CLAIM_REPLAY"] = "ERR_MINING_CLAIM_REPLAY";
    /** The claim carries no gate certificate, or the chain has no gate keys at all. */
    ErrCode["MINING_GATE_REQUIRED"] = "ERR_MINING_GATE_REQUIRED";
    /** The gate certificate is malformed, expired, from an unknown issuer, or does not match this claim. */
    ErrCode["MINING_GATE_INVALID"] = "ERR_MINING_GATE_INVALID";
    // Genesis
    ErrCode["GENESIS_ALREADY_CLAIMED"] = "ERR_GENESIS_ALREADY_CLAIMED";
    ErrCode["GENESIS_NOT_ELIGIBLE"] = "ERR_GENESIS_NOT_ELIGIBLE";
    // Transaction-type specific
    ErrCode["UNKNOWN_TX_TYPE"] = "ERR_UNKNOWN_TX_TYPE";
    ErrCode["NAME_TAKEN"] = "ERR_NAME_TAKEN";
    ErrCode["NAME_NOT_OWNED"] = "ERR_NAME_NOT_OWNED";
    ErrCode["NAME_INVALID"] = "ERR_NAME_INVALID";
    ErrCode["NAME_RESERVED"] = "ERR_NAME_RESERVED";
    ErrCode["PRICE_MISMATCH"] = "ERR_PRICE_MISMATCH";
    // Oracle
    ErrCode["ORACLE_STALE"] = "ERR_ORACLE_STALE";
    ErrCode["ORACLE_UNAVAILABLE"] = "ERR_ORACLE_UNAVAILABLE";
    ErrCode["ORACLE_OUT_OF_BOUNDS"] = "ERR_ORACLE_OUT_OF_BOUNDS";
    ErrCode["ORACLE_INSUFFICIENT_SOURCES"] = "ERR_ORACLE_INSUFFICIENT_SOURCES";
    // Block level
    ErrCode["BAD_PREV_HASH"] = "ERR_BAD_PREV_HASH";
    ErrCode["BAD_HEIGHT"] = "ERR_BAD_HEIGHT";
    ErrCode["BAD_MERKLE_ROOT"] = "ERR_BAD_MERKLE_ROOT";
    ErrCode["BAD_STATE_ROOT"] = "ERR_BAD_STATE_ROOT";
    ErrCode["BAD_TIMESTAMP"] = "ERR_BAD_TIMESTAMP";
    ErrCode["BAD_DIFFICULTY"] = "ERR_BAD_DIFFICULTY";
    ErrCode["BLOCK_TOO_LARGE"] = "ERR_BLOCK_TOO_LARGE";
    ErrCode["DUPLICATE_BLOCK"] = "ERR_DUPLICATE_BLOCK";
    ErrCode["ORPHAN_BLOCK"] = "ERR_ORPHAN_BLOCK";
    /** The block forks further back than the protocol's maximum reorg depth. */
    ErrCode["STALE_BLOCK"] = "ERR_STALE_BLOCK";
    ErrCode["BAD_PRODUCER"] = "ERR_BAD_PRODUCER";
    ErrCode["NOT_PRODUCER_TURN"] = "ERR_NOT_PRODUCER_TURN";
    /** The candidate would replace or omit locally finalized history. */
    ErrCode["FINALITY_CONFLICT"] = "ERR_FINALITY_CONFLICT";
    // Node runner registry (Proof of Time node rewards)
    ErrCode["NODE_NOT_REGISTERED"] = "ERR_NODE_NOT_REGISTERED";
    ErrCode["NODE_ALREADY_REGISTERED"] = "ERR_NODE_ALREADY_REGISTERED";
    ErrCode["NODE_WALLET_IN_USE"] = "ERR_NODE_WALLET_IN_USE";
    ErrCode["NODE_BAD_ENDPOINT"] = "ERR_NODE_BAD_ENDPOINT";
    ErrCode["NODE_HEARTBEAT_TOO_SOON"] = "ERR_NODE_HEARTBEAT_TOO_SOON";
    ErrCode["NODE_BAD_SUBJECT"] = "ERR_NODE_BAD_SUBJECT";
    ErrCode["NODE_ATTEST_LIMIT"] = "ERR_NODE_ATTEST_LIMIT";
    ErrCode["NODE_FAULT_LIMIT"] = "ERR_NODE_FAULT_LIMIT";
    ErrCode["NODE_WALLET_CHANGE_PENDING"] = "ERR_NODE_WALLET_CHANGE_PENDING";
    ErrCode["NODE_PROOF_EXPIRED"] = "ERR_NODE_PROOF_EXPIRED";
    // Fees
    ErrCode["VALIDATOR_BOND_MISMATCH"] = "ERR_VALIDATOR_BOND_MISMATCH";
    // Fees
    ErrCode["GAS_REQUIRED"] = "ERR_GAS_REQUIRED";
    // Internal
    ErrCode["INTERNAL"] = "ERR_INTERNAL";
    ErrCode["RATE_LIMITED"] = "ERR_RATE_LIMITED";
    ErrCode["NOT_FOUND"] = "ERR_NOT_FOUND";
})(ErrCode || (ErrCode = {}));
export class ProtocolError extends Error {
    code;
    context;
    constructor(code, message, context) {
        super(message);
        this.code = code;
        this.context = context;
        this.name = 'ProtocolError';
    }
}
export function reject(code, message, context) {
    throw new ProtocolError(code, message, context);
}
/** Human-readable explanation shown in the interface for each rejection. */
export const ERR_MESSAGES = {
    [ErrCode.OK]: 'Accepted.',
    [ErrCode.MALFORMED]: 'The object could not be decoded under the canonical encoding rules.',
    [ErrCode.VERSION_MISMATCH]: 'Protocol version not supported by this node.',
    [ErrCode.WRONG_NETWORK]: 'Object belongs to a different Obsidian network.',
    [ErrCode.WRONG_CHAIN_ID]: 'Object was signed for a different chain ID.',
    [ErrCode.TRAILING_BYTES]: 'Object contains trailing bytes.',
    [ErrCode.BAD_SIGNATURE]: 'Cryptographic signature verification failed.',
    [ErrCode.BAD_SENDER]: 'The public key does not control the stated sender address.',
    [ErrCode.BAD_ADDRESS]: 'Address is not a valid obs1 address.',
    [ErrCode.UNAUTHORIZED]: 'The signer is not authorised for this operation.',
    [ErrCode.BAD_NONCE]: 'Transaction nonce is not the expected next nonce for this account.',
    [ErrCode.DUPLICATE_TX]: 'This transaction is already known.',
    [ErrCode.REPLAY]: 'This object has already been applied.',
    [ErrCode.EXPIRED]: 'Object expired before it was included.',
    [ErrCode.NOT_YET_VALID]: 'Object is not valid yet.',
    [ErrCode.NONCE_PENDING]: 'This account already has a transaction with that nonce waiting for the next block.',
    [ErrCode.INSUFFICIENT_FUNDS]: 'Insufficient OBS balance to cover amount plus gas.',
    [ErrCode.AMOUNT_ZERO]: 'Amount must be greater than zero.',
    [ErrCode.AMOUNT_NEGATIVE]: 'Amount must not be negative.',
    [ErrCode.BAD_GAS]: 'Gas calculation does not match the protocol formula.',
    [ErrCode.SUPPLY_EXCEEDED]: 'Issuance would exceed the 21,000,000 OBS maximum supply.',
    [ErrCode.MINING_NOT_ELIGIBLE]: 'Wallet is not an eligible miner.',
    [ErrCode.MINING_TOO_SOON]: 'The protocol mining interval has not elapsed yet.',
    [ErrCode.MINING_CYCLE_LIMIT]: 'The maximum number of claims for this 24-hour cycle is reached.',
    [ErrCode.EVIDENCE_LIMIT]: 'This block carries more equivocation evidence than one block may hold; the report stays pending for a later block.',
    [ErrCode.MINING_BAD_PROOF]: 'Mining claim proof failed verification.',
    [ErrCode.MINING_CLAIM_REPLAY]: 'This mining claim has already been accepted.',
    [ErrCode.MINING_GATE_REQUIRED]: 'A mining claim must carry a certificate from the mining gate (a signed-in, verified account).',
    [ErrCode.MINING_GATE_INVALID]: 'The mining gate certificate is not valid for this claim.',
    [ErrCode.GENESIS_ALREADY_CLAIMED]: 'The Genesis Allocation has already been claimed by another wallet.',
    [ErrCode.GENESIS_NOT_ELIGIBLE]: 'This wallet is not eligible for the Genesis Allocation.',
    [ErrCode.UNKNOWN_TX_TYPE]: 'Unknown transaction type for this protocol version.',
    [ErrCode.NAME_TAKEN]: 'That .obs name is already registered.',
    [ErrCode.NAME_NOT_OWNED]: 'The signer does not own that .obs name.',
    [ErrCode.NAME_INVALID]: 'Name format is invalid.',
    [ErrCode.NAME_RESERVED]: 'That name is reserved by the protocol.',
    [ErrCode.PRICE_MISMATCH]: 'The accepted price does not match the price recorded in protocol state.',
    [ErrCode.ORACLE_STALE]: 'The price oracle has no fresh observation and cannot price this transaction.',
    [ErrCode.ORACLE_UNAVAILABLE]: 'Insufficient independent price sources are available to form a valid price.',
    [ErrCode.ORACLE_OUT_OF_BOUNDS]: 'A reported price fell outside protocol sanity bounds and was rejected.',
    [ErrCode.ORACLE_INSUFFICIENT_SOURCES]: 'Fewer oracle sources than the protocol quorum.',
    [ErrCode.BAD_PREV_HASH]: 'Block does not extend the parent seen by this node.',
    [ErrCode.BAD_HEIGHT]: 'Block height does not follow from its parent.',
    [ErrCode.BAD_MERKLE_ROOT]: 'Merkle root does not commit to the block transactions.',
    [ErrCode.BAD_STATE_ROOT]: 'State root does not match the state produced by this block.',
    [ErrCode.BAD_TIMESTAMP]: 'Block timestamp violates the median-time-past / drift rules.',
    [ErrCode.BAD_DIFFICULTY]: 'Difficulty does not match the value derived from the latest headers.',
    [ErrCode.BLOCK_TOO_LARGE]: 'Block exceeds the maximum serialized size.',
    [ErrCode.DUPLICATE_BLOCK]: 'Block is already part of this chain.',
    [ErrCode.ORPHAN_BLOCK]: 'Parent block is unknown; queued as an orphan.',
    [ErrCode.STALE_BLOCK]: 'Block forks further back than the maximum reorganisation depth and can never join the chain.',
    [ErrCode.BAD_PRODUCER]: 'The block producer signature is invalid or does not match the producer address.',
    [ErrCode.NOT_PRODUCER_TURN]: 'Producer is not the scheduled proposer for this height.',
    [ErrCode.FINALITY_CONFLICT]: 'Candidate conflicts with locally finalized history.',
    [ErrCode.NODE_NOT_REGISTERED]: 'This node identity is not registered for node runner rewards.',
    [ErrCode.NODE_ALREADY_REGISTERED]: 'This node identity is already registered.',
    [ErrCode.NODE_WALLET_IN_USE]: 'This reward wallet already backs another registered node.',
    [ErrCode.NODE_BAD_ENDPOINT]: 'The endpoint hint is not a usable host:port, or is longer than the protocol allows.',
    [ErrCode.NODE_HEARTBEAT_TOO_SOON]: 'This node already sent its heartbeat for the current reward period.',
    [ErrCode.NODE_BAD_SUBJECT]: 'The subject node is not a registered node runner.',
    [ErrCode.NODE_ATTEST_LIMIT]: 'This node reached the per-period attestation limit.',
    [ErrCode.NODE_FAULT_LIMIT]: 'This node reached the per-period fault report limit.',
    [ErrCode.NODE_WALLET_CHANGE_PENDING]: 'A reward wallet change is already pending for this node.',
    [ErrCode.NODE_PROOF_EXPIRED]: 'The signed node statement is outside its validity window.',
    [ErrCode.VALIDATOR_BOND_MISMATCH]: 'Validator registration requires exactly 20,000 OBS bonded.',
    [ErrCode.GAS_REQUIRED]: 'Transaction does not carry the protocol-required gas.',
    [ErrCode.INTERNAL]: 'Internal node error.',
    [ErrCode.RATE_LIMITED]: 'Rate limit exceeded.',
    [ErrCode.NOT_FOUND]: 'Object not found.',
};
//# sourceMappingURL=errors.js.map