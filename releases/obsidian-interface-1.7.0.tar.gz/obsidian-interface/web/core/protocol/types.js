/**
 * Obsidian protocol object model.
 *
 * These types are the consensus surface. The canonical encoder in
 * encoding.ts serializes them; a field not listed here cannot affect state.
 */
export var TxType;
(function (TxType) {
    TxType[TxType["PAYMENT"] = 1] = "PAYMENT";
    TxType[TxType["ONS"] = 2] = "ONS";
    TxType[TxType["ORACLE"] = 6] = "ORACLE";
    TxType[TxType["MINING_CLAIM"] = 7] = "MINING_CLAIM";
    TxType[TxType["VALIDATOR"] = 8] = "VALIDATOR";
    TxType[TxType["TREASURY"] = 9] = "TREASURY";
    TxType[TxType["GOVERNANCE"] = 10] = "GOVERNANCE";
    /**
     * Node Runner registry. Carries the signed statements that make node-runner
     * rewards measurable: registration with a proof of reward-wallet ownership,
     * wallet changes, deregistration, liveness heartbeats, peer attestations and
     * peer fault reports. None of these carry an amount: the protocol computes
     * every payout from the evidence it collects here (see src/economy/node-rewards.ts).
     */
    TxType[TxType["NODE_REGISTRY"] = 11] = "NODE_REGISTRY";
    /**
     * Slashing. Carries self-contained cryptographic proof that a bonded
     * validator signed two conflicting messages for one consensus slot. The
     * submitter chooses nothing: the executor derives the penalty from the
     * consensus slash ratio and the validator's own record, and a validator can
     * only be slashed by evidence that every honest node verifies identically
     * (src/consensus/slash-evidence.ts).
     */
    TxType[TxType["SLASH"] = 12] = "SLASH";
})(TxType || (TxType = {}));
/** Operations inside a SLASH transaction. */
export var SlashOp;
(function (SlashOp) {
    /** Two conflicting block proposals, or two conflicting finality votes. */
    SlashOp[SlashOp["EQUIVOCATION"] = 1] = "EQUIVOCATION";
})(SlashOp || (SlashOp = {}));
/** Operations inside a NODE_REGISTRY transaction. */
export var NodeRegistryOp;
(function (NodeRegistryOp) {
    NodeRegistryOp[NodeRegistryOp["REGISTER"] = 1] = "REGISTER";
    NodeRegistryOp[NodeRegistryOp["CHANGE_WALLET"] = 2] = "CHANGE_WALLET";
    NodeRegistryOp[NodeRegistryOp["DEREGISTER"] = 3] = "DEREGISTER";
    /** A signed liveness statement from the node itself, valid within a slot. */
    NodeRegistryOp[NodeRegistryOp["HEARTBEAT"] = 4] = "HEARTBEAT";
    /** A signed statement from one node about another node's liveness. */
    NodeRegistryOp[NodeRegistryOp["ATTEST"] = 5] = "ATTEST";
    /** A signed report that another node behaved incorrectly. */
    NodeRegistryOp[NodeRegistryOp["REPORT_FAULT"] = 6] = "REPORT_FAULT";
})(NodeRegistryOp || (NodeRegistryOp = {}));
// ── ONS ──────────────────────────────────────────────────────────────────────
export var OnsOp;
(function (OnsOp) {
    OnsOp[OnsOp["REGISTER"] = 1] = "REGISTER";
    OnsOp[OnsOp["UPDATE_ADDRESS"] = 2] = "UPDATE_ADDRESS";
    OnsOp[OnsOp["TRANSFER"] = 3] = "TRANSFER";
    OnsOp[OnsOp["RENEW"] = 4] = "RENEW";
})(OnsOp || (OnsOp = {}));
// ── Validators ───────────────────────────────────────────────────────────────
export var ValidatorOp;
(function (ValidatorOp) {
    ValidatorOp[ValidatorOp["REGISTER"] = 1] = "REGISTER";
    ValidatorOp[ValidatorOp["UNREGISTER"] = 2] = "UNREGISTER";
    ValidatorOp[ValidatorOp["CLAIM_UNBONDED"] = 3] = "CLAIM_UNBONDED";
})(ValidatorOp || (ValidatorOp = {}));
// ── Treasury ─────────────────────────────────────────────────────────────────
export var TreasuryOp;
(function (TreasuryOp) {
    /** Existing treasury balance grants signed by the designated treasury key. */
    TreasuryOp[TreasuryOp["GRANT"] = 2] = "GRANT";
})(TreasuryOp || (TreasuryOp = {}));
//# sourceMappingURL=types.js.map