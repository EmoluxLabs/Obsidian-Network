/**
 * Protocol error codes.
 *
 * Every rejection carries a stable machine code so that nodes, explorers and
 * the interface can reason about failures without parsing prose. Codes are part
 * of the protocol surface and must not be renumbered.
 */
export declare enum ErrCode {
    OK = "OK",
    MALFORMED = "ERR_MALFORMED",
    VERSION_MISMATCH = "ERR_VERSION_MISMATCH",
    WRONG_NETWORK = "ERR_WRONG_NETWORK",
    WRONG_CHAIN_ID = "ERR_WRONG_CHAIN_ID",
    TRAILING_BYTES = "ERR_TRAILING_BYTES",
    BAD_SIGNATURE = "ERR_BAD_SIGNATURE",
    BAD_SENDER = "ERR_BAD_SENDER",
    BAD_ADDRESS = "ERR_BAD_ADDRESS",
    UNAUTHORIZED = "ERR_UNAUTHORIZED",
    BAD_NONCE = "ERR_BAD_NONCE",
    DUPLICATE_TX = "ERR_DUPLICATE_TX",
    REPLAY = "ERR_REPLAY",
    EXPIRED = "ERR_EXPIRED",
    NOT_YET_VALID = "ERR_NOT_YET_VALID",
    /** Another transaction with this sender and nonce is already waiting for a block. */
    NONCE_PENDING = "ERR_NONCE_PENDING",
    INSUFFICIENT_FUNDS = "ERR_INSUFFICIENT_FUNDS",
    AMOUNT_ZERO = "ERR_AMOUNT_ZERO",
    AMOUNT_NEGATIVE = "ERR_AMOUNT_NEGATIVE",
    BAD_GAS = "ERR_BAD_GAS",
    SUPPLY_EXCEEDED = "ERR_SUPPLY_EXCEEDED",
    MINING_NOT_ELIGIBLE = "ERR_MINING_NOT_ELIGIBLE",
    MINING_TOO_SOON = "ERR_MINING_TOO_SOON",
    MINING_CYCLE_LIMIT = "ERR_MINING_CYCLE_LIMIT",
    /** A block carries more equivocation evidence than the per-block budget. */
    EVIDENCE_LIMIT = "ERR_EVIDENCE_LIMIT",
    MINING_BAD_PROOF = "ERR_MINING_BAD_PROOF",
    MINING_CLAIM_REPLAY = "ERR_MINING_CLAIM_REPLAY",
    /** The claim carries no gate certificate, or the chain has no gate keys at all. */
    MINING_GATE_REQUIRED = "ERR_MINING_GATE_REQUIRED",
    /** The gate certificate is malformed, expired, from an unknown issuer, or does not match this claim. */
    MINING_GATE_INVALID = "ERR_MINING_GATE_INVALID",
    GENESIS_ALREADY_CLAIMED = "ERR_GENESIS_ALREADY_CLAIMED",
    GENESIS_NOT_ELIGIBLE = "ERR_GENESIS_NOT_ELIGIBLE",
    UNKNOWN_TX_TYPE = "ERR_UNKNOWN_TX_TYPE",
    NAME_TAKEN = "ERR_NAME_TAKEN",
    NAME_NOT_OWNED = "ERR_NAME_NOT_OWNED",
    NAME_INVALID = "ERR_NAME_INVALID",
    NAME_RESERVED = "ERR_NAME_RESERVED",
    PRICE_MISMATCH = "ERR_PRICE_MISMATCH",
    ORACLE_STALE = "ERR_ORACLE_STALE",
    ORACLE_UNAVAILABLE = "ERR_ORACLE_UNAVAILABLE",
    ORACLE_OUT_OF_BOUNDS = "ERR_ORACLE_OUT_OF_BOUNDS",
    ORACLE_INSUFFICIENT_SOURCES = "ERR_ORACLE_INSUFFICIENT_SOURCES",
    BAD_PREV_HASH = "ERR_BAD_PREV_HASH",
    BAD_HEIGHT = "ERR_BAD_HEIGHT",
    BAD_MERKLE_ROOT = "ERR_BAD_MERKLE_ROOT",
    BAD_STATE_ROOT = "ERR_BAD_STATE_ROOT",
    BAD_TIMESTAMP = "ERR_BAD_TIMESTAMP",
    BAD_DIFFICULTY = "ERR_BAD_DIFFICULTY",
    BLOCK_TOO_LARGE = "ERR_BLOCK_TOO_LARGE",
    DUPLICATE_BLOCK = "ERR_DUPLICATE_BLOCK",
    ORPHAN_BLOCK = "ERR_ORPHAN_BLOCK",
    /** The block forks further back than the protocol's maximum reorg depth. */
    STALE_BLOCK = "ERR_STALE_BLOCK",
    BAD_PRODUCER = "ERR_BAD_PRODUCER",
    NOT_PRODUCER_TURN = "ERR_NOT_PRODUCER_TURN",
    /** The candidate would replace or omit locally finalized history. */
    FINALITY_CONFLICT = "ERR_FINALITY_CONFLICT",
    NODE_NOT_REGISTERED = "ERR_NODE_NOT_REGISTERED",
    NODE_ALREADY_REGISTERED = "ERR_NODE_ALREADY_REGISTERED",
    NODE_WALLET_IN_USE = "ERR_NODE_WALLET_IN_USE",
    NODE_BAD_ENDPOINT = "ERR_NODE_BAD_ENDPOINT",
    NODE_HEARTBEAT_TOO_SOON = "ERR_NODE_HEARTBEAT_TOO_SOON",
    NODE_BAD_SUBJECT = "ERR_NODE_BAD_SUBJECT",
    NODE_ATTEST_LIMIT = "ERR_NODE_ATTEST_LIMIT",
    NODE_FAULT_LIMIT = "ERR_NODE_FAULT_LIMIT",
    NODE_WALLET_CHANGE_PENDING = "ERR_NODE_WALLET_CHANGE_PENDING",
    NODE_PROOF_EXPIRED = "ERR_NODE_PROOF_EXPIRED",
    VALIDATOR_BOND_MISMATCH = "ERR_VALIDATOR_BOND_MISMATCH",
    GAS_REQUIRED = "ERR_GAS_REQUIRED",
    INTERNAL = "ERR_INTERNAL",
    RATE_LIMITED = "ERR_RATE_LIMITED",
    NOT_FOUND = "ERR_NOT_FOUND"
}
export declare class ProtocolError extends Error {
    readonly code: ErrCode;
    readonly context?: Record<string, unknown> | undefined;
    constructor(code: ErrCode, message: string, context?: Record<string, unknown> | undefined);
}
export declare function reject(code: ErrCode, message: string, context?: Record<string, unknown>): never;
/** Human-readable explanation shown in the interface for each rejection. */
export declare const ERR_MESSAGES: Record<ErrCode, string>;
