/**
 * Hash domain separation tags.
 *
 * Each protocol object hashes over exactly one of these ASCII tags, so a
 * transaction id can never equal a block id, an address can never be reused as
 * a transaction hash, and cross-object replay of signatures is impossible.
 */
export declare const DOMAIN: {
    readonly BLOCK_HEADER: "OBSIDIAN:BLOCK_HEADER:v1";
    readonly BLOCK: "OBSIDIAN:BLOCK:v1";
    readonly TX: "OBSIDIAN:TX:v1";
    readonly TX_SIGNING: "OBSIDIAN:TX_SIGNING:v1";
    readonly MERKLE_LEAF: "OBSIDIAN:MERKLE_LEAF:v1";
    readonly MERKLE_NODE: "OBSIDIAN:MERKLE_NODE:v1";
    readonly STATE_ROOT: "OBSIDIAN:STATE_ROOT:v1";
    readonly GENESIS: "OBSIDIAN:GENESIS:v1";
    readonly GENESIS_ID: "OBSIDIAN:GENESIS_ID:v1";
    readonly PEER_HELLO: "OBSIDIAN:PEER_HELLO:v1";
    readonly PEER_ANNOUNCE: "OBSIDIAN:PEER_ANNOUNCE:v1";
    readonly NODE_METADATA: "OBSIDIAN:NODE_METADATA:v1";
    readonly ORACLE_PRICE: "OBSIDIAN:ORACLE_PRICE:v1";
    readonly ORACLE_ATTESTATION: "OBSIDIAN:ORACLE_ATTEST:v1";
    readonly AUCTION_BID: "OBSIDIAN:AUCTION_BID:v1";
    readonly RELEASE_SIGNATURE: "OBSIDIAN:RELEASE:v1";
    readonly API_TOKEN: "OBSIDIAN:API_TOKEN:v1";
    /** Node runner registration: proves the operator controls the reward wallet. */
    readonly NODE_REGISTRATION: "OBSIDIAN:NODE_REGISTRATION:v1";
    /** Reward wallet change: signed by the incoming wallet, delayed by a period. */
    readonly NODE_WALLET_CHANGE: "OBSIDIAN:NODE_WALLET_CHANGE:v1";
    /** Deregistration: releases the bond back to the reward wallet. */
    readonly NODE_DEREGISTRATION: "OBSIDIAN:NODE_DEREGISTRATION:v1";
    /** Liveness heartbeat signed by the node identity key. */
    readonly NODE_HEARTBEAT: "OBSIDIAN:NODE_HEARTBEAT:v1";
    /** Attestation signed by an observing node about another node. */
    readonly NODE_ATTESTATION: "OBSIDIAN:NODE_ATTESTATION:v1";
    /** Fault report signed by an observing node about another node. */
    readonly NODE_FAULT_REPORT: "OBSIDIAN:NODE_FAULT_REPORT:v1";
    /** Equal-membership bonded-validator checkpoint vote. */
    readonly FINALITY_VOTE: "OBSIDIAN:POT_FINALITY_VOTE:v1";
    /** Canonical hash of the finality validator committee. */
    readonly FINALITY_VALIDATOR_SET: "OBSIDIAN:FINALITY_VALIDATOR_SET:v1";
    /** Mining gate certificate: an issuer key vouches that one wallet may make one specific claim. */
    readonly MINING_GATE: "OBSIDIAN:MINING_GATE:v1";
    /** Canonical identity of equivocation evidence. */
    readonly EQUIVOCATION_EVIDENCE: "OBSIDIAN:EQUIVOCATION_EVIDENCE:v1";
};
export type DomainTag = (typeof DOMAIN)[keyof typeof DOMAIN];
