/**
 * Obsidian Core version metadata.
 *
 * Every official release publishes: Version, Protocol Version, Build ID,
 * SHA256, Release Signature, Supported Network, Minimum Core Version.
 * See /docs/release-process.md.
 */
/** Software version of this Obsidian Core build. */
export declare const CORE_VERSION = "1.7.0";
/** Consensus protocol version implemented by this build. */
export declare const PROTOCOL_VERSION = "1.7.0";
/**
 * Current lossless consensus-state snapshot format.
 *
 * 4 adds the committed mining-gate issuer keys (`miningGateKeys`); a 1.6.1 snapshot has none, and reading it as
 * "no keys" would be harmless but reading a 1.7 chain from it would not be meaningful, so it is refused.
 *
 * 3 adds the committed validator-mode indicator (`validatorModeEstablished`) and
 * the time-based jail term (`jailedUntilTime`). A snapshot written by 1.6.0 has
 * neither, so it is refused rather than silently read as "not established" —
 * reading an old snapshot as a new one would hand a bootstrapped chain back to
 * permissionless production.
 */
export declare const STATE_SNAPSHOT_VERSION = 4;
/** Wire/peer protocol version. */
export declare const WIRE_PROTOCOL_VERSION = 1;
/**
 * Minimum Obsidian Core version permitted to peer with this build.
 * Peers below this version are rejected during handshake (hard fork guard).
 *
 * 1.7.0 gates MINING_CLAIM behind a certificate signed by a genesis-committed issuer key, so a 1.6.1 peer (which
 * accepts claims from any key) is rejected: the two cannot agree on a chain.
 *
 * 1.6.1 changes consensus rules (validator admission mode, time-based jailing,
 * slash liability window, evidence budgets), so a 1.6.0 peer is rejected: two
 * nodes that share a protocol id but not a rule set cannot agree on a chain.
 */
export declare const MIN_CORE_VERSION = "1.7.0";
/**
 * Build identifier — deterministic hash of the release identity triple.
 * Uses the protocol's own SHA-256 implementation so this module is identical in
 * Node and in a browser bundle.
 */
export declare const BUILD_ID: string;
export interface VersionInfo {
    coreVersion: string;
    protocolVersion: string;
    wireProtocolVersion: number;
    minCoreVersion: string;
    buildId: string;
}
export declare function versionInfo(): VersionInfo;
/** Numeric comparison of dotted semantic versions. Returns -1 | 0 | 1. */
export declare function compareVersions(a: string, b: string): number;
