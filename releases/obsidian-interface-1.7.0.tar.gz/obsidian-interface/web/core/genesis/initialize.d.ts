/**
 * Genesis construction.
 *
 * Obsidian's genesis block contains NO allocation to any person, company or
 * founder wallet. The only issuance that ever becomes possible is the 100,000
 * OBS Genesis Allocation reserved for the first protocol-valid mining claim
 * (see genesis/rules.ts). The legacy 3,000,000 OBS allocation does not exist in
 * this codebase.
 *
 * The genesis document is a protocol constant: two nodes that build the same
 * document derive the same genesis id, the same genesis hash and therefore the
 * same network. A mismatch at startup is a hard refusal to start.
 */
import type { NetworkDefinition } from '../protocol/networks.js';
import type { Block } from '../protocol/types.js';
import { WorldState } from '../blockchain/state.js';
import { encodeEventForRoot } from '../blockchain/events.js';
import type { GenesisDocument } from '../blockchain/chain.js';
/**
 * Canonical mainnet genesis document. The timestamp is the Obsidian mainnet
 * genesis instant: 2026-01-01T00:00:00Z. It is a protocol constant, not a
 * deployment-time setting, because changing it changes every block hash.
 */
export declare const MAINNET_GENESIS_DOCUMENT: GenesisDocument;
export declare const TESTNET_GENESIS_DOCUMENT: GenesisDocument;
export declare function normalizeBootstrapValidatorPublicKeys(keys: readonly string[]): string[];
/**
 * Resolve the bootstrap committee for a network.
 *
 *   - A network with a committed set (mainnet, testnet) always uses it. An
 *     operator may pass the same list explicitly; passing a *different* list is
 *     a hard error rather than a silent fork, because it would produce a
 *     different genesis id while looking like the real network.
 *   - A network without a committed set (staging, devnet, a private chain) uses
 *     whatever the operator supplies. An empty list is allowed and means no
 *     finality bootstrap at all.
 */
export declare function resolveBootstrapValidatorKeys(net: NetworkDefinition, requested?: readonly string[]): string[];
export declare function normalizeMiningGatePublicKeys(keys: readonly string[]): string[];
/**
 * Resolve the mining gate issuer keys for a network. Same rule as the bootstrap committee: a committed list is the
 * only list (an operator may repeat it, never replace it); a network without one uses what the operator supplies; and
 * an empty result is legal but means no claim can be accepted.
 */
export declare function resolveMiningGateKeys(net: NetworkDefinition, requested?: readonly string[]): string[];
export declare function genesisDocumentFor(net: NetworkDefinition, bootstrapKeys?: readonly string[], miningGateKeys?: readonly string[]): GenesisDocument;
/** Deterministic genesis identifier: identifies the network, not a block. */
export declare function genesisId(document: GenesisDocument, net: NetworkDefinition): string;
/**
 * Build the genesis block. It has no transactions: there is no premine and no
 * registration reward. The state root of the empty initial state is committed.
 */
export declare function buildGenesisBlock(document: GenesisDocument, net: NetworkDefinition): Block;
/** The initial world state: zero accounts, zero supply, nothing minted. */
export declare function createGenesisState(block: Block, net: NetworkDefinition, bootstrapKeys?: readonly string[], miningGateKeys?: readonly string[]): WorldState;
/** Release checksum helper: SHA-256 of the genesis document + parameters. */
export declare function genesisFingerprint(document: GenesisDocument, net: NetworkDefinition): string;
export { encodeEventForRoot };
