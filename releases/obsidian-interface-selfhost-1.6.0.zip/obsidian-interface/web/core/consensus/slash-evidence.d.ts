/**
 * Equivocation evidence verification — the single path that decides whether a
 * slash may be applied.
 *
 * WHAT IS SLASHABLE, AND WHAT IS NOT
 *
 *   Only objectively provable double-signing by a validator that is bonded at
 *   the moment the evidence is applied:
 *
 *     - PROPOSER_EQUIVOCATION: one validator signed two different block headers
 *       for the same height *and the same round*. Two proposals in different
 *       rounds are legitimate (a slot can elapse and the turn move on), so the
 *       round is checked, not assumed.
 *     - VOTE_EQUIVOCATION: one validator signed two conflicting finality votes
 *       for the same finalized anchor — the exact conflict rule the node's own
 *       finality admission already uses.
 *
 *   Being offline, missing a slot, failing to vote, restarting or losing the
 *   network is NOT slashable. Those are handled by the missed-slot jail
 *   (transactions/executors/validator.ts), which costs time, not capital.
 *
 * THE EVIDENCE IS SELF-CONTAINED
 *
 *   Every honest node must reach the same verdict from the evidence and the
 *   chain state alone — no local observations, no "a node told me", no
 *   administrator. Signature verification, identity binding, domain binding and
 *   the conflict itself are all recomputed here.
 *
 *   Block headers do not carry their parent's timestamp, but the round is a
 *   function of it. A proposer evidence transaction therefore also carries both
 *   parent headers, bound to the children by
 *   `child.prevHash === blockHash(parent)`. A fabricated parent cannot satisfy
 *   that without finding a SHA-256 preimage, so a submitter can neither invent a
 *   round nor claim one that never existed.
 *
 *   Vote equivocation is verified against the local chain's genesis identity
 *   (recomputed from consensus state, never from the submitter) and against the
 *   running protocol version and params hash, so evidence from another network,
 *   another chain or another rule set cannot slash anyone here.
 *
 * IDEMPOTENCE
 *
 *   `state.s.slashes` is keyed by the canonical evidence id, and the validator's
 *   status becomes SLASHED. Replaying the same evidence — in another block, from
 *   another peer, after a restart — finds one of the two and is rejected. A
 *   second, genuinely different equivocation by the same validator at the same
 *   height is also rejected: one registration is slashed once.
 *
 * WHERE THE LIABILITY LIVES
 *
 *   The offence is charged to the registration, not to the address: an offence
 *   must fall inside `[registeredAtHeight, unbondingStartHeight]` of the record
 *   that holds the bond now (`WorldState.offenceChargesToCurrentRegistration`).
 *   Two consequences, both deliberate:
 *
 *     - unregistering does not escape the penalty. `UNBONDING`, `JAILED` and
 *       `ACTIVE` all still hold the escrowed bond, so the offence stays
 *       chargeable for the whole unbonding window; the offending validator
 *       cannot make the window run out, it can only start the clock;
 *     - a fresh registration cannot be charged for an earlier tenure. Claiming
 *       the remainder and registering again with a full bond is a new liability,
 *       so evidence about the old one is refused rather than confiscating an
 *       innocent bond that happens to reuse the same key.
 *
 *   Once the remainder has been claimed the registration is gone and the
 *   evidence is refused with NOT_FOUND — deterministically, on every node. That
 *   is the boundary of the mechanism: the window is the unbonding delay, and it
 *   is the protocol's only guarantee about how long a proven offence can still
 *   be charged (see the audit report, section I).
 */
import { ErrCode } from '../protocol/errors.js';
import type { SlashBody } from '../protocol/types.js';
import type { NetworkDefinition } from '../protocol/networks.js';
import type { WorldState } from '../blockchain/state.js';
/** Share of the bond a proven equivocation costs, in basis points. */
export declare const EQUIVOCATION_SLASH_BPS: 5000;
export interface VerifiedSlash {
    ok: true;
    evidenceId: string;
    type: 'PROPOSER_EQUIVOCATION' | 'VOTE_EQUIVOCATION';
    validator: string;
    /** Height of the equivocation (not of the block applying it). */
    height: number;
    round: number;
    bondBefore: bigint;
    /** Taken from the bond and credited to the Mining Pool. */
    amount: bigint;
    /** Still held by the validator, claimable after the unbonding delay. */
    remaining: bigint;
}
export interface SlashRejection {
    ok: false;
    code: ErrCode;
    message: string;
}
export type SlashVerification = VerifiedSlash | SlashRejection;
/**
 * Penalty for a proven equivocation: `bond × bps / 10_000`, integer-exact, with
 * the remainder staying with the validator. Nothing is hard-coded: the amount
 * follows the consensus ratio and the validator's own recorded bond, so a
 * submitter cannot name a number and a change to the ratio is a visible,
 * hash-committed protocol change.
 */
export declare function slashAmountFor(bond: bigint): bigint;
/** True when the two amounts re-add to the whole bond, with nothing lost. */
export declare function slashSumsBack(amount: bigint, remaining: bigint, bond: bigint): boolean;
/**
 * The genesis identity this chain is on, recomputed from consensus state.
 * A submitter never supplies it; a vote that names another network's genesis id
 * is therefore rejected here rather than trusted.
 */
export declare function genesisIdForState(state: WorldState, net: NetworkDefinition): string | null;
/**
 * The single authoritative verification path. Returns the exact amounts to
 * apply on success; every rejection carries the protocol error code the node
 * reports.
 */
export declare function verifyEquivocationEvidence(state: WorldState, net: NetworkDefinition, body: SlashBody, atHeight: number): SlashVerification;
