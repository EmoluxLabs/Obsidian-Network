# Verifying a release

Running software that will hold keys without checking where it came from is how
people lose money. This page is the short, complete procedure.

## 1. Get the archives and the checksums

Everything lives in `releases/`:

```
obsidian-core-1.0.0.zip / .tar.gz
obsidian-interface-1.0.0.zip / .tar.gz
obsidian-cloudflare-1.0.0.zip / .tar.gz
obsidian-node-operator-1.0.0.zip / .tar.gz
obsidian-interface-selfhost-1.0.0.zip / .tar.gz
obsidian-network-source-1.0.0.tar.gz
SHA256SUMS
MANIFEST.json          # version, commit, networks, protocol constants, asset sizes
RELEASE-NOTES-1.0.0.md
```

## 2. Check the digests

```bash
cd releases
sha256sum -c SHA256SUMS
```

Every line must read `OK`. Compare the digests against the values published in
`RELEASE-NOTES-1.0.0.md` for this version — a checksum file that travelled with
the archive proves integrity against corruption, not against tampering; comparing
against an independently published value is what closes that gap.

## 3. Confirm what build you have

```bash
cat MANIFEST.json | jq '{version, commit, protocolVersion, networks}'
```

`commit` names the exact source revision. `obsidian-network-source-<version>.tar.gz`
should contain that same tree.

## 4. Verify with the script

```bash
./verify-release.sh obsidian-core-1.0.0.tar.gz --with-tests
```

It refuses any archive that is not listed in `SHA256SUMS`, extracts into a
temporary directory (never over your working tree), checks entry points, and with
`--with-tests` runs the shipped suite. Nothing from the archive is executed before
that point.

## 5. Verify from source instead, if you prefer

```bash
tar -xzf obsidian-network-source-1.0.0.tar.gz
cd obsidian-network-1.0.0/obsidian-core
npm ci && npm run build && npm test        # 154 tests
cd ../obsidian-interface
npm ci && npm run build && npm test        # 61 tests
cd ../cloudflare
node --test test/worker.test.mjs           # 7 tests
cd ..
node --test tests/e2e/cluster.test.mjs     # 11 tests: three real nodes on one chain
```

The last command is the one that answers "is it a blockchain": it starts three
Obsidian Core nodes from the built output, chains them with seed peers, mines the
genesis claim, moves OBS, replays a transaction, publishes an oracle price and
registers a `.obs` name — then asserts that all three nodes independently agree.
It needs ports 39630-39635 free and takes about 40 seconds.

## 6. Run the packages, not just the tests

A build that compiles is not a deployment. The 1.0.0 archives were verified this
way, from an empty directory, and you can repeat it in a couple of minutes:

```bash
mkdir -p /tmp/obsidian-verify && cd /tmp/obsidian-verify
tar -xzf /path/to/obsidian-node-operator-1.0.0.tar.gz
cd obsidian-core && npm ci --omit=dev
OBSIDIAN_KEYSTORE_PASSPHRASE='choose-a-long-one' \
  node dist/index.js start --config config/devnet.json --data-dir ./data/devnet &
curl -s http://127.0.0.1:38630/health | jq '.status, .supplyOk, .genesisId'
curl -s http://127.0.0.1:38630/audit/compliance | jq -c 'to_entries[] | {(.key): .value.present}'
```

```bash
cd /tmp/obsidian-verify && tar -xzf /path/to/obsidian-interface-selfhost-1.0.0.tar.gz
cd obsidian-interface
node dist/server/main.js --nodes http://127.0.0.1:38630 --port 8788 &
curl -s http://127.0.0.1:8788/api/health | jq        # {"status":"ok","healthyNodes":1,...}
curl -s http://127.0.0.1:8788/mine/ | head -5        # the mine page, served from the package
curl -sI http://127.0.0.1:8788/js/explorer.js | head -3   # strict CSP on the bundle route
```

If the interface starts, you have a working reader; if the node answers `/health`
with `supplyOk: true`, you have a validator whose supply invariant holds.

## 7. Verify the chain you are about to trust

A binary that builds is not the same as a chain that behaves. After starting a
node, check the properties this project promises:

```bash
curl -s localhost:8630/audit/compliance | jq        # removed mechanisms absent
curl -s localhost:8630/params | jq '.maximumSupplyObs, .genesisAllocationObs'
curl -s localhost:8630/status | jq '{height, genesisId, paramsHash, supplyObs, networkId}'
curl -s localhost:8630/genesis | jq | head -40      # the document every node must match
```

Compare `genesisId` and `paramsHash` with another node on the same network — and
with the values in `MANIFEST.json` for the release you downloaded. A node whose
genesis id differs is on a different chain, and no amount of UI polish changes
that.

## 8. Verify node metadata signatures

Peers exchange signed descriptors (`OBSIDIAN:NODE_METADATA:v1`). A node will
refuse a descriptor whose signature does not verify against the identity key it
advertises, so a stranger cannot insert itself into your peer list as somebody
else. `GET /peers` shows the peers you are connected to; from a node binary:

```bash
node dist/index.js node --offline --log-level debug   # see handshake verification lines
```

## 9. What verification cannot tell you

* That the code is free of bugs. Read it, or pay someone to; the repository is
  small enough for a careful review of `src/blockchain`, `src/consensus` and
  `src/transactions`.
* That an operator running this software is honest. A node can lie to *you* about
  state; it cannot forge signatures, and two nodes that disagree are visible.
* That a Docker recipe works on your host. Run
  `deployment/docker/verify.sh` — it exists precisely because a Dockerfile is not
  evidence.
