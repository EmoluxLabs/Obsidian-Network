/**
 * Obsidian key management and addresses.
 *
 * Cryptographic choices (documented in /docs/cryptography.md):
 *   - Curve:        secp256k1 (the same curve family as Bitcoin/Ethereum, with
 *                   the widest library and hardware-wallet support).
 *   - Signatures:   ECDSA over secp256k1, RFC 6979 deterministic nonces,
 *                   64-byte compact r||s, low-S enforced.
 *   - Address:      bech32("obs", RIPEMD160(SHA256(compressed pubkey))).
 *   - Identifier:   bech32m("obs", payload) for names/parcels/capsules.
 *
 * No primitive here is invented by Obsidian: all are from @noble/curves and
 * @noble/hashes (audited, extensively fuzzed implementations).
 *
 * PRIVATE KEY HANDLING RULE
 * -------------------------
 * Keys are pure data in this module. This module MUST NOT log, serialize to
 * disk outside an explicit encrypted keystore, or transmit private key material
 * over the network. The node's own networking key is the only key Obsidian Core
 * persists, and it is always stored encrypted at rest (see crypto/keystore.ts).
 */
export declare const ADDRESS_HRP = "obs";
export declare const ID_HRP = "obsid";
export declare const PRIVATE_KEY_BYTES = 32;
export declare const PUBLIC_KEY_BYTES = 33;
export declare const SIGNATURE_BYTES = 64;
export interface KeyPair {
    /** 32-byte secp256k1 private key (hex). NEVER transmit or log. */
    privateKey: string;
    /** 33-byte compressed public key (hex). */
    publicKey: string;
    /** bech32 obs1... address derived from the public key. */
    address: string;
}
/**
 * Derive the canonical Obsidian address for a compressed public key.
 * address = bech32("obs", RIPEMD160(SHA256(pubkey)))
 */
export declare function addressFromPublicKey(publicKeyHex: string, hrp?: string): string;
/** True if `address` is a syntactically and checksum-valid obs1 address. */
export declare function isValidAddress(address: string, hrp?: string): boolean;
/** Decode an address to its 20-byte hash160 payload, or throw. */
export declare function addressPayload(address: string, hrp?: string): Uint8Array;
/**
 * Generate a cryptographically random secp256k1 key pair.
 *
 * SECURITY: the entropy source is the operating system CSPRNG
 * (node:crypto randomBytes). Wallet keys are NEVER derived from email, Google
 * ID, username, phone number, birth date, account ID, timestamp, or any other
 * predictable application value.
 */
export declare function generateKeyPair(): KeyPair;
export declare function keyPairFromPrivateKey(privateKey: Uint8Array | string): KeyPair;
export declare function isValidPrivateKey(bytes: Uint8Array): boolean;
/**
 * Sign a 32-byte digest. Deterministic (RFC 6979) so signatures are
 * reproducible, which makes the network's test suite bit-exact.
 */
export declare function signDigest(digest: Uint8Array, privateKeyHex: string): Uint8Array;
export declare function verifyDigest(digest: Uint8Array, signature: Uint8Array | string, publicKeyHex: string): boolean;
/** Sign an arbitrary domain-separated message (used by P2P handshakes). */
export declare function signMessage(domain: string, message: Uint8Array, privateKeyHex: string): string;
export declare function verifyMessage(domain: string, message: Uint8Array, signatureHex: string, publicKeyHex: string): boolean;
/** Derive a deterministic 33-byte node identity public key from a seed. */
export declare function nodeIdFromPublicKey(publicKeyHex: string): string;
/**
 * Random identifier. Uses WebCrypto when the runtime provides it (browsers and
 * Node >= 19 both expose `globalThis.crypto`), so the same code path serves the
 * node software and the browser wallet.
 */
export declare function randomId(): string;
/** 32 bytes of CSPRNG output as hex — used for nonces, salts, capsule keys. */
export declare function randomHex(bytes?: number): string;
export declare function publicKeysEqual(a: string, b: string): boolean;
/**
 * Verify that a signature was produced by the private key controlling
 * `address`. Used before any state change touches an account.
 */
export declare function verifyAddressSignature(address: string, digest: Uint8Array, signatureHex: string, publicKeyHex: string, hrp?: string): boolean;
