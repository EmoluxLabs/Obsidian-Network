// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  names(prefix = "") {
    return this.request(`/names${prefix ? `?prefix=${encodeURIComponent(prefix)}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  landCountries() {
    return this.request("/land/countries");
  }
  landDivisions(countryCode) {
    return this.request(`/land/divisions?country=${encodeURIComponent(countryCode)}`);
  }
  landSearch(query) {
    return this.request(`/land/search?q=${encodeURIComponent(query)}`);
  }
  landParcels(options = {}) {
    const query = new URLSearchParams();
    if (options.divisionId) query.set("divisionId", options.divisionId);
    if (options.owner) query.set("owner", options.owner);
    query.set("limit", String(options.limit ?? 25));
    return this.request(`/land/parcels?${query.toString()}`);
  }
  landParcel(parcelId) {
    return this.request(`/land/parcel/${encodeURIComponent(parcelId)}`);
  }
  landQuote(divisionId) {
    return this.request(`/land/quote/${encodeURIComponent(divisionId)}`);
  }
  capsules(options = {}) {
    const query = new URLSearchParams({ limit: String(options.limit ?? 25) });
    if (options.status) query.set("status", options.status);
    if (options.owner) query.set("owner", options.owner);
    return this.request(`/capsules?${query.toString()}`);
  }
  capsule(id) {
    return this.request(`/capsules/${encodeURIComponent(id)}`);
  }
  socialFeed(limit = 25) {
    return this.request(`/social/feed?limit=${limit}`);
  }
  socialProfile(accountId) {
    return this.request(`/social/profile/${encodeURIComponent(accountId)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  /**
   * Register. The response is the ONLY time the recovery codes exist — they
   * are not stored in recoverable form and can never be shown again.
   */
  register(input) {
    return api("/api/auth/register", { method: "POST", body: JSON.stringify(input) });
  },
  signIn(input) {
    return api("/api/auth/login", { method: "POST", body: JSON.stringify(input) });
  },
  startMfa() {
    return api("/api/auth/mfa/setup", { method: "POST", body: "{}" });
  },
  confirmMfa(totp) {
    return api("/api/auth/mfa/confirm", { method: "POST", body: JSON.stringify({ totp }) });
  },
  recover(input) {
    return api("/api/auth/recover", { method: "POST", body: JSON.stringify(input) });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  linkWallet(address) {
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "circle", href: "/circle/", label: "Circle", blurb: "Land registry" },
  { id: "capsule", href: "/capsule/", label: "Capsules", blurb: "Time locks" },
  { id: "social", href: "/social/", label: "Social", blurb: "OBS Social" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const nav = el(
    "nav",
    { class: "nav" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      accountSlot
    ),
    banner,
    nav
  );
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/pages/node.ts
var client = new ObsidianClient();
var economics = el("section", { class: "card" }, spinner("reading protocol revenue\u2026"));
var registry = el("section", { class: "card" }, spinner("reading the node registry\u2026"));
var settlements = el("section", { class: "card" }, spinner("reading settled reward periods\u2026"));
var lookupResult = el("div", {});
var lookupInput = el("input", {
  type: "text",
  id: "node-id",
  placeholder: "20 bytes of hex, printed by your node at startup",
  autocomplete: "off",
  spellcheck: "false",
  class: "mono"
});
var lookupForm = el(
  "form",
  { class: "stack" },
  el("label", { for: "node-id" }, "Node ID"),
  lookupInput,
  el("button", { type: "submit", class: "primary" }, "Look up this node")
);
function pct(bps) {
  return `${(bps / 100).toFixed(bps % 100 === 0 ? 0 : 2)}%`;
}
function scoreBar(label, bps, weightBps) {
  const width = Math.max(0, Math.min(100, bps / 100));
  return el(
    "div",
    { class: "score-row" },
    el("span", { class: "score-label" }, `${label} \xB7 ${pct(weightBps)} of the score`),
    el("span", { class: "score-track" }, el("span", { class: "score-fill", style: `width:${width}%` })),
    el("span", { class: "mono score-value" }, pct(bps))
  );
}
layout({
  current: "node",
  title: "Node runners",
  tagline: "40% of qualifying platform revenue, paid to the nodes that actually carry the network.",
  children: [
    el(
      "section",
      { class: "notice" },
      el("strong", {}, "Nothing on this page is self-reported. "),
      "A node cannot tell the protocol it was online: its uptime is counted from heartbeats that other registered nodes attested, ",
      "its participation from blocks the chain shows it produced, and its reliability from faults independent peers corroborated. ",
      "Every node recomputes the same score from the same evidence, which is why the payout can be verified without trusting this website."
    ),
    economics,
    settlements,
    el(
      "section",
      { class: "card" },
      el("h2", {}, "Look up a node"),
      el("p", { class: "muted" }, "Operators: paste your node id to see the evidence recorded about it in the current period."),
      lookupForm,
      lookupResult
    ),
    registry,
    el(
      "section",
      { class: "card" },
      el("h2", {}, "How to become a reward-eligible node"),
      el(
        "ol",
        { class: "steps" },
        el("li", {}, el("strong", {}, "Run Obsidian Core. "), "It generates a node identity key on first start and prints the node id."),
        el("li", {}, el("strong", {}, "Sync and peer. "), "A node that is behind or unreachable scores nothing, whatever it claims."),
        el(
          "li",
          {},
          el("strong", {}, "Register a reward wallet. "),
          "Your node signs a registration statement; the reward wallet signs the transaction and posts the bond. ",
          "That pair of signatures is what proves the operator controls both \u2014 nobody can point your wallet at their node, or their wallet at yours."
        ),
        el("li", {}, el("strong", {}, "Stay up. "), "Heartbeat each period, attest the peers you can see, and keep in sync."),
        el(
          "li",
          {},
          el("strong", {}, "Get paid. "),
          "At the end of each period the protocol settles inside a block \u2014 no service, no operator and no administrator has to run anything."
        )
      ),
      el(
        "p",
        { class: "muted" },
        "The bond is returned in full when you deregister. It exists so a Sybil fleet must fund every node it invents, ",
        "which is what lets the network stay open without an approval list."
      )
    )
  ]
});
function renderScore(status, scoring) {
  const score = status.score;
  return el(
    "div",
    { class: "stack" },
    el(
      "div",
      { class: "score-head" },
      el("span", { class: "mono big" }, pct(score.scoreBps)),
      score.eligible ? badge("eligible this period", "ok") : badge("not eligible this period", "warn")
    ),
    scoreBar("Uptime", score.uptimeBps, scoring.scoreWeights.uptimeBps),
    scoreBar("Participation", score.participationBps, scoring.scoreWeights.participationBps),
    scoreBar("Reliability", score.reliabilityBps, scoring.scoreWeights.reliabilityBps),
    scoreBar("Responsiveness", score.responsivenessBps, scoring.scoreWeights.responsivenessBps),
    score.reasons.length ? el("ul", { class: "reasons" }, ...score.reasons.map((reason) => el("li", {}, reason))) : el("p", { class: "muted" }, "The protocol recorded no penalties or shortfalls for this node in this period.")
  );
}
async function lookup(nodeId) {
  lookupResult.replaceChildren(spinner("reading this node\u2019s evidence\u2026"));
  try {
    const [status, rewards] = await Promise.all([client.nodeStatus(nodeId), client.nodeRewards(10)]);
    const settled = status.settledRewards;
    lookupResult.replaceChildren(
      el("h3", {}, "Identity"),
      kv([
        ["Node ID", el("span", { class: "mono" }, status.nodeId)],
        ["Reward wallet", el("span", { class: "mono" }, status.rewardWallet)],
        ["Registered", status.registered ? badge("yes", "ok") : badge(`deregistered at height ${status.deregisteredAtHeight}`, "warn")],
        ["Registered at height", String(status.registeredAtHeight)],
        ["Endpoint hint", status.endpoint ?? "\u2014 (an endpoint is a hint, never the identity)"],
        ["Bond held", obs(status.bondObs)],
        ["Lifetime rewards", obs(status.lifetimeRewardObs)],
        [
          "Pending wallet change",
          status.pendingWalletChange ? `${status.pendingWalletChange.wallet} \u2014 effective in period ${status.pendingWalletChange.effectivePeriod}` : "none"
        ]
      ]),
      el("h3", {}, `Score \u2014 period ${status.currentPeriod}`),
      renderScore(status, rewards.scoring),
      el("h3", {}, "Evidence the network recorded"),
      kv([
        ["Heartbeats", `${status.evidence.heartbeats} of ${status.evidence.expectedHeartbeats} expected`],
        [
          "Independent attesters",
          status.evidence.attesters.length ? el("span", { class: "mono" }, status.evidence.attesters.join(", ")) : "none yet \u2014 uptime cannot be credited without another node observing this one"
        ],
        ["Blocks produced", String(status.evidence.blocksProduced)],
        ["Peers this node attested", String(status.evidence.attestationsMade)],
        ["Faults reported against it", `${status.evidence.faults} (reporters: ${status.evidence.faultReporters.length || "none"})`],
        ["Heartbeats out of sync", String(status.evidence.staleHeartbeats)],
        ["Last reported height", String(status.evidence.lastReportedHeight)]
      ]),
      el("h3", {}, "Settled rewards"),
      settled.length ? table(
        ["Period", "Height", "Score", "Share", "Paid", "Wallet"],
        settled.map((entry) => [
          String(entry.period),
          String(entry.atHeight),
          pct(entry.scoreBps),
          pct(entry.shareBps),
          obs(entry.amountObs),
          el("span", { class: "mono" }, entry.rewardWallet)
        ])
      ) : el("p", { class: "muted" }, "No period has settled for this node yet."),
      el("p", { class: "muted" }, status.note)
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    lookupResult.replaceChildren(
      el("p", { class: "error" }, `Could not read that node: ${message}`),
      el("p", { class: "muted" }, "A node id is 40 hex characters. Unregistered nodes have no record until they register a reward wallet.")
    );
  }
}
lookupForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const value = lookupInput.value.trim().toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(value)) {
    toast("A node id is exactly 40 hexadecimal characters.", "error");
    return;
  }
  void lookup(value);
});
void (async () => {
  try {
    const [revenue, rewards] = await Promise.all([client.revenue(), client.nodeRewards(10)]);
    economics.replaceChildren(
      el("h2", {}, "Where platform revenue goes"),
      el(
        "div",
        { class: "split-flow" },
        el("div", { class: "flow-node" }, el("span", { class: "flow-label" }, "Qualifying platform revenue"), el("span", { class: "mono big" }, obs(revenue.qualifyingPlatformRevenueObs))),
        el(
          "div",
          { class: "flow-branches" },
          el(
            "div",
            { class: "flow-branch" },
            el("span", { class: "flow-share" }, pct(revenue.split.nodePoolBps)),
            el("span", { class: "flow-label" }, "Node Runner Reward Pool"),
            el("span", { class: "mono" }, obs(revenue.split.nodeRunnerPoolObs))
          ),
          el(
            "div",
            { class: "flow-branch" },
            el("span", { class: "flow-share" }, pct(revenue.split.treasuryBps)),
            el("span", { class: "flow-label" }, "Treasury wallet"),
            el("span", { class: "mono" }, obs(revenue.split.treasuryObs))
          )
        )
      ),
      kv([
        ["Split adds back to the whole", revenue.split.sumsBack ? badge("verified", "ok") : badge("MISMATCH \u2014 do not trust this node", "bad")],
        ["Pool balance now", obs(revenue.accounts.nodeRunnerPoolObs)],
        ["Bonds held for operators", obs(revenue.accounts.nodeBondsObs)],
        ["Mining Pool (gas, capsules, Time Travel)", obs(revenue.accounts.miningPoolObs)],
        ["Treasury wallet", revenue.accounts.treasuryWallet ? el("span", { class: "mono" }, revenue.accounts.treasuryWallet) : "not designated yet \u2014 the first valid mining claim designates it"],
        ["Revenue awaiting a treasury wallet", obs(revenue.accounts.unclaimedTreasuryRevenueObs)]
      ]),
      el("h3", {}, "By source"),
      revenue.bySource.length ? table(["Source", "Lifetime"], revenue.bySource.map((entry) => [el("span", { class: "mono" }, entry.source), obs(entry.totalObs)])) : el("p", { class: "muted" }, "No qualifying platform revenue has been recorded on this chain yet."),
      el("h3", {}, "What is deliberately NOT platform revenue"),
      table(
        ["Flow", "Why it is excluded"],
        revenue.notPlatformRevenue.map((entry) => [entry.kind, entry.because])
      ),
      el("p", { class: "muted" }, `${revenue.gas.note} Lifetime gas to the Mining Pool: ${revenue.gas.lifetimeObs} OBS.`)
    );
    settlements.replaceChildren(
      el("h2", {}, "Settled reward periods"),
      kv([
        ["Current period", String(rewards.pool.currentPeriod)],
        ["Last settled period", rewards.pool.lastSettledPeriod ? String(rewards.pool.lastSettledPeriod) : "none yet"],
        ["Period length", `${rewards.pool.periodSeconds / 3600} hours of protocol time`],
        ["Paid out so far", obs(rewards.pool.lifetimeDistributedObs)],
        ["Maximum one node may take from a period", pct(rewards.scoring.maxNodeShareBps)],
        ["Minimum uptime to earn", pct(rewards.scoring.minUptimeBps)],
        ["Independent attesters required", String(rewards.scoring.minAttesters)],
        ["Reward wallet changes take effect after", `${rewards.scoring.walletChangeDelayPeriods} period(s)`]
      ]),
      rewards.settlements.length ? el(
        "div",
        {},
        ...rewards.settlements.map(
          (settlement) => el(
            "div",
            { class: "settlement" },
            el("h3", {}, `Period ${settlement.period}`),
            kv([
              ["Settled at height", String(settlement.atHeight)],
              ["Pool at settlement", obs(settlement.poolObs)],
              ["Distributed", obs(settlement.distributedObs)],
              ["Carried to the next period", obs(settlement.carriedObs)],
              ["Nodes paid", `${settlement.eligibleNodes} of ${settlement.scoredNodes} scored`]
            ]),
            settlement.payouts.length ? table(
              ["Node", "Wallet", "Score", "Share", "Paid"],
              settlement.payouts.map((payout) => [
                el("span", { class: "mono" }, payout.nodeId),
                el("span", { class: "mono" }, payout.rewardWallet),
                pct(payout.scoreBps),
                pct(payout.shareBps),
                obs(payout.amountObs)
              ])
            ) : el("p", { class: "muted" }, "No node qualified in this period; the whole pool was carried forward.")
          )
        )
      ) : el("p", { class: "muted" }, "No reward period has closed on this chain yet. Settlement happens inside a block, with no operator involved.")
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    economics.replaceChildren(el("p", { class: "error" }, `Could not read the reward economics: ${message}`));
    settlements.replaceChildren(el("p", { class: "muted" }, "Settlement history is unavailable while the node is unreachable."));
  }
  try {
    const response = await client.nodeRegistry(100);
    registry.replaceChildren(
      el("h2", {}, `Registered nodes (${response.registeredNodes})`),
      response.nodes.length ? table(
        ["Node", "Reward wallet", "Heartbeats", "Attesters", "Blocks", "Attested", "Faults", "Bond"],
        response.nodes.map((node) => [
          el("span", { class: "mono" }, node.nodeId),
          el("span", { class: "mono" }, node.rewardWallet),
          String(node.currentPeriod.heartbeats),
          String(node.currentPeriod.attesters),
          String(node.currentPeriod.blocksProduced),
          String(node.currentPeriod.attestationsMade),
          node.currentPeriod.faults > 0 ? badge(String(node.currentPeriod.faults), "warn") : "0",
          obs(node.bondObs)
        ])
      ) : el("p", { class: "muted" }, "No node runner has registered a reward wallet on this chain yet."),
      el("p", { class: "muted" }, response.note)
    );
  } catch (error) {
    const message = error instanceof ChainError ? error.message : String(error);
    registry.replaceChildren(el("p", { class: "error" }, `Could not read the node registry: ${message}`));
  }
})();
//# sourceMappingURL=node.js.map
