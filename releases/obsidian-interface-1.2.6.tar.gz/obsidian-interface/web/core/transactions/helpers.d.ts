/**
 * Shared executor helpers: gas, oracle price access, address checks.
 *
 * These functions are consensus-critical and therefore pure and deterministic.
 */
import type { NetworkDefinition } from '../protocol/networks.js';
import type { WorldState } from '../blockchain/state.js';
import { ONE_DAY } from './time.js';
/**
 * Protocol gas: 0.02% of the transferred OBS, capped at 0.01 OBS.
 * Integer-only so every node computes the identical number.
 */
export declare function expectedGas(base: bigint): bigint;
/** Reject a transaction that does not carry exactly the protocol gas. */
export declare function assertGas(provided: bigint, base: bigint): bigint;
export declare function assertAmount(amount: bigint, { allowZero, label }?: {
    allowZero?: boolean | undefined;
    label?: string | undefined;
}): void;
export declare function assertAddress(address: string, net: NetworkDefinition, label?: string): void;
export interface OraclePrice {
    /** Micro-USD per OBS (1e-6 USD units). */
    priceUsdMicro: bigint;
    updatedAt: number;
    sourceCount: number;
}
/**
 * Read the protocol price used to convert USD-denominated features into OBS.
 * Fails closed: a stale or absent price rejects the transaction rather than
 * inventing a value, so an oracle outage can never corrupt consensus state.
 */
export declare function requirePrice(state: WorldState, protocolTime: number): OraclePrice;
/**
 * Convert a USD micro-unit amount into OBS seals, rounding UP.
 * Rounding up guarantees the protocol/network side is never under-paid, and it
 * is deterministic in integer arithmetic.
 */
export declare function usdMicroToSeals(usdMicro: bigint, priceUsdMicro: bigint): bigint;
/** Convert OBS seals into USD micro-units, rounding down (conservative). */
export declare function sealsToUsdMicro(seals: bigint, priceUsdMicro: bigint): bigint;
/** Split an amount by basis points with the protocol's rounding rule. */
export declare function splitBps(amount: bigint, bps: number): bigint;
export { ONE_DAY };
