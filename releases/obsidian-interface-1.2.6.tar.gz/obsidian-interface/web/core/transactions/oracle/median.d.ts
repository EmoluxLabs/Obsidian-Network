/**
 * Median aggregation for the protocol price oracle.
 *
 * Deterministic rules:
 *   - only observations inside the freshness window are counted;
 *   - the median of the accepted prices is the protocol price;
 *   - with fewer than params.oracle.minSources fresh observations the feed is
 *     marked stale and medianPriceUsdMicro is left at its previous value (it is
 *     never zeroed, so historical state roots stay reproducible).
 */
import type { MutableState } from '../../blockchain/state.js';
export interface MedianResult {
    medianPriceUsdMicro: bigint;
    medianUpdatedAt: number;
    sourceCount: number;
    stale: boolean;
    sources: string[];
}
export declare function recomputeMedian(state: MutableState, protocolTime: number): MedianResult;
/** True when the stored price may be used for a USD-priced feature. */
export declare function priceIsUsable(state: MutableState, protocolTime: number): boolean;
