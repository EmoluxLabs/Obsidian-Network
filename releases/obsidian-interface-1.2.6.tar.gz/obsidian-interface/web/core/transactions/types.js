/**
 * Executor context and dispatch contract.
 *
 * Every transaction type implements the same signature so the state machine can
 * treat them uniformly and so "unknown type" can never silently no-op.
 */
export {};
//# sourceMappingURL=types.js.map