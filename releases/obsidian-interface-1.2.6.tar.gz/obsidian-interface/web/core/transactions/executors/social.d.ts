/**
 * SOCIAL — OBS Social on-chain state (spec §33–§38).
 *
 * What lives on-chain: identity handles, follow graph counters, posts (content
 * hash + body), tips, business-page activations, verification tiers, creator
 * monetisation eligibility and the 70/30 creator revenue split.
 *
 * What stays off-chain: the feed cache, search indexes, notifications, media.
 * Those are caches; the blockchain is the record.
 *
 * Wallet rules: tips and payments are direct OBS transfers between user
 * wallets. The protocol never creates an "internal balance" and never lets a
 * database become the source of truth for money.
 */
import { type SocialBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeSocialBody(body: Uint8Array): SocialBody;
export declare function encodeSocialBody(body: SocialBody): Uint8Array;
/** Deterministic post id: content-addressed, so edits and forks are visible. */
export declare function computePostId(authorAddress: string, accountId: string, content: string, parentPostId: string, nonce: number): string;
export declare function executeSocial(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * Creator view revenue distribution (spec §36): 70% to the creator's wallet,
 * 30% to the Obsidian Network treasury wallet. Paid in a normal signed
 * transaction; the payer's funds are never routed anywhere else, and the split
 * only applies once the creator meets the published eligibility thresholds.
 */
export declare function executeViewRevenue(ctx: ExecutorContext, tx: TxEnvelope, creatorAccountId: string, amount: bigint): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
export declare function avatarDigest(value: string): string;
