/**
 * ONS — Obsidian Name Service (spec §39).
 *
 * A `.obs` name maps to exactly one wallet address at a time and the mapping is
 * blockchain state, not a database row. Names are priced in USD and paid in OBS
 * at a fixed OBS price; the fee is protocol revenue and is remitted to
 * the designated treasury wallet on-chain (it cannot be minted, and the
 * treasury cannot change except by the protocol rule).
 *
 * Registration is a commitment: anyone may register an available name, and
 * ownership can be transferred or sold according to protocol rules.
 */
import { type OnsBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeOnsBody(body: Uint8Array): OnsBody;
export declare function encodeOnsBody(body: OnsBody): Uint8Array;
export declare function normalizeName(raw: string): string;
export declare function validateNameFormat(name: string): void;
/**
 * The protocol fee for a name, in seals.
 *
 * Fees are denominated in OBS, so this is a constant lookup: no oracle, no
 * staleness window, no way for an absent price feed to make registration
 * impossible. The signature keeps `state`/`protocolTime` so callers and future
 * term-dependent pricing need not change shape.
 */
export declare function requiredFeeSeals(_state: ExecutorContext['state'], _protocolTime: number, feeSeals: bigint): bigint;
/** Registration is never allowed to silently renew an existing name. */
export declare function executeOns(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * Expire names whose term has ended. Called once per block by the state
 * machine: deterministic, height-derived, and never driven by an external
 * scheduler. Expired names return to the pool for re-registration.
 */
export declare function processNameExpiry(ctx: ExecutorContext): void;
