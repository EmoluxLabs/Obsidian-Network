/**
 * CAPSULE — the Obsidian Time Capsule Wall (spec §41–§44).
 *
 * Model
 *   - A capsule commits to an encrypted payload (never stored in plaintext on
 *     chain) and locks a creator commitment of at least 0.0001 OBS.
 *   - The locked commitment is NOT a balance: it is removed from circulation
 *     into the capsule and counted by the supply invariant while LOCKED.
 *   - At the exact unlock protocol time the commitment is transferred to the
 *     Mining Pool automatically, by state transition, with no action required
 *     from the creator — it works even if the creator is offline forever.
 *   - Each account may Time Travel a given capsule exactly once, paying
 *     1000 x creator commitment, which goes entirely to the Mining Pool.
 *
 * Honest limitation (documented in /docs/time-capsule.md): the protocol can
 * release only data that needs no online party. The creator therefore publishes
 * a teaser at creation, and the *Time Travel gate* is a protocol-recorded,
 * paid access right. Genuinely secret content stays inside the encrypted
 * payload and is released by a REVEAL transaction only at or after unlockAt,
 * which the protocol rejects before that time.
 */
import { type CapsuleBody, type CapsuleRecord, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeCapsuleBody(body: Uint8Array): CapsuleBody;
export declare function encodeCapsuleBody(body: CapsuleBody): Uint8Array;
/**
 * Canonical capsule id. Deterministic from (owner, contentCommitment, unlockAt,
 * contentNonce) so no attacker can mint a colliding or spoofed id.
 */
export declare function computeCapsuleId(owner: string, contentCommitment: string, unlockAt: number, contentNonce: string): string;
export declare function isCapsuleId(value: string): boolean;
export declare function executeCapsule(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * Deterministic per-block unlock routine, executed by the state machine for
 * every block: any LOCKED capsule whose unlockAt has arrived flips to UNLOCKED
 * and its commitment is transferred to the Mining Pool. No transaction, no
 * owner action and no scheduler are involved — the block itself is the trigger.
 */
export declare function processCapsuleUnlocks(ctx: ExecutorContext): void;
export declare function capsuleTeaser(capsule: CapsuleRecord): string | null;
export declare function capsuleIdHash(capsuleId: string): string;
