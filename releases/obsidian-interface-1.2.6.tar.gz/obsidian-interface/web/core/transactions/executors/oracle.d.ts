/**
 * ORACLE — the protocol price feed for USD-denominated features.
 *
 * Design goals (spec §30, §76):
 *   - No single external API can become a hidden consensus authority.
 *   - Outliers are rejected, not averaged in.
 *   - A stale feed fails closed: USD-priced features are refused rather than
 *     priced with invented data, so an outage can never corrupt state.
 *   - Prices move in bounded steps, so a compromised source cannot reprice the
 *     whole ecosystem in one block.
 *
 * The median of all accepted sources is the protocol price. Each source
 * contributes at most one observation, and an observation is accepted only if:
 *   1. the source id is well-formed;
 *   2. the reported timestamp is not in the future and not older than
 *      params.oracle.maxSourceAgeSeconds;
 *   3. the price is inside the absolute protocol bounds;
 *   4. if a median already exists, the price is within
 *      params.oracle.maxDeviationFromPreviousBps of it;
 *   5. the submitting account has not submitted an oracle update in the last
 *      oracle.submissionCooldownBlocks blocks (deterministic anti-spam).
 */
import type { OracleBody, TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
/** Deterministic oracle submission cooldown, in blocks. */
export declare const ORACLE_SUBMISSION_COOLDOWN_BLOCKS = 100;
export declare function decodeOracleBody(body: Uint8Array): OracleBody;
export declare function encodeOracleBody(body: OracleBody): Uint8Array;
export interface AcceptedObservation {
    source: string;
    priceUsdMicro: bigint;
    observedAt: number;
}
export declare function executeOracle(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
