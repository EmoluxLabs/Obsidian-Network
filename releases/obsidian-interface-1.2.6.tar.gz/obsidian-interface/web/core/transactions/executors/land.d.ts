/**
 * LAND — Obsidian Circle, the blockchain land registry (spec §45–§56).
 *
 * Two distinct markets exist and must never be confused:
 *
 *  1. PROTOCOL MARKET (PROTOCOL_BUY / PROTOCOL_SELL)
 *     The protocol issues or buys back exactly ONE square metre per transaction
 *     — multiple purchases must be separate transactions, each recomputing GLV
 *     before the next, so no single transaction can bypass the value sequence.
 *     GLV (official Global Location Value) is the price. A purchase raises the
 *     division's GLV; a buyback lowers it.
 *
 *  2. USER MARKETPLACE (LIST / DELIST / BUY_LISTED / GIFT)
 *     Owners set an MSP (asking price in OBS). Trading at MSP establishes the
 *     parcel's ILV as protocol state and never changes GLV. Gifting transfers
 *     ownership and charges standard gas.
 *
 * PARCEL IDENTITY
 *   Parcels are content-addressed: parcelId = bech32m("obsid",
 *   SHA-256("PARCEL|division|level|subId|plotIndex")). Transactions carry the
 *   human-readable descriptor and every node re-derives the id, so a caller can
 *   never fabricate or alias a parcel.
 */
import { type LandBody, type ParcelRecord, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeLandBody(body: Uint8Array): LandBody;
export declare function encodeLandBody(body: LandBody): Uint8Array;
/** Canonical, content-addressed parcel identity. */
export declare function computeParcelId(body: Pick<LandBody, 'divisionId' | 'level' | 'subId' | 'plotIndex'>): string;
/** Public helper used by the RPC layer and tests. */
export declare function parcelOfficialValue(parcel: ParcelRecord, divisionGlv: bigint, divisionPurchases: number): bigint;
export declare function executeLand(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
