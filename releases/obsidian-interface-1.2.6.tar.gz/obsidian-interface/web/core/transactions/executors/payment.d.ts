/**
 * PAYMENT — value transfer between wallets.
 *
 * Rules:
 *   - amount > 0 and >= the protocol dust minimum;
 *   - gas must equal min(0.02% of amount, 0.01 OBS);
 *   - sender balance must cover amount + gas (no negative balances, ever);
 *   - gas is remitted to the Mining Pool;
 *   - the recipient's address must be valid for this network's HRP.
 */
import type { TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export interface PaymentDecoded {
    to: string;
    amount: bigint;
    memo?: string;
}
export declare function decodePaymentBody(body: Uint8Array): PaymentDecoded;
export declare function encodePaymentBody(body: PaymentDecoded): Uint8Array;
export declare function paymentBaseAmount(decoded: PaymentDecoded): bigint;
export declare function executePayment(ctx: ExecutorContext, tx: TxEnvelope): void;
