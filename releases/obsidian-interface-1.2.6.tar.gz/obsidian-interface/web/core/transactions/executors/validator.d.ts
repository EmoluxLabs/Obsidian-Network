/**
 * VALIDATOR — registration and bonding for consensus participation.
 *
 * A validator bonds at least params.consensus.minValidatorBond OBS. Bonded OBS
 * is locked value: it leaves the spendable balance, and it is counted by the
 * supply invariant while bonded. Unbonding takes params.consensus.unbondingBlocks
 * blocks, after which the bond returns to the owner's balance.
 *
 * Bonded stake is the *only* role it plays here: it does not vote on consensus
 * outcomes, and no validator can mint, alter balances, or rewrite history. It
 * establishes who may propose blocks in rotation (see consensus/proposer.ts).
 */
import { type TxEnvelope, type ValidatorBody } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeValidatorBody(body: Uint8Array): ValidatorBody;
export declare function encodeValidatorBody(body: ValidatorBody): Uint8Array;
export declare function executeValidator(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * Per-block validator bookkeeping: jail validators that miss too many slots in
 * a rolling window and release jails whose term has ended. Deterministic and
 * height-driven — no administrator, no dashboard action.
 */
export declare function processValidatorBookkeeping(ctx: ExecutorContext, missedBy: string[]): void;
