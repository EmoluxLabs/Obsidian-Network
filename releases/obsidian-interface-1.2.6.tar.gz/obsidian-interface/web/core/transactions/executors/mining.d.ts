/**
 * MINING_CLAIM — the protocol-authoritative mining mechanism (spec §21–§27).
 *
 * Determinism: the reward is derived from (activeMiners at this height,
 * protocol schedule constants) and the eligibility window from the including
 * block's timestamp. Nothing in this executor reads a wall clock, a request
 * header, or any client-provided timestamp.
 *
 * Settlement: a valid claim pays immediately
 *      pool funds first  ->  scheduled issuance for the remainder
 * so the reward schedule is stable while gas recycled into the Mining Pool is
 * spent on real mining rewards before new OBS is ever minted.
 *
 * Genesis: if the allocation is still unclaimed, THIS transaction (in canonical
 * block order) wins it. See genesis/rules.ts for the atomicity argument.
 */
import type { MiningClaimBody, TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
/** Cap on the audit history of pool distributions kept inside state. */
export declare const POOL_DISTRIBUTION_HISTORY = 256;
export declare function decodeMiningBody(body: Uint8Array): MiningClaimBody;
export declare function encodeMiningBody(body: MiningClaimBody): Uint8Array;
/**
 * Canonical claim id. Binding the id to chain, wallet, sequence and the
 * previous claim height makes every claim unique, unforgeable and impossible to
 * replay — the same computed id can only ever be accepted once.
 */
export declare function computeClaimId(chainId: number, address: string, claimSequence: number, lastClaimHeight: number): string;
export declare function executeMiningClaim(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
