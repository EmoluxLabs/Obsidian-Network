/**
 * Transaction dispatch.
 *
 * The state machine calls exactly one executor per transaction type, and an
 * unknown type is a hard rejection — never a silent no-op. Fees/limits that
 * apply to every type are enforced in the state machine (nonce, replay, size),
 * while type-specific rules live in each executor.
 */
import { TxType, type TxEnvelope } from '../protocol/types.js';
import type { ExecutorContext, ExecutorResult } from './types.js';
export declare function executeTransaction(ctx: ExecutorContext, tx: TxEnvelope): ExecutorResult;
export { TxType };
export type { ExecutorContext, ExecutorResult };
