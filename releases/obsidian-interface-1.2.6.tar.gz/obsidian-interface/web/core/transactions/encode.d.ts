/**
 * Transaction canonical encoding, hashing, signing and verification.
 *
 * A transaction is the only object that can change protocol state, so its
 * encoding is the most security-relevant code in the node.
 *
 * Signing preimage:  H(TX_SIGNING | chainId | nonce | type | gas | validUntil |
 *                       sender | memo | body)
 * Transaction id:    H(TX | signed-preimage-bytes | publicKey | signature)
 *
 * Consequences:
 *   - The chain ID is inside the signed preimage, so a mainnet transaction can
 *     never be replayed on testnet or on a fork of a different network.
 *   - The nonce is inside the preimage, so a transaction cannot be re-signed
 *     onto another position in the account's sequence.
 *   - The transaction id commits to the signature, so two different signatures
 *     over the same body produce two different ids (no malleability collapse)
 *     while low-S enforcement removes the usual ECDSA malleability vector.
 */
import { Reader, Writer } from '../protocol/encoding.js';
import { TxType, type TxEnvelope, type TxSignature } from '../protocol/types.js';
export interface UnsignedTx {
    protocolVersion: string;
    chainId: number;
    sender: string;
    nonce: number;
    type: TxType;
    gas: bigint;
    body: Uint8Array;
    memo?: string;
    validUntil: number;
}
export declare function signingDigest(tx: UnsignedTx): Uint8Array;
export declare function encodeSignedTx(tx: TxEnvelope): Uint8Array;
export declare function encodeTxForRoot(tx: TxEnvelope): Uint8Array;
export declare function computeTxId(tx: UnsignedTx, signature: TxSignature): string;
/** Deterministic transaction id given a signed envelope. */
export declare function txIdOf(tx: TxEnvelope): string;
export interface SignTxOptions {
    sender: string;
    privateKeyHex: string;
    publicKeyHex: string;
    chainId: number;
    protocolVersion: string;
    nonce: number;
    type: TxType;
    gas: bigint;
    body: Uint8Array;
    memo?: string;
    validUntil: number;
}
export declare function signTransaction(options: SignTxOptions): TxEnvelope;
export interface TxValidationContext {
    chainId: number;
    supportedProtocolVersions: string[];
    /** Protocol time of the block that would include the transaction. */
    protocolTime: number;
    /** Account nonce expected next, if the sender account exists. */
    expectedNonce: number;
    /** Height of the block that would include the transaction. */
    height: number;
    /**
     * Address human-readable part of the network (obs on mainnet, dobs on devnet,
     * ...). Signatures are verified against the address of THIS network, so a
     * mainnet transaction can never be replayed on another Obsidian network.
     */
    addressHrp?: string;
}
/**
 * Structural validation. Runs before any state is touched: encoding, version,
 * chain id, size, expiry, signature and nonce. State-dependent checks (balance,
 * type-specific rules) run in the executors.
 */
export declare function validateTxStructure(tx: TxEnvelope, ctx: TxValidationContext): void;
/** Decode canonical signed bytes back into an envelope (p2p / block sync). */
export declare function decodeSignedTx(r: Reader): TxEnvelope;
export declare function decodeSignedTxFromBytes(bytes: Uint8Array): TxEnvelope;
export declare function encodeBody(fn: (w: Writer) => void): Uint8Array;
