/**
 * Economic accounting — the one place that says where money may go.
 *
 * THE RULE
 *   Every OBS in the system belongs to exactly one accounting category, and no
 *   transition may move value between categories except along the paths declared
 *   here. This file is the declaration; the executors are the enforcement.
 *
 * WHY IT EXISTS
 *   A blockchain can be perfectly consensus-correct and still be economically
 *   dishonest: revenue quietly routed to the wrong wallet, a fee counted twice,
 *   escrow spent as if it were income. Splitting the categories and writing them
 *   down makes that class of bug a failing test instead of a slow leak.
 *
 * CATEGORIES
 *   MINING_POOL        protocol-owned; gas, capsule commitments, Time Travel
 *                      revenue and other protocol inflows are distributed to
 *                      miners by the mining schedule. Never platform income.
 *   TREASURY           60% of qualifying platform revenue, sent to the wallet
 *                      designated on-chain by the genesis rule.
 *   NODE_RUNNER_POOL   40% of qualifying platform revenue, held for the node
 *                      runner reward settlement (see src/economy/node-rewards.ts).
 *   USER_FUNDS         balances owned by users. Never platform revenue, never a
 *                      destination for protocol revenue.
 *   CREATOR_FUNDS      the creator share of platform-monetised activity, paid
 *                      straight to the creator's own balance.
 *   MARKETPLACE_ESCROW value held for a specific counterparty (a land sale
 *                      between two users, a tipping balance in flight). Owned by
 *                      users, not by the protocol.
 *   UNCLAIMED_REVENUE  qualifying platform revenue received before the genesis
 *                      allocation designates a treasury wallet. Held in the
 *                      Mining Pool as protocol value and *recorded* as unclaimed
 *                      so no node can treat it as income; the recorded source
 *                      decides its destination once the designation exists.
 *
 * WHAT IS NOT PLATFORM REVENUE
 *   user-to-user transfers, mining rewards, capsule commitments and Time Travel
 *   payments, gas, validator bonds, marketplace sale proceeds, tips and any
 *   escrowed balance. Those are enumerated in NOT_PLATFORM_REVENUE below and
 *   asserted by tests.
 */
import type { TxType } from '../protocol/types.js';
export declare enum AccountingCategory {
    MINING_POOL = "MINING_POOL",
    TREASURY = "TREASURY",
    NODE_RUNNER_POOL = "NODE_RUNNER_POOL",
    USER_FUNDS = "USER_FUNDS",
    CREATOR_FUNDS = "CREATOR_FUNDS",
    MARKETPLACE_ESCROW = "MARKETPLACE_ESCROW",
    UNCLAIMED_REVENUE = "UNCLAIMED_REVENUE"
}
/**
 * Why a payment is platform revenue. The reason is stored on-chain with the
 * split event, so an auditor can classify every basis point from chain data
 * alone instead of trusting this file's intent.
 */
export declare enum RevenueSource {
    /** A `.obs` name registration. */
    ONS_REGISTRATION = "ONS_REGISTRATION",
    /** A `.obs` name renewal. */
    ONS_RENEWAL = "ONS_RENEWAL",
    /** A business page: the platform's $50-equivalent page fee. */
    BUSINESS_PAGE = "BUSINESS_PAGE",
    /** An explicit treasury revenue payment signed by a platform wallet. */
    EXPLICIT_PAYMENT = "EXPLICIT_PAYMENT",
    /**
     * Land released by the protocol market. Protocol-issued land revenue is
     * classified as qualifying platform revenue: the protocol is the seller and
     * the treasury buys land back from owners, so the two flows belong in one
     * account. Buy-backs move *treasury* funds to the owner and are not revenue.
     */
    LAND_PROTOCOL_SALE = "LAND_PROTOCOL_SALE"
}
/** Value that is explicitly NOT platform revenue, with the reason attached. */
export declare const NOT_PLATFORM_REVENUE: ReadonlyArray<{
    txType: TxType;
    name: string;
    because: string;
}>;
export interface RevenueSplit {
    /** Total qualifying platform revenue received. */
    total: bigint;
    /** 40% → Node Runner Reward Pool. */
    nodeRunnerPool: bigint;
    /** 60% → treasury wallet (or the unclaimed account before designation). */
    treasury: bigint;
    /** Always 10_000; carried so consumers can print the split without guessing. */
    totalBps: number;
    nodePoolBps: number;
    treasuryBps: number;
}
/**
 * Split qualifying platform revenue with exact integer arithmetic.
 *
 * `nodePool = floor(total * nodePoolBps / 10_000)` and `treasury = total -
 * nodePool`, so the parts always add back to the whole. Flooring in favour of
 * the treasury is deliberate: the last seal can never be lost to rounding, and
 * the treasury is the account that pays it back out through buy-backs.
 */
export declare function splitPlatformRevenue(total: bigint, source: RevenueSource): RevenueSplit;
/** The invariant every route that credits platform revenue must satisfy. */
export declare function assertSplitInvariant(split: RevenueSplit): void;
