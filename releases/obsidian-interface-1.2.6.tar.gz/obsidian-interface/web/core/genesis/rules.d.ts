/**
 * Genesis Allocation rules (spec §10–§13).
 *
 * THE RULE
 *   - Allocation size: exactly 100,000 OBS, issued ONCE.
 *   - It is NOT granted at registration. A newly registered account holds 0 OBS.
 *   - It is granted to the wallet attached to the FIRST protocol-valid mining
 *     claim accepted by consensus, in canonical block order, and never again.
 *   - Once granted, that wallet becomes the protocol treasury wallet.
 *
 * ATOMICITY
 *   The transition genesis.allocationClaimed false -> true happens inside the
 *   state transition of one transaction in one block, under the same
 *   deterministic execution that every node replays. Two wallets cannot both
 *   receive it: whichever block becomes canonical defines the winner, and every
 *   node recomputes that block's state from scratch during reorgs.
 *
 * WHAT CAN NEVER DETERMINE THE WINNER
 *   frontend timestamps, server timestamps, browser clocks, database insertion
 *   order, Google account age, email verification time, administrator choice.
 */
import type { WorldState, ApplyContext } from '../blockchain/state.js';
export declare const GENESIS_ALLOCATION_AMOUNT: bigint;
/** The legacy 3,000,000 OBS allocation must never be issued again. */
export declare const LEGACY_GENESIS_ALLOCATION: 0n;
export interface GenesisOutcome {
    awarded: boolean;
    recipient: string;
    amount: bigint;
    reason: string;
}
/**
 * Attempt to award the Genesis Allocation to `claimant`.
 * Returns awarded=false when the allocation was already taken (normal case).
 * Throws only for protocol violations that must reject the whole transaction.
 */
export declare function awardGenesisAllocation(state: WorldState, claimant: string, ctx: ApplyContext): GenesisOutcome;
/**
 * Treasury designation. The treasury wallet is protocol state, not a
 * configuration value: it is set by the genesis rule and can only ever move by
 * an explicit, documented consensus upgrade — never by an administrator, an
 * environment variable, a database row, or a frontend constant.
 */
export declare function treasuryWallet(state: WorldState): string;
export declare function assertTreasuryConfigured(state: WorldState): void;
