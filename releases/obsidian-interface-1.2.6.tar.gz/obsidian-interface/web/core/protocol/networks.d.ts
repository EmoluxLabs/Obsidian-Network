/**
 * Network identification.
 *
 * Chain ID, network ID, address HRP, p2p magic and default ports are protocol
 * constants. A node refuses to peer with, or accept transactions from, any
 * object carrying a different chain ID: this is the primary defence against
 * accidentally mixing testnet/staging/devnet data with mainnet.
 *
 * Genesis identifiers are computed from the genesis document (see genesis/), so
 * two independently configured nodes that build the same genesis document
 * always derive the same genesis hash and will synchronise with each other.
 */
export type NetworkName = 'mainnet' | 'testnet' | 'staging' | 'devnet';
export interface NetworkDefinition {
    name: NetworkName;
    networkId: string;
    chainId: number;
    /** bech32 human-readable part for addresses on this network. */
    addressHrp: string;
    /** 4-byte p2p handshake magic, ASCII. */
    p2pMagic: string;
    defaultRpcPort: number;
    defaultP2pPort: number;
    /** Human-facing label rendered by the interface. */
    displayName: string;
    /** Whether this network's OBS has monetary intent. */
    isProduction: boolean;
}
export declare const NETWORKS: Record<NetworkName, NetworkDefinition>;
export declare function getNetwork(name: string): NetworkDefinition;
/**
 * Hard guard: a development/test process must never silently attach to mainnet.
 * Call this at startup with the resolved network and the process environment.
 */
export declare function assertNetworkSafety(net: NetworkDefinition): void;
/** Deterministic network fingerprint, printed by the health endpoint. */
export declare function networkFingerprint(net: NetworkDefinition, genesisId: string): string;
