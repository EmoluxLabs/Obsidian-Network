/**
 * Canonical binary encoding.
 *
 * Consensus rule: two nodes agree on a hash if and only if they encode the same
 * object identically. Obsidian therefore uses ONE canonical encoder and no JSON
 * in any hashing or signing path. JSON is used only for RPC/UI payloads.
 *
 * Encoder rules:
 *   - Every integer is big-endian two's-complement fixed width, minimal width
 *     that fits with sign preserved (u8/u16/u32/u64/u128).
 *   - Every byte string is length-prefixed with a u32.
 *   - Every string is UTF-8, length-prefixed with a u32 (byte length).
 *   - Every list is length-prefixed with a u32.
 *   - Booleans are a single byte 0x00/0x01.
 *   - No implicit field ordering: writes happen in the order the schema defines.
 *
 * Domain separation: protocol/domains.ts lists the ASCII domain tag that is
 * prepended (length-prefixed) to every hash preimage.
 */
export declare class Writer {
    private chunks;
    private length;
    bytes(data: Uint8Array): this;
    raw(data: Uint8Array): this;
    string(value: string): this;
    boolean(value: boolean): this;
    u8(value: number): this;
    u16(value: number): this;
    u32(value: number): this;
    /** Fixed-width 8-byte unsigned integer (satoshis-style amount field). */
    u64(value: bigint): this;
    /** Fixed-width 16-byte unsigned integer — OBS base units (seals). */
    u128(value: bigint): this;
    /** Signed 16-byte integer for oracle/price deltas. */
    i128(value: bigint): this;
    /** Length-prefixed list of already-encoded items. */
    list(items: Uint8Array[]): this;
    bytesList(items: Uint8Array[]): this;
    stringList(items: string[]): this;
    finish(): Uint8Array;
}
export declare class Reader {
    private readonly data;
    private offset;
    constructor(data: Uint8Array);
    get remaining(): number;
    private take;
    bytes(): Uint8Array;
    string(): string;
    boolean(): boolean;
    u8(): number;
    u16(): number;
    u32(): number;
    u64(): bigint;
    u128(): bigint;
    i128(): bigint;
    list<T>(fn: (r: Reader) => T): T[];
    bytesList(): Uint8Array[];
    stringList(): string[];
    ensureConsumed(): void;
}
/** Encode a schema-bound object via a callback that writes fields in order. */
export declare function encode(fn: (w: Writer) => void): Uint8Array;
