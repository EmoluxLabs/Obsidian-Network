/**
 * Obsidian monetary arithmetic.
 *
 * All OBS amounts are represented as unsigned integers of "seals" where
 * 1 OBS = 10^18 seals (18 decimal places). Integer arithmetic is mandatory:
 * the protocol NEVER performs consensus maths in floating point.
 *
 * Rationale for 18 decimals: the mining schedule expresses rewards such as
 * 0.000166666666666666 OBS per claim, which requires more than 8 decimals to
 * represent exactly at the base unit. 18 decimals removes all rounding drift
 * from the supply invariant.
 */
export declare const OBS_DECIMALS = 18;
export declare const OBS_UNIT: bigint;
/** Hard maximum supply: 21,000,000 OBS. Never exceeded by any code path. */
export declare const MAX_SUPPLY_SEALS: bigint;
export type Seals = bigint;
export declare class AmountError extends Error {
    constructor(message: string);
}
/** Parse a decimal OBS string ("12.5") into seals. Rejects over-precision. */
export declare function parseObs(input: string | number | bigint): bigint;
/**
 * Format seals as a decimal OBS string with trimmed trailing zeros.
 *
 * The default is FULL 18-decimal precision so protocol values (for example a
 * claim reward of 0.000166666666666666 OBS) are never displayed truncated. Pass
 * a smaller `decimals` only for display-only surfaces that want compactness.
 */
export declare function formatObs(seals: bigint, decimals?: number): string;
/**
 * Deterministic integer division rounded half-up. Used for reward splits so
 * every node computes byte-identical results.
 */
export declare function divRoundHalfUp(numerator: bigint, denominator: bigint): bigint;
/** floor(numerator/denominator) for bigints. */
export declare function divFloor(numerator: bigint, denominator: bigint): bigint;
/**
 * Fixed-point multiply: (value * bps) / 10_000 using integer maths only.
 * Used for gas (2 bps = 0.02%) and reward reduction maths.
 */
export declare function applyBasisPoints(value: bigint, basisPoints: number): bigint;
export declare function minBig(a: bigint, b: bigint): bigint;
export declare function maxBig(a: bigint, b: bigint): bigint;
/** Clamp helper for USD oracle values expressed in micro-dollars (1e-6 USD). */
export declare const USD_UNIT = 1000000n;
