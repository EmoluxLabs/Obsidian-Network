/**
 * Obsidian protocol object model.
 *
 * These types are the consensus surface. The canonical encoder in
 * encoding.ts serializes them; a field not listed here cannot affect state.
 */
export var TxType;
(function (TxType) {
    TxType[TxType["PAYMENT"] = 1] = "PAYMENT";
    TxType[TxType["ONS"] = 2] = "ONS";
    TxType[TxType["CAPSULE"] = 3] = "CAPSULE";
    TxType[TxType["LAND"] = 4] = "LAND";
    TxType[TxType["SOCIAL"] = 5] = "SOCIAL";
    TxType[TxType["ORACLE"] = 6] = "ORACLE";
    TxType[TxType["MINING_CLAIM"] = 7] = "MINING_CLAIM";
    TxType[TxType["VALIDATOR"] = 8] = "VALIDATOR";
    TxType[TxType["TREASURY"] = 9] = "TREASURY";
    TxType[TxType["GOVERNANCE"] = 10] = "GOVERNANCE";
    /**
     * Node Runner registry. Carries the signed statements that make node-runner
     * rewards measurable: registration with a proof of reward-wallet ownership,
     * wallet changes, deregistration, liveness heartbeats, peer attestations and
     * peer fault reports. None of these carry an amount: the protocol computes
     * every payout from the evidence it collects here (see src/economy/node-rewards.ts).
     */
    TxType[TxType["NODE_REGISTRY"] = 11] = "NODE_REGISTRY";
})(TxType || (TxType = {}));
/** Operations inside a NODE_REGISTRY transaction. */
export var NodeRegistryOp;
(function (NodeRegistryOp) {
    NodeRegistryOp[NodeRegistryOp["REGISTER"] = 1] = "REGISTER";
    NodeRegistryOp[NodeRegistryOp["CHANGE_WALLET"] = 2] = "CHANGE_WALLET";
    NodeRegistryOp[NodeRegistryOp["DEREGISTER"] = 3] = "DEREGISTER";
    /** A signed liveness statement from the node itself, valid within a slot. */
    NodeRegistryOp[NodeRegistryOp["HEARTBEAT"] = 4] = "HEARTBEAT";
    /** A signed statement from one node about another node's liveness. */
    NodeRegistryOp[NodeRegistryOp["ATTEST"] = 5] = "ATTEST";
    /** A signed report that another node behaved incorrectly. */
    NodeRegistryOp[NodeRegistryOp["REPORT_FAULT"] = 6] = "REPORT_FAULT";
})(NodeRegistryOp || (NodeRegistryOp = {}));
// ── ONS ──────────────────────────────────────────────────────────────────────
export var OnsOp;
(function (OnsOp) {
    OnsOp[OnsOp["REGISTER"] = 1] = "REGISTER";
    OnsOp[OnsOp["UPDATE_ADDRESS"] = 2] = "UPDATE_ADDRESS";
    OnsOp[OnsOp["TRANSFER"] = 3] = "TRANSFER";
    OnsOp[OnsOp["RENEW"] = 4] = "RENEW";
})(OnsOp || (OnsOp = {}));
// ── Capsules ─────────────────────────────────────────────────────────────────
export var CapsuleOp;
(function (CapsuleOp) {
    CapsuleOp[CapsuleOp["CREATE"] = 1] = "CREATE";
    CapsuleOp[CapsuleOp["PREVIEW"] = 2] = "PREVIEW";
})(CapsuleOp || (CapsuleOp = {}));
// ── Land (Obsidian Circle) ───────────────────────────────────────────────────
export var LandOp;
(function (LandOp) {
    /** Official protocol market: issues one new parcel to the buyer at GLV. */
    LandOp[LandOp["PROTOCOL_BUY"] = 1] = "PROTOCOL_BUY";
    /** Owner lists a parcel at their marketplace asking price (MSP). */
    LandOp[LandOp["LIST"] = 2] = "LIST";
    LandOp[LandOp["DELIST"] = 3] = "DELIST";
    /** Buyer accepts a listed MSP price. Does not change GLV. */
    LandOp[LandOp["BUY_LISTED"] = 4] = "BUY_LISTED";
    /** Owner transfers a parcel to another wallet (standard gas rules). */
    LandOp[LandOp["GIFT"] = 5] = "GIFT";
    /** Official protocol buyback: pays current GLV and reduces GLV. */
    LandOp[LandOp["PROTOCOL_SELL"] = 6] = "PROTOCOL_SELL";
})(LandOp || (LandOp = {}));
// ── Social ───────────────────────────────────────────────────────────────────
export var SocialOp;
(function (SocialOp) {
    SocialOp[SocialOp["SET_PROFILE"] = 1] = "SET_PROFILE";
    SocialOp[SocialOp["FOLLOW"] = 2] = "FOLLOW";
    SocialOp[SocialOp["UNFOLLOW"] = 3] = "UNFOLLOW";
    SocialOp[SocialOp["POST"] = 4] = "POST";
    SocialOp[SocialOp["DELETE_POST"] = 5] = "DELETE_POST";
    SocialOp[SocialOp["TIP"] = 6] = "TIP";
    SocialOp[SocialOp["PAY_BUSINESS_PAGE"] = 7] = "PAY_BUSINESS_PAGE";
    SocialOp[SocialOp["REQUEST_VERIFICATION"] = 8] = "REQUEST_VERIFICATION";
    SocialOp[SocialOp["SET_MONETISATION"] = 9] = "SET_MONETISATION";
    SocialOp[SocialOp["ATTEST_VIEWS"] = 10] = "ATTEST_VIEWS";
})(SocialOp || (SocialOp = {}));
// ── Validators ───────────────────────────────────────────────────────────────
export var ValidatorOp;
(function (ValidatorOp) {
    ValidatorOp[ValidatorOp["REGISTER"] = 1] = "REGISTER";
    ValidatorOp[ValidatorOp["UNREGISTER"] = 2] = "UNREGISTER";
    ValidatorOp[ValidatorOp["CLAIM_UNBONDED"] = 3] = "CLAIM_UNBONDED";
})(ValidatorOp || (ValidatorOp = {}));
// ── Treasury ─────────────────────────────────────────────────────────────────
export var TreasuryOp;
(function (TreasuryOp) {
    /**
     * Explicit, auditable protocol revenue payment into the treasury wallet.
     * This is the ONLY way protocol revenue reaches the treasury: it moves funds
     * from the signer's own balance. It can never mint.
     */
    TreasuryOp[TreasuryOp["PAY_REVENUE"] = 1] = "PAY_REVENUE";
    /** Foundation grants from the treasury wallet (signed by the treasury key). */
    TreasuryOp[TreasuryOp["GRANT"] = 2] = "GRANT";
})(TreasuryOp || (TreasuryOp = {}));
//# sourceMappingURL=types.js.map