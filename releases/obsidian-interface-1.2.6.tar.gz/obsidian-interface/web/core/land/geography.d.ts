/**
 * Obsidian Circle geographic factor table — GENERATED DATA, PROTOCOL CONSTANT.
 *
 * This table is part of the protocol: every node derives identical initial GLVs
 * from it. It is shipped inside obsidian-core and never fetched at runtime, so
 * a network outage, an API change or a compromised CDN can never reprice land.
 *
 * Changing this file changes land pricing and therefore requires a protocol
 * version bump (it is included in PARAMS_HASH revocation checks and in the
 * release checksums).
 *
 * Fields per country:
 *   populationM     population in millions (published reference values)
 *   economy         economic activity index, 0-100
 *   infrastructure  infrastructure index, 0-100
 *   tourism         tourism index, 0-100
 *   significance    global significance index, 0-100
 *   divisions       ISO 3166-2 first-level divisions with optional weights
 *                   (percent, 100 = neutral) for tourism/economic concentration
 */
export interface RawDivision {
    id: string;
    name: string;
    /** Percent weight applied to the country GLV (100 = neutral). */
    weight?: number;
}
export interface RawCountry {
    code: string;
    name: string;
    continent: string;
    populationM: number;
    economy: number;
    infrastructure: number;
    tourism: number;
    significance: number;
    divisions?: RawDivision[];
}
export interface RawGeography {
    version: string;
    countries: RawCountry[];
}
export declare const GEOGRAPHY: RawGeography;
