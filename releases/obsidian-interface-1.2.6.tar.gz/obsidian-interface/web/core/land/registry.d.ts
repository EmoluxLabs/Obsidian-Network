/**
 * Obsidian Circle geographic registry.
 *
 * The protocol needs two deterministic facts about a location:
 *   1. the administrative hierarchy (earth -> continent -> country -> region ->
 *      city -> district -> street -> parcel), used for search and for parcel
 *      identity; and
 *   2. the initial GLV (Global Location Value) of every first-level division,
 *      which is the price of the first protocol purchase there.
 *
 * Initial GLV is derived from a published factor table with deterministic
 * integer arithmetic, bounded by the protocol minimum ($100) and maximum
 * ($30,000) from CONSENSUS_PARAMS.circle:
 *
 *   GLV = clamp(min, base(population, economy, infrastructure, tourism,
 *                globalSignificance) * countryMultiplier, max)
 *
 * Every node ships the same table (src/land/geography.ts, changeable only by a
 * protocol version bump), so every node derives identical prices. Nothing here
 * reads the network or an external service.
 */
export declare const DIVISION_LEVEL_CODES: {
    readonly DIVISION: 1;
    readonly CITY: 2;
    readonly DISTRICT: 3;
    readonly STREET: 4;
};
export type DivisionLevel = keyof typeof DIVISION_LEVEL_CODES;
export interface CountryEntry {
    /** ISO 3166-1 alpha-2. */
    code: string;
    name: string;
    continent: string;
    /** Population in millions, integer (published reference values). */
    populationM: number;
    /** Economic activity index 0-100 (relative GDP weight). */
    economy: number;
    /** Infrastructure index 0-100. */
    infrastructure: number;
    /** Tourism index 0-100. */
    tourism: number;
    /** Global significance index 0-100 (cultural / political weight). */
    significance: number;
    /**
     * ISO 3166-2 first-level divisions. When omitted the country itself is the
     * first-level division (city-states and single-tier territories).
     */
    divisions?: Array<{
        id: string;
        name: string;
        weight?: number;
    }>;
}
export interface GeographyFile {
    version: string;
    countries: CountryEntry[];
}
export declare function geographyTable(): GeographyFile;
export declare function normaliseDivisionId(divisionId: string): string;
export declare function findDivision(divisionId: string): {
    country: CountryEntry;
    divisionId: string;
    weight: number;
} | null;
/**
 * Base GLV for a location, in OBS seals, from the published factor table.
 * Deterministic integer expression — no floating point in consensus, and no
 * external price source of any kind.
 */
export declare function baseGlv(country: CountryEntry, divisionWeight?: number): bigint;
export interface DivisionSeed {
    divisionId: string;
    countryCode: string;
    countryName: string;
    continent: string;
    glvSeals: bigint;
    /** Deterministic identity for the division record. */
    fingerprint: string;
}
export declare function divisionSeed(divisionId: string, countryCode?: string): DivisionSeed;
export interface SearchHit {
    divisionId: string;
    countryCode: string;
    name: string;
    continent: string;
    glvSeals: bigint;
    glvObs: string;
}
/** Simple, deterministic, case-insensitive search over the registry. */
export declare function searchDivisions(query: string, limit?: number): SearchHit[];
/**
 * Every first-level division of one country, with the GLV the protocol gives it.
 *
 * `listCountries()` returns counts only, so an interface that wanted to offer
 * Earth → country → division navigation had to guess division ids. This is the
 * registry, not chain state: current GLVs come from the node's state store and
 * are overlaid by the RPC handler.
 */
export declare function listDivisions(countryCode: string): Array<{
    divisionId: string;
    name: string;
    weight: number;
    glvSeals: bigint;
    glvObs: string;
    level: number;
}>;
export declare function listCountries(): Array<{
    code: string;
    name: string;
    continent: string;
    divisionCount: number;
    glvObs: string;
}>;
