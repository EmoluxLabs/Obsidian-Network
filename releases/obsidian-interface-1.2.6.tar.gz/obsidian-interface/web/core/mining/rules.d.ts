/**
 * Mining eligibility rules — the anti-cheat core.
 *
 * ELIGIBILITY IS A FUNCTION OF PROTOCOL STATE AND THE INCLUDING BLOCK'S
 * TIMESTAMP ONLY. Nothing here can be influenced by:
 *   - the user's device clock, timezone, cookies or local storage;
 *   - a frontend countdown;
 *   - the HTTP request time;
 *   - a node operator's wall clock (the block timestamp is bounded by the
 *     median-time-past rule and a 60-second future drift limit);
 *   - retries, duplicate requests or multiple tabs (claim ids and nonces are
 *     unique per attempt and replay-protected in state).
 */
import { ErrCode } from '../protocol/errors.js';
import type { Account, MiningState } from '../protocol/types.js';
export interface MiningEligibility {
    eligible: boolean;
    /** Protocol time (seconds) at which the wallet may next claim. */
    nextEligibleAt: number;
    /** Remaining seconds, floored at zero (UI hint only — never authority). */
    secondsRemaining: number;
    claimsThisCycle: number;
    claimsRemainingInCycle: number;
    cycleStartAt: number;
    cycleEndsAt: number;
    nextClaimSequence: number;
    rewardPerClaim: bigint;
    reason: ErrCode;
    /** True when this wallet would receive the one-time Genesis Allocation. */
    genesisEligible: boolean;
}
/** Aligned claim cycle window that every node agrees on. */
export declare function alignedCycleStart(protocolTime: number): number;
export declare function cycleEndsAt(cycleStart: number): number;
export declare function freshMiningState(protocolTime: number): MiningState;
/**
 * Evaluate eligibility for `address` at `protocolTime`.
 *
 * Determinism note: the returned object is a pure function of
 * (account.mining, protocolTime, metrics.activeMiners, genesis state).
 */
export declare function evaluateMining(account: Account | undefined, protocolTime: number, activeMiners: number, genesisClaimed: boolean): MiningEligibility;
/** Throwing form used inside the state machine. */
export declare function assertMiningEligibility(account: Account | undefined, protocolTime: number, activeMiners: number, genesisClaimed: boolean): MiningEligibility;
/**
 * Max claims one wallet may place in a single block. Prevents a producer from
 * bundling a queue of claims to fast-forward a wallet's history.
 */
export declare const MAX_CLAIMS_PER_BLOCK_PER_WALLET: 1;
