/**
 * Obsidian mining emission schedule — pure, deterministic, integer-only.
 *
 * Rules (spec §21, §23):
 *   - 6 claims per 24-hour cycle, one every 4 hours.
 *   - Genesis-era network emission: 0.001 OBS per 24 hours.
 *   - Per-claim reward = floor(dailyReward / 6) = 0.000166666666666666 OBS.
 *   - Reduction: 0.5% per 100,000 active miners (compounding, floor-rounded).
 *   - Hard floor: 0.0002 OBS per 24 hours, never crossed.
 *
 * Every node computes the identical value from the identical inputs, so no
 * client-side calculation, oracle or administrator can alter a reward.
 */
/**
 * Daily network emission for a given active-miner count.
 * reward = max(floor, floor(initial * (9950/10000)^steps))
 * where steps = floor(activeMiners / 100000).
 */
export declare function dailyRewardForActiveMiners(activeMiners: number): bigint;
/** Reward paid for one accepted claim at a given active-miner count. */
export declare function claimRewardForActiveMiners(activeMiners: number): bigint;
/**
 * Emission ceiling for a given height — the maximum OBS that may ever have been
 * issued by mining up to that point. Used as a belt-and-braces assertion: an
 * implementation that drifts above this schedule is rejected by peers.
 *
 * The ceiling is intentionally generous (initial daily reward at the floor
 * applied for the whole history) because issuance is also gated by the supply
 * invariant; this function exists to make gross emission bugs impossible.
 */
export declare function issuanceCeilingSeals(height: number): bigint;
export interface MiningScheduleView {
    activeMiners: number;
    dailyRewardSeals: bigint;
    dailyRewardObs: string;
    claimRewardSeals: bigint;
    claimRewardObs: string;
    reductionPercentPerStep: number;
    reductionStepMiners: number;
    floorDailySeals: bigint;
    floorDailyObs: string;
    claimsPerCycle: number;
    intervalSeconds: number;
}
export declare function scheduleView(activeMiners: number): MiningScheduleView;
