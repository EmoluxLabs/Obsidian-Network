/**
 * BIP-39 mnemonics and hierarchical deterministic wallet derivation.
 *
 * Obsidian wallets use standard BIP-39 (English wordlist, 256-bit entropy =>
 * 24 words) and a BIP-32 style derivation path:
 *
 *      m / 44' / 7777' / account' / 0 / index
 *
 * where 7777 is the registered Obsidian coin type placeholder (7847 was
 * requested from SLIP-0044; the constant is protocol data and can be changed
 * only by a documented consensus upgrade, never silently).
 *
 * Guarantees enforced here:
 *   - Entropy comes exclusively from the OS CSPRNG.
 *   - No application identifier (email, Google sub, username, account id,
 *     timestamp) ever participates in key derivation.
 *   - The phrase is never serialized by the node except into an encrypted
 *     keystore the user explicitly creates.
 */
import { type KeyPair } from './keys.js';
export declare const OBSIDIAN_COIN_TYPE = 7777;
export declare const DEFAULT_DERIVATION_PREFIX = "m/44'/7777'";
/**
 * Generate a 24-word recovery phrase from CSPRNG entropy.
 * 256 bits of entropy is the strongest BIP-39 offers.
 */
export declare function generateRecoveryPhrase(): string;
export declare function isValidRecoveryPhrase(phrase: string): boolean;
export declare function normalizePhrase(phrase: string): string;
export interface DerivedWallet extends KeyPair {
    derivationPath: string;
    account: number;
    index: number;
}
/**
 * Derive a wallet from a recovery phrase.
 * Default path m/44'/7777'/account'/0/index keeps one phrase able to control
 * many independent wallets (useful for ONS identity separation).
 */
export declare function deriveWallet(phrase: string, account?: number, index?: number, prefix?: string, addressHrp?: string): DerivedWallet;
/** Derive many addresses from one phrase (account discovery in the UI). */
export declare function deriveWalletRange(phrase: string, count: number, account?: number, addressHrp?: string): DerivedWallet[];
