/**
 * Hashing primitives. SHA-256 is the Obsidian Network hash function.
 * Hashes are always computed over canonical, domain-separated byte strings
 * (see protocol/encoding.ts) so that a transaction hash can never be confused
 * with a block hash, an address, or any other digest.
 */
export declare function utf8(s: string): Uint8Array;
export declare function toHex(bytes: Uint8Array): string;
export declare function fromHex(hex: string): Uint8Array;
export declare function concatBytes(...parts: Uint8Array[]): Uint8Array;
export declare function sha256(data: Uint8Array): Uint8Array;
export declare function sha256Hex(data: Uint8Array | string): string;
export declare function doubleSha256(data: Uint8Array): Uint8Array;
export declare function ripemd160(data: Uint8Array): Uint8Array;
export declare function hmacSha256(key: Uint8Array, data: Uint8Array): Uint8Array;
/**
 * Domain-separated hash. The `domain` string is length-prefixed into the
 * preimage so that different object types can never collide.
 */
export declare function domainHash(domain: string, ...chunks: Uint8Array[]): Uint8Array;
/** Constant-time comparison to avoid timing oracles on digests. */
export declare function bytesEqual(a: Uint8Array, b: Uint8Array): boolean;
export declare function utf8Compare(a: string, b: string): number;
