/**
 * Hash domain separation tags.
 *
 * Each protocol object hashes over exactly one of these ASCII tags, so a
 * transaction id can never equal a block id, an address can never be reused as
 * a transaction hash, and cross-object replay of signatures is impossible.
 */
export declare const DOMAIN: {
    readonly BLOCK_HEADER: "OBSIDIAN:BLOCK_HEADER:v1";
    readonly BLOCK: "OBSIDIAN:BLOCK:v1";
    readonly TX: "OBSIDIAN:TX:v1";
    readonly TX_SIGNING: "OBSIDIAN:TX_SIGNING:v1";
    readonly MERKLE_LEAF: "OBSIDIAN:MERKLE_LEAF:v1";
    readonly MERKLE_NODE: "OBSIDIAN:MERKLE_NODE:v1";
    readonly STATE_ROOT: "OBSIDIAN:STATE_ROOT:v1";
    readonly GENESIS: "OBSIDIAN:GENESIS:v1";
    readonly GENESIS_ID: "OBSIDIAN:GENESIS_ID:v1";
    readonly PEER_HELLO: "OBSIDIAN:PEER_HELLO:v1";
    readonly PEER_ANNOUNCE: "OBSIDIAN:PEER_ANNOUNCE:v1";
    readonly NODE_METADATA: "OBSIDIAN:NODE_METADATA:v1";
    readonly ORACLE_PRICE: "OBSIDIAN:ORACLE_PRICE:v1";
    readonly ORACLE_ATTESTATION: "OBSIDIAN:ORACLE_ATTEST:v1";
    readonly CAPSULE_SECRET: "OBSIDIAN:CAPSULE_SECRET:v1";
    readonly CAPSULE_ID: "OBSIDIAN:CAPSULE_ID:v1";
    readonly AUCTION_BID: "OBSIDIAN:AUCTION_BID:v1";
    readonly RELEASE_SIGNATURE: "OBSIDIAN:RELEASE:v1";
    readonly API_TOKEN: "OBSIDIAN:API_TOKEN:v1";
};
export type DomainTag = (typeof DOMAIN)[keyof typeof DOMAIN];
