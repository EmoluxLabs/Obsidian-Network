/**
 * Consensus parameters — the Obsidian Protocol Specification in constant form.
 *
 * RULE (spec §75): consensus-critical configuration must be deterministic
 * across nodes. Therefore every value in this file is a compile-time constant
 * of the protocol version, NOT an operator setting. Operators configure only
 * application-level items (ports, data directory, log level, RPC bind address).
 *
 * Changing any value below requires a protocol version bump and a documented
 * consensus upgrade — it is a hard fork.
 *
 * Values are documented in /docs/consensus.md and /docs/economics.md.
 */
export declare const CONSENSUS_PARAMS: {
    /** Protocol version that owns these parameters. */
    readonly protocolVersion: "1.0.0";
    /** Hard cap. Issuance of ANY kind is rejected if it would exceed this. */
    readonly maxSupply: bigint;
    /** One-time genesis allocation reserved for the first protocol-valid miner. */
    readonly genesisAllocation: bigint;
    /**
     * The legacy 3,000,000 OBS genesis allocation is REMOVED and MUST NOT exist.
     * This constant exists purely so the automated compliance checklist can
     * assert its value is zero. Nothing may ever read it for issuance.
     */
    readonly legacyGenesisAllocationRemoved: 0n;
    readonly mining: {
        /** Minimum seconds between two accepted claims by the same wallet. */
        readonly claimIntervalSeconds: number;
        /** Maximum accepted claims per wallet per rolling 24-hour cycle. */
        readonly maxClaimsPerCycle: 6;
        /** Length of the claim cycle in seconds. */
        readonly cycleSeconds: number;
        /** Genesis-era total daily reward across the whole network. */
        readonly initialDailyReward: bigint;
        /** Per-claim reward while the network is at genesis participation. */
        readonly initialClaimReward: bigint;
        /** Owner of a claim must have been registered at least this recent... */
        readonly activeMinerWindowSeconds: number;
        /**
         * Reward reduction: 0.5% per 100,000 active miners.
         * Implemented with exact integer arithmetic (see mining/schedule.ts).
         */
        readonly reductionBasisPointsPerStep: 50;
        readonly reductionStepMiners: 100000;
        /** Absolute floor: 0.0002 OBS per 24 hours. Never crossed. */
        readonly dailyRewardFloor: bigint;
        /**
         * Grace applied to a wallet's very first claim so a miner is never forced
         * to wait for a full interval after registering the wallet on-chain.
         */
        readonly firstClaimGraceSeconds: 0;
        /** Maximum claims accepted from one wallet inside a single block. */
        readonly maxClaimsPerBlockPerWallet: 1;
    };
    readonly gas: {
        /** 0.02% of the transferred amount, in basis points. */
        readonly basisPoints: 2;
        /** Absolute ceiling on gas per transaction: 0.01 OBS. */
        readonly maxGas: bigint;
        /** Minimum gas charged on any value-bearing transaction (anti-spam dust). */
        readonly minGas: 0n;
        /**
         * Gas destination. Protocol rule: gas is remitted to the Mining Pool.
         * The Mining Pool is protocol state, not a wallet; see treasury/pool.ts.
         */
        readonly destination: "MINING_POOL";
    };
    readonly block: {
        /** Target spacing between blocks, seconds. */
        readonly targetBlockSeconds: 5;
        /** Maximum serialized block size in bytes. */
        readonly maxBlockBytes: number;
        /** Maximum number of transactions in one block including the reward claim batch. */
        readonly maxBlockTransactions: 2000;
        /** Allowed future drift for a block timestamp relative to local node time. */
        readonly maxFutureDriftSeconds: 60;
        /** Minimum number of parents considered when computing median time past. */
        readonly medianTimePastWindow: 11;
        /** Blocks after which a transaction is considered buried (soft finality hint). */
        readonly confirmationDepthSoft: 12;
        /** Depth at which an interface may show "final" (irreversible for practical use). */
        readonly confirmationDepthHard: 64;
        /** Emission decade length used by the halving-style issuance cap. */
        readonly issuanceDecadeSeconds: number;
    };
    readonly consensus: {
        /** Slots per producer rotation (proposer = validators[height % validatorCount]). */
        readonly validatorSlotsPerRotation: 1;
        /** A validator must be bonded with at least this much OBS. */
        readonly minValidatorBond: bigint;
        /** Unbonding delay in blocks before bond funds return. */
        readonly unbondingBlocks: 20160;
        /** Missed slots tolerated in a 100-block window before jailing. */
        readonly maxMissedSlotsPerWindow: 40;
        /** Jailing period in blocks. */
        readonly jailBlocks: 10080;
        /**
         * Fork-choice weight: accumulated work then chain length then lowest hash.
         * See consensus/fork-choice.ts for the exact deterministic tie-break.
         */
        readonly forkChoice: "MOST_ACCUMULATED_WORK_THEN_LENGTH_THEN_LOWEST_HEADER_HASH";
        /** Maximum reorg depth accepted by the node's chain reorganiser. */
        readonly maxReorgDepth: 256;
    };
    readonly tx: {
        /** Replay window: a transaction is invalid if included after this many blocks. */
        readonly expiryBlocks: 240;
        /** Maximum memo length in bytes. */
        readonly maxMemoBytes: 256;
        /** Maximum signed transaction size in bytes. */
        readonly maxTxBytes: number;
        /** Maximum number of out-messages a transaction executor may enqueue. */
        readonly maxEventsPerTx: 64;
        /** Minimum transfer amount enforced by the protocol (anti-dust). */
        readonly minTransfer: 1n;
    };
    readonly ons: {
        readonly minLength: 3;
        readonly maxLength: 63;
        /** Registration fee in USD micro-units, paid in OBS at oracle price. */
        readonly registrationFeeUsd: 5000000n;
        readonly renewalFeeUsd: 5000000n;
        /** Registration grants ownership for this many seconds (1 year). */
        readonly termSeconds: number;
        /** Grace period after expiry before the name returns to the pool. */
        readonly graceSeconds: number;
        /** Protocol-reserved names that can never be registered by users. */
        readonly reserved: readonly ["obs", "www", "admin", "root", "treasury", "foundation", "blackseal", "core", "node", "genesis", "support", "api", "wallet", "explorer", "social", "capsule", "circle", "developer"];
    };
    readonly capsules: {
        /** Minimum OBS commitment. */
        readonly minCommitment: bigint;
        /** Time Travel preview price multiplier (price = 1000 * commitment). */
        readonly timeTravelMultiplier: 1000n;
        /** Preview window, in seconds. */
        readonly previewSeconds: 30;
        /** Minimum lock duration from creation, in seconds (1 hour). */
        readonly minLockSeconds: number;
        /** Maximum lock duration (100 years) — a sanity bound, not a limit on ambition. */
        readonly maxLockSeconds: number;
        /** Maximum encrypted payload size per capsule, in bytes. */
        readonly maxContentBytes: number;
        /** One Time Travel preview per capsule per account. */
        readonly maxPreviewsPerAccount: 1;
    };
    readonly circle: {
        /**
         * Every parcel is 1 square metre at the level of the protocol market:
         * "one plot or one square metre, or less, per protocol transaction".
         */
        readonly parcelSquareMetres: 1;
        /** Protocol purchase and buyback are executed one parcel per transaction. */
        readonly maxParcelsPerProtocolTx: 1;
        /**
         * GLV (Global Location Value) multiplier applied to the location's base
         * value for each protocol purchase: GLV_next = GLV * (1 + step).
         * The buyer of a purchase never retroactively benefits — see docs.
         */
        readonly protocolPurchaseMultiplierBps: 10000;
        /** Step applied to GLV after each protocol purchase, in basis points (0.25%). */
        readonly appreciationStepBps: 25;
        /** Step applied to GLV after each protocol buyback, in basis points (0.25%). */
        readonly depreciationStepBps: 25;
        /** GLV bounds in USD micro-units. */
        readonly minGlvUsd: 100000000n;
        readonly maxGlvUsd: 30000000000n;
        /** A buyback is only permitted when the protocol land reserve can fund it. */
        readonly requireReserveForBuyback: true;
    };
    readonly social: {
        /** Post body limit, bytes. */
        readonly maxPostBytes: number;
        readonly maxCommentBytes: number;
        readonly maxUsernameLength: 24;
        /** Creator monetisation eligibility thresholds. */
        readonly monetisationMinFollowers: 10000;
        readonly monetisationMinMonthlyViews: 100000;
        /** Revenue split in basis points: 70% creator, 30% Obsidian Network. */
        readonly creatorShareBps: 7000;
        readonly networkShareBps: 3000;
        /** Business page activation price in USD micro-units ($50). */
        readonly businessPagePriceUsd: 50000000n;
        /** Tip minimum (one seal). */
        readonly minTip: 1n;
        /** Feed page size ceiling enforced by the node. */
        readonly maxPageSize: 100;
    };
    readonly oracle: {
        /** Price is invalid if older than this many seconds. */
        readonly maxAgeSeconds: number;
        /** Quorum: observations required to form a median price. */
        readonly minSources: 2;
        /** Sanity bound: reject any single observation this far from local median. */
        readonly maxDeviationBps: 2500;
        /** Absolute bounds on OBS/USD price in micro-USD. */
        readonly minPriceUsdMicro: 1n;
        readonly maxPriceUsdMicro: 1000000000000n;
        /** Maximum observation age accepted from a single source, seconds. */
        readonly maxSourceAgeSeconds: number;
    };
    readonly registry: {
        /**
         * Invite-only registration is an APPLICATION policy, never consensus.
         * Each application account may invite at most this many new accounts.
         */
        readonly maxInvitesPerAccount: 5;
        /** New accounts always begin at exactly this balance. */
        readonly newAccountBalance: 0n;
        /**
         * WAC is removed. These constants exist so the compliance checklist can
         * assert the removal programmatically.
         */
        readonly wacPriceUsd: 0n;
        readonly wacEnabled: false;
        readonly miningKycRequired: false;
        readonly miningWithdrawalRequiresWac: false;
        readonly nativeExchangeEnabled: false;
    };
};
/** Convenience: reward floor per claim derived from the daily floor. */
export declare const MIN_CLAIM_REWARD: bigint;
