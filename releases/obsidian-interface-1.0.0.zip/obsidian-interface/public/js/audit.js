// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function when(timestampSeconds) {
  if (!timestampSeconds) return "\u2014";
  return new Date(timestampSeconds * 1e3).toLocaleString();
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  names(prefix = "") {
    return this.request(`/names${prefix ? `?prefix=${encodeURIComponent(prefix)}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  landCountries() {
    return this.request("/land/countries");
  }
  landDivisions(countryCode) {
    return this.request(`/land/divisions?country=${encodeURIComponent(countryCode)}`);
  }
  landSearch(query) {
    return this.request(`/land/search?q=${encodeURIComponent(query)}`);
  }
  landParcels(options = {}) {
    const query = new URLSearchParams();
    if (options.divisionId) query.set("divisionId", options.divisionId);
    if (options.owner) query.set("owner", options.owner);
    query.set("limit", String(options.limit ?? 25));
    return this.request(`/land/parcels?${query.toString()}`);
  }
  landParcel(parcelId) {
    return this.request(`/land/parcel/${encodeURIComponent(parcelId)}`);
  }
  landQuote(divisionId) {
    return this.request(`/land/quote/${encodeURIComponent(divisionId)}`);
  }
  capsules(options = {}) {
    const query = new URLSearchParams({ limit: String(options.limit ?? 25) });
    if (options.status) query.set("status", options.status);
    if (options.owner) query.set("owner", options.owner);
    return this.request(`/capsules?${query.toString()}`);
  }
  capsule(id) {
    return this.request(`/capsules/${encodeURIComponent(id)}`);
  }
  socialFeed(limit = 25) {
    return this.request(`/social/feed?limit=${limit}`);
  }
  socialProfile(accountId) {
    return this.request(`/social/profile/${encodeURIComponent(accountId)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  signIn(idToken, inviteCode) {
    return api("/api/auth/google", {
      method: "POST",
      body: JSON.stringify({ idToken, inviteCode })
    });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  linkWallet(address) {
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "circle", href: "/circle/", label: "Circle", blurb: "Land registry" },
  { id: "capsule", href: "/capsule/", label: "Capsules", blurb: "Time locks" },
  { id: "social", href: "/social/", label: "Social", blurb: "OBS Social" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const nav = el(
    "nav",
    { class: "nav" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        el("span", { class: "brand-mark", "aria-hidden": "true" }, "\u25C6"),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      accountSlot
    ),
    banner,
    nav
  );
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a proof-of-work chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/pages/audit.ts
var client = new ObsidianClient();
var panel = el("section", { class: "card" }, spinner("asking every reachable node\u2026"));
var decPanel = el("section", { class: "card" }, spinner("reading the decentralisation report\u2026"));
layout({
  current: "audit",
  title: "Compliance audit",
  tagline: "What is absent from the protocol, read from the protocol itself.",
  children: [
    el(
      "section",
      { class: "notice" },
      el("strong", {}, "Absence is a property of code, not of a policy page. "),
      "Each row below comes from a route every node serves. A mechanism reported as `present: true` would mean the running binary still accepts it \u2014 regardless of what any document says."
    ),
    panel,
    decPanel
  ]
});
void (async () => {
  try {
    const [compliance, decentralisation, status, supply] = await Promise.all([
      client.requestSafe("/audit/compliance"),
      client.requestSafe("/audit/decentralization"),
      client.status(),
      client.supply()
    ]);
    if (!compliance) throw new Error("this node does not expose /audit/compliance");
    const rows = Object.entries(compliance).map(([key, value]) => {
      const flag = value;
      const present = typeof flag === "boolean" ? flag : Boolean(flag?.present);
      const detail = typeof flag === "boolean" ? "" : flag?.detail ?? "";
      return [
        el("span", { class: "mono" }, key),
        present ? badge("present \u2014 investigate", "bad") : badge("absent", "ok"),
        detail
      ];
    });
    panel.replaceChildren(
      el("h2", {}, "Removed mechanisms"),
      table(["Mechanism", "State", "Node detail"], rows),
      el("h3", {}, "Supply and genesis"),
      kv([
        // The node names these `totalSupplyObs` / `maxSupplyObs`: reading a
        // field that does not exist prints "undefined OBS" beside a healthy chain.
        ["Total supply", `${obs(supply.totalSupplyObs || status.supplyObs)} OBS`],
        ["Hard cap", `${obs(supply.maxSupplyObs || status.maxSupplyObs)} OBS`],
        ["Invariant", supply.invariantOk ? "supply invariant holds (recomputed by this node)" : "FAILED \u2014 investigate"],
        ["Issuance sources", supply.issuanceSources.length > 0 ? supply.issuanceSources.join(", ") : "none yet"],
        ["Genesis allocation", status.genesis ? `${status.genesis.allocationObs} OBS to ${status.genesis.allocationClaimed ? "the first valid mining claim (claimed)" : "the first valid mining claim (unclaimed)"}` : "\u2014"],
        ["Treasury wallet", el("span", { class: "mono" }, status.genesis?.treasuryWallet ?? "\u2014")],
        ["Designation", "the wallet that received the genesis allocation is the on-chain treasury: platform revenue is routed there, user funds never are"]
      ]),
      el("p", { class: "fineprint" }, `Read at ${when(status.lastBlockTimestamp)} from ${status.networkId} at height ${status.height.toLocaleString()}.`)
    );
    if (decentralisation) {
      decPanel.replaceChildren(
        el("h2", {}, "Decentralisation"),
        kv(Object.entries(decentralisation).map(([key, value]) => [key, typeof value === "object" ? JSON.stringify(value) : String(value)])),
        el("p", { class: "fineprint" }, "Mining distribution, node counts and validator participation are recomputed by each node from the chain it holds.")
      );
    } else {
      decPanel.replaceChildren(el("h2", {}, "Decentralisation"), el("p", { class: "muted" }, "This node does not expose the decentralisation report."));
    }
  } catch (error) {
    panel.replaceChildren(el("h2", {}, "Compliance audit"), el("p", { class: "error" }, error.message));
    toast(error.message, "error");
  }
})();
//# sourceMappingURL=audit.js.map
