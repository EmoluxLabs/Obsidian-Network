# Obsidian Interface

The reader: a self-hostable web server that serves the Obsidian Network apps
(wallet, miner, explorer, ONS, node runners, developer docs and the compliance
audit) on top of one or more **Obsidian Core** nodes. It is a light,
mobile-first application: one stylesheet, phone-first layout, tested from 320px
to 1440px.

The interface is a *cache with an allowlist*, never an authority:

* It cannot create, move, price or decide anything — every number it shows is
  fetched from a node and re-fetched on the next page.
* It never holds a wallet key or a recovery phrase. Wallets are created and
  transactions are signed **in the browser**, and only signed bytes are relayed.
* Its `/api/rpc` proxy is an exact-route allowlist: the route is matched, the
  query string is forwarded to the node (`/blocks?limit=`, `/mining/status?address=`),
  and anything off the list is refused with `ERR_REJECTED`. There is no SPA
  fallback: an unknown path is an honest 404.
* It stops rather than guessing: no healthy node ⇒ `503 ERR_NO_HEALTHY_NODE`, a
  genesis mismatch between nodes is flagged instead of blended.

## Requirements

* Node.js **>= 20.10**, npm
* One or more Obsidian Core nodes to read from (two or more recommended)

## Install and build

```bash
npm ci
npm run build     # compile the server, typecheck, bundle the browser apps, write the nine site shells
npm test          # auth, invites, store, node pool, HTTP server, config discovery,
                  # amount formatters, jsdom page tests, and a suite that drives the real
                  # pages against a real obsidian-core node (needs `npm run build` first)
```

`npm run build` writes:

* `dist/` — the compiled server
* `public/js/`, `public/css/`, `public/assets/` — browser bundles and brand assets
* the site shells (`landing/index.html`, `mine/index.html`, …) at `$SITE_ROOT`

## Run

```bash
export OBSIDIAN_NODE_URLS=http://127.0.0.1:18630,http://node2.example:18630
node dist/server/main.js --network testnet        # listens on 127.0.0.1:18788
```

`--network` is required: an interface serves exactly one network, uses that network's own port
(mainnet 8788, testnet 18788, staging 28788, devnet 38788) and refuses a node that follows another.
List the RPC URLs of nodes on **that** network.

All flags are listed by `--help`: `--host --port --nodes --data-dir --site-root
--public-dir --core-dir --allow-origin --max-invites
--trust-proxy --log-level`. Every one of them has an `OBSIDIAN_*` environment
equivalent (`deployment/interface.env.example`).

### Where the site shells are found

`--site-root` is the directory that holds `landing/`, `mine/`, `wallet/`, … When
it is not given, the interface looks in the checkout layout first (the parent of
this package, i.e. the repository root) and then inside this package — which is
the layout of the self-contained `obsidian-interface-selfhost` release. If the
shells are missing it **refuses to start** instead of serving a blank page.

A Dockerfile is not proof of deployability: `deployment/docker/verify.sh` builds
the image, starts it, waits for `/api/health` and checks headers and assets. Run
it in your environment.

## Security posture

| Property | How |
| --- | --- |
| Invite-only, server-enforced | Gmail + password + invite + TOTP, all verified **server-side**; the canonical Gmail address (dots and `+tags` stripped) is the uniqueness key, so one inbox gets one mining account; no client-supplied flag is ever trusted; 5 invites per account, enforced in the store |
| Mining is account-bound, server-enforced | a mining claim (`POST /api/rpc?path=/tx/submit`, classified by decoding the transaction with the node's own decoder) is relayed only for a **signed-in** account that has a **wallet linked** and **MFA confirmed**, and only when the claim is **signed by that linked wallet**; otherwise `401 ERR_UNAUTHORIZED`, `403 ERR_WALLET_NOT_LINKED`, `403 ERR_MINING_NOT_ENABLED` or `403 ERR_WALLET_MISMATCH`. Payments and names are not account-bound. The relay accepts a POST only for `/tx/submit` and the two balance routes, refuses transactions it cannot decode, and `/api/wallet/link` accepts only a checksum-valid address of this network. The mining page mirrors the same rules, but the server is the gate |
| One wallet per account, proven, permanent | a wallet is linked by **signing a server challenge** (`POST /api/wallet/link/challenge`, then `POST /api/wallet/link` with address, public key and signature; the challenge is bound to the network, the account and the address, single-use, five minutes, one outstanding per account, and signed under the domain `OBSIDIAN:WALLET_LINK:v1`). The server checks the signature and that the public key derives the address, so nobody can link an address whose key they do not hold. The link is **permanent**: the same address again is a no-op, a different one is `409 ERR_WALLET_LOCKED`; an address linked to another account is `409 ERR_WALLET_TAKEN` and cannot be used to claim through any other account (`ERR_WALLET_MISMATCH`). The wallet is a device-held key and is **never derived from account data**; the server stores the address and public key only. A bare address from before this rule counts as unlinked and is replaced by a proven link. **Eligibility is not the platform's**: it adds no cooldown or claim logic and does no chain lookup for linking; consensus decides from the account's last claim, and the mining page reads the node's `/mining/status` |
| Keys never leave the browser | wallet creation, keystore (PBKDF2 210k + AES-GCM) and signing happen in `web/src/lib/wallet.ts`; the server only ever sees signed transaction bytes |
| No balance surveillance | balances are only served by an explicit `POST /api/rpc` to `/wallet/balance`; explorer routes mask addresses |
| Cache safety | `/api/auth/*`, wallet and node-refresh routes are never cached; the Cloudflare worker in `../cloudflare` enforces the same rule at the edge |
| Headers | strict CSP, no wildcard CORS, `x-content-type-options`, no framing |

## Sites served

`landing` (root), `mine`, `wallet`, `explorer`, `ons`, `node`, `developer`,
`app` (accounts) and `audit` (compliance). Each is a separate directory with its
own shell and bundle, so one can be deployed or replaced on its own.

## Docs

* `../docs/self-hosting.md` — deployments, TLS, proxies, failover
* `../docs/wallet.md` — key handling and recovery
* `../docs/explorer.md` — what the explorer deliberately does not show
* `../docs/api.md` — the node RPC the interface reads
* `../docs/security-model.md` — trust boundaries

## Licence

Apache-2.0 — see `LICENSE`.
