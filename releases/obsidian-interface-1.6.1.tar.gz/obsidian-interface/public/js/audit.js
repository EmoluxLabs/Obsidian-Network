// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function duration(seconds) {
  if (seconds <= 0) return "now";
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds % 86400 / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  const secs = Math.floor(seconds % 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${secs}s`;
  return `${secs}s`;
}
function when(timestampSeconds) {
  if (!timestampSeconds) return "\u2014";
  return new Date(timestampSeconds * 1e3).toLocaleString();
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
function pct(value, digits = 2) {
  return `${value.toFixed(digits)}%`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
async function copy(value, label = "Copied") {
  try {
    await navigator.clipboard.writeText(value);
    toast(`${label} to clipboard`, "success");
  } catch {
    toast("Clipboard access was blocked by the browser", "error");
  }
}
function copyButton(value, label = "Copy") {
  const button = el("button", { class: "ghost small", type: "button" }, label);
  button.addEventListener("click", () => void copy(typeof value === "function" ? value() : value));
  return button;
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  names(prefix = "") {
    return this.request(`/names${prefix ? `?prefix=${encodeURIComponent(prefix)}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  /**
   * Register. The response is the ONLY time the recovery codes exist — they
   * are not stored in recoverable form and can never be shown again.
   */
  register(input) {
    return api("/api/auth/register", { method: "POST", body: JSON.stringify(input) });
  },
  signIn(input) {
    return api("/api/auth/login", { method: "POST", body: JSON.stringify(input) });
  },
  startMfa() {
    return api("/api/auth/mfa/setup", { method: "POST", body: "{}" });
  },
  confirmMfa(totp) {
    return api("/api/auth/mfa/confirm", { method: "POST", body: JSON.stringify({ totp }) });
  },
  recover(input) {
    return api("/api/auth/recover", { method: "POST", body: JSON.stringify(input) });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  /**
   * Link `address` to the account — once, for good. The server issues a challenge; `sign` signs it
   * on this device (the key never leaves); the server checks the signature and links. Linking the
   * wallet the account already has is a no-op that succeeds.
   */
  async linkWallet(address, sign) {
    const challenge = await api(
      "/api/wallet/link/challenge",
      { method: "POST", body: JSON.stringify({ address }) }
    );
    if (challenge.alreadyLinked) return { linked: true, address, account: challenge.account };
    if (!challenge.message) throw new Error("the interface sent no link challenge");
    const proof = sign(challenge.message);
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address, ...proof }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const isLanding = options.current === "landing";
  const nav = el(
    "nav",
    { class: "nav", id: "site-nav", "aria-label": "All products" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const navToggle = el(
    "button",
    {
      type: "button",
      class: "nav-toggle",
      id: "nav-toggle",
      "aria-expanded": "false",
      "aria-controls": "site-nav",
      "aria-label": "Open menu"
    },
    el("span", { class: "nav-toggle-bars", "aria-hidden": "true" }),
    el("span", { class: "nav-toggle-text" }, "Menu")
  );
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      el("div", { class: "masthead-actions" }, accountSlot, navToggle)
    ),
    banner,
    nav
  );
  header.classList.add("masthead");
  if (isLanding) header.classList.add("landing");
  const setOpen = (open) => {
    header.classList.toggle("menu-open", open);
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  navToggle.addEventListener("click", () => setOpen(!header.classList.contains("menu-open")));
  nav.addEventListener("click", (event) => {
    if (event.target.closest("a")) setOpen(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && header.classList.contains("menu-open")) {
      setOpen(false);
      navToggle.focus();
    }
  });
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/lib/revenue.ts
function revenueTimingRows(revenue) {
  const rows = [];
  const wallet = revenue.treasury?.wallet ?? revenue.accounts.treasuryWallet;
  rows.push([
    "Treasury wallet",
    wallet ? el("span", {}, el("span", { class: "mono", id: "treasury-wallet" }, wallet), " ", copyButton(wallet, "Copy address")) : "not designated yet \u2014 the first valid mining claim designates it"
  ]);
  if (revenue.treasury) {
    rows.push(["Treasury share credited so far", `${obs(revenue.split.treasuryCreditedObs)} OBS \u2014 credited in the same block as each ONS fee once a treasury is designated`]);
    rows.push(["Treasury share still owed", `${obs(revenue.split.treasuryUnclaimedObs)} OBS \u2014 held as an explicit protocol obligation until a treasury wallet exists`]);
  }
  const timing = revenue.timing;
  if (!timing) {
    rows.push(["When it is paid", "this node does not report a payment schedule"]);
    return rows;
  }
  rows.push([
    `Treasury share (${pct(timing.treasuryShare.bps / 100, 0)})`,
    `${timing.treasuryShare.paid}.`
  ]);
  const nodes = timing.nodeRunnerShare;
  rows.push([
    `Node-runner share (${pct(nodes.bps / 100, 0)})`,
    `Held in the Node Runner Reward Pool and paid ${nodes.paid} \u2014 every ${duration(nodes.periodSeconds)} \u2014 to registered nodes in proportion to the score their recorded evidence earned.`
  ]);
  rows.push(["Next node-runner payout", `${when(nodes.nextSettlementAt)} \u2014 in ${duration(nodes.secondsUntilNextSettlement)}`]);
  rows.push(["Waiting in the pool", `${obs(nodes.poolBalanceObs)} OBS`]);
  rows.push([
    "Registered node runners",
    nodes.carriedWhenNoNodes ? el("span", {}, "0 ", badge("pool is carried forward", "warn"), " ", nodes.note) : `${nodes.registeredNodes} \u2014 ${nodes.note}`
  ]);
  return rows;
}

// web/src/pages/audit.ts
var client = new ObsidianClient();
var panel = el("section", { class: "card" }, spinner("asking every reachable node\u2026"));
var decPanel = el("section", { class: "card" }, spinner("reading the decentralisation report\u2026"));
layout({
  current: "audit",
  title: "Compliance audit",
  tagline: "What is absent from the protocol, read from the protocol itself.",
  children: [
    el(
      "section",
      { class: "notice" },
      el("strong", {}, "Absence is a property of code, not of a policy page. "),
      "Each row below comes from a route every node serves. A mechanism reported as `present: true` would mean the running binary still accepts it \u2014 regardless of what any document says."
    ),
    panel,
    decPanel
  ]
});
void (async () => {
  try {
    const [compliance, decentralisation, status, supply, revenue] = await Promise.all([
      client.requestSafe("/audit/compliance"),
      client.requestSafe("/audit/decentralization"),
      client.status(),
      client.supply(),
      client.requestSafe("/revenue")
    ]);
    if (!compliance) throw new Error("this node does not expose /audit/compliance");
    const rows = Object.entries(compliance).map(([key, value]) => {
      const flag = value;
      const present = typeof flag === "boolean" ? flag : Boolean(flag?.present);
      const detail = typeof flag === "boolean" ? "" : flag?.detail ?? "";
      return [
        el("span", { class: "mono" }, key),
        present ? badge("present \u2014 investigate", "bad") : badge("absent", "ok"),
        detail
      ];
    });
    panel.replaceChildren(
      el("h2", {}, "Removed mechanisms"),
      table(["Mechanism", "State", "Node detail"], rows),
      el("h3", {}, "Supply and genesis"),
      kv([
        // The node names these `totalSupplyObs` / `maxSupplyObs`: reading a
        // field that does not exist prints "undefined OBS" beside a healthy chain.
        ["Total supply", `${obs(supply.totalSupplyObs || status.supplyObs)} OBS`],
        ["Hard cap", `${obs(supply.maxSupplyObs || status.maxSupplyObs)} OBS`],
        ["Invariant", supply.invariantOk ? "supply invariant holds (recomputed by this node)" : "FAILED \u2014 investigate"],
        ["Issuance sources", supply.issuanceSources.length > 0 ? supply.issuanceSources.join(", ") : "none yet"],
        ["Genesis allocation", status.genesis ? `${status.genesis.allocationObs} OBS to ${status.genesis.allocationClaimed ? "the first valid mining claim (claimed)" : "the first valid mining claim (unclaimed)"}` : "\u2014"],
        ["Designation", "the wallet that received the genesis allocation is the on-chain treasury: the 10% ONS treasury share is routed there, user funds never are"]
      ]),
      // The treasury is read from /revenue, which returns it in full: /status masks it, and a masked
      // address cannot be looked up, which left nobody able to check where the ONS treasury share lands.
      el("h3", {}, "ONS revenue (the protocol\u2019s only revenue source)"),
      revenue ? kv(revenueTimingRows(revenue)) : kv([["Treasury wallet", el("span", { class: "mono" }, status.genesis?.treasuryWallet ?? "\u2014")]]),
      el("p", { class: "fineprint" }, `Read at ${when(status.lastBlockTimestamp)} from ${status.networkId} at height ${status.height.toLocaleString()}.`)
    );
    if (decentralisation) {
      decPanel.replaceChildren(
        el("h2", {}, "Decentralisation"),
        ...decentralisationRows(decentralisation),
        el("p", { class: "fineprint" }, "Mining distribution, node counts and validator participation are recomputed by each node from the chain it holds.")
      );
    } else {
      decPanel.replaceChildren(el("h2", {}, "Decentralisation"), el("p", { class: "muted" }, "This node does not expose the decentralisation report."));
    }
  } catch (error) {
    panel.replaceChildren(el("h2", {}, "Compliance audit"), el("p", { class: "error" }, error.message));
    toast(error.message, "error");
  }
})();
function decentralisationRows(audit) {
  const rows = [];
  const questions = Array.isArray(audit.questions) ? audit.questions : [];
  if (questions.length > 0) {
    const allNo = questions.every((entry) => String(entry.answer).toUpperCase() === "NO");
    rows.push(
      el(
        "p",
        { class: "muted" },
        `${questions.length} single-point-of-failure questions${allNo ? ", every one answered NO by this node" : ""}.`
      ),
      kv(
        questions.map((entry) => [
          String(entry.question ?? "\u2014"),
          el("span", {}, el("strong", {}, String(entry.answer ?? "\u2014")), ` \u2014 ${String(entry.evidence ?? "")}`)
        ])
      )
    );
  }
  const dependencies = Array.isArray(audit.centralisedDependencies) ? audit.centralisedDependencies : [];
  if (dependencies.length > 0) {
    rows.push(
      el("h3", {}, "Centralised dependencies"),
      el(
        "p",
        { class: "muted" },
        "Named on purpose. Each is scoped so that losing it cannot stop or corrupt consensus."
      ),
      kv(
        dependencies.map((entry) => [
          String(entry.component ?? "\u2014"),
          `${String(entry.scope ?? "\u2014")} \xB7 consensus impact: ${String(entry.consensusImpact ?? "\u2014")}`
        ])
      )
    );
  }
  const known = /* @__PURE__ */ new Set(["questions", "centralisedDependencies"]);
  const rest = Object.entries(audit).filter(([key]) => !known.has(key));
  if (rest.length > 0) {
    rows.push(
      kv(
        rest.map(([key, value]) => [
          key,
          Array.isArray(value) ? `${value.length} ${value.length === 1 ? "entry" : "entries"}` : typeof value === "object" && value !== null ? Object.entries(value).map(([k, v]) => `${k}: ${String(v)}`).join(" \xB7 ") : String(value)
        ])
      )
    );
  }
  return rows;
}
//# sourceMappingURL=audit.js.map
