/**
 * Consensus parameters — the Obsidian Protocol Specification in constant form.
 *
 * RULE (spec §75): consensus-critical configuration must be deterministic
 * across nodes. Therefore every value in this file is a compile-time constant
 * of the protocol version, NOT an operator setting. Operators configure only
 * application-level items (ports, data directory, log level, RPC bind address).
 *
 * Changing any value below requires a protocol version bump and a documented
 * consensus upgrade — it is a hard fork.
 *
 * Values are documented in /docs/consensus.md and /docs/economics.md.
 */
export declare const CONSENSUS_PARAMS: {
    /**
     * Protocol version that owns these parameters.
     *
     * 1.1.0 introduces two consensus-visible changes:
     *   - the consensus identity is named and documented as Proof of Time (PoT):
     *     the fork-choice weight is PoT Weight, the timing rule is PoT Difficulty
     *     and the participation metric is Time-Rate (see `proofOfTime` below);
     *   - qualifying platform revenue is split 40% Node Runner Reward Pool /
     *     60% treasury at the state-transition layer (see `nodeRewards` below).
     */
    readonly protocolVersion: "1.1.0";
    /**
     * PROOF OF TIME — the consensus identity of Obsidian Network.
     *
     * Obsidian does not hold a hash-puzzle race. A block is produced by the
     * validator whose slot it is, and acceptance depends on TIME, not on how much
     * computation anyone spent:
     *
     *   - the proposer for a height is scheduled deterministically from the
     *     validator set (`proposer = activeValidators[height mod n]`), so nobody
     *     competes by spending work;
     *   - a block's timestamp must exceed the median time past of its ancestors
     *     and may not run ahead of the network's time (see `block` below), so a
     *     node cannot manufacture time;
     *   - the `PoT Difficulty` raises or lowers the required *time* between
     *     blocks, measured against protocol time, and is recomputed from chain
     *     history every `difficultyWindowBlocks` blocks — it never asks anyone to
     *     hash harder;
     *   - participation itself is time-based: mining claims open on a 4-hour
     *     protocol-time schedule, six per day per wallet.
     *
     * Cryptographic hashing still happens everywhere (block ids, Merkle roots,
     * state roots, signatures). Computation is not the consensus mechanism: time
     * is. That distinction is the whole point of PoT, and it is documented in
     * /docs/proof-of-time.md.
     */
    readonly proofOfTime: {
        /** Machine-readable consensus identity, reported by every node. */
        readonly consensus: "PROOF_OF_TIME";
        /** Short name used in APIs and the interface. */
        readonly shortName: "PoT";
        /**
         * Fork-choice weight rule. PoT Weight replaces PoW "work": a block's weight
         * is 1 + its transaction count — a measure of how much verified state the
         * block carries into the chain, not of spent computation.
         */
        readonly weightRule: "POT_WEIGHT_THEN_TIME_THEN_LOWEST_HEADER_HASH";
        /** Blocks of history used to recompute PoT Difficulty. */
        readonly difficultyWindowBlocks: 720;
        /** Target spacing in seconds that PoT Difficulty aims to hold. */
        readonly difficultyTargetSeconds: 5;
        /**
         * PoT Difficulty bounds, in basis points of the *time* target
         * (2_500 = 25% of the target spacing, 40_000 = 400%).
         */
        readonly minDifficultyBps: 2500;
        readonly maxDifficultyBps: 40000;
        /**
         * PoT Difficulty is published as an integer in thousandths of a second:
         * the minimum number of milliseconds that must separate two consecutive
         * block timestamps at the current difficulty.
         */
        readonly minBlockSpacingMs: 200;
        /** Time-Rate measurement window, seconds (one day). */
        readonly timeRateWindowSeconds: number;
        /**
         * Time-Rate is the protocol's participation metric: verified blocks and
         * verified transactions per minute of protocol time, across the window.
         * It is what an explorer shows where a PoW chain shows hashrate.
         */
        readonly timeRateUnit: "BLOCKS_AND_TXS_PER_MINUTE";
    };
    /**
     * Qualifying platform revenue is split at the moment it is received, inside
     * the state transition, by every node — not by a website, a worker or a
     * spreadsheet:
     *
     *     qualifying platform revenue
     *        ├── 40%  →  Node Runner Reward Pool
     *        └── 60%  →  protocol treasury wallet (genesis-designated)
     *
     * The split is exact integer arithmetic: `nodePool = floor(amount * 4000 /
     * 10_000)` and `treasury = amount - nodePool`, so the two always sum back to
     * the amount with no rounding leak in either direction.
     *
     * Gas is NOT platform revenue: gas goes to the Mining Pool (see `gas`), and
     * user-to-user transfers, mining rewards, creator earnings, marketplace
     * proceeds and escrowed funds are never platform revenue either. The
     * classification is enumerated in /docs/economics.md and enforced in
     * src/economy/revenue.ts.
     */
    readonly nodeRewards: {
        /** 40% of qualifying platform revenue goes to node runners. */
        readonly nodePoolShareBps: 4000;
        /** 60% goes to the protocol treasury wallet. */
        readonly treasuryShareBps: 6000;
        /** Reward period length in seconds (one day of protocol time). */
        readonly periodSeconds: number;
        /**
         * Minimum verified uptime (basis points) for a node to be eligible in a
         * period. Below this the node is scored but receives nothing.
         */
        readonly minUptimeBps: 5000;
        /** Minimum total score (basis points) required to receive a share. */
        readonly minScoreBps: 1000;
        /**
         * Attestations needed before a node's liveness is considered independently
         * verified, when enough peers exist. With n registered nodes the protocol
         * requires `min(minAttesters, n - 1)` distinct attesters: a two-node
         * network can verify each other, a single-node network cannot.
         */
        readonly minAttesters: 2;
        /** Uptime component of a single-node network, per mille of the peerless case. */
        readonly bootstrapUptimeBps: 5000;
        /** Maximum subjects one node may attest in one period. */
        readonly maxAttestationsPerAttester: 64;
        /** Heartbeats accepted per node per period. */
        readonly heartbeatsPerPeriod: 1;
        /** Fault reports accepted per reporter per period. */
        readonly maxFaultReportsPerReporterPerPeriod: 8;
        /** Score weight of one corroborated fault report, basis points. */
        readonly faultPenaltyBps: 2000;
        /** Maximum block lag still counted as "responsive" in an attestation. */
        readonly responsiveHeightLag: 12;
        /**
         * Score composition (basis points, must sum to 10_000). Every component is
         * computed by each node from chain data; no operator ever reports a number.
         */
        readonly scoreWeights: {
            readonly uptimeBps: 4000;
            readonly participationBps: 2500;
            readonly reliabilityBps: 2000;
            readonly responsivenessBps: 1500;
        };
        /** Within participation: produced blocks vs. attested peer coverage. */
        readonly participationWeights: {
            readonly blocksBps: 6000;
            readonly coverageBps: 4000;
        };
        /** Ceiling on what one node may take from a period's pool (5%). */
        readonly maxNodeShareBps: 500;
        /** Reward-wallet changes take effect after this many periods. */
        readonly walletChangeDelayPeriods: 1;
        /** Evidence kept per node, in periods (older periods are archived). */
        readonly evidenceWindowPeriods: 3;
        /** Minimum registration age, in blocks, before a node can earn. */
        readonly minRegistrationBlocks: 1;
        /**
         * Maximum validity of a signed node statement (registration, deregistration),
         * in seconds of protocol time. Short windows mean a captured statement is
         * useless by the time an attacker can mine it into a block.
         */
        readonly proofMaxValiditySeconds: 3600;
        /**
         * Registration bond, in OBS, locked from the reward wallet when a node
         * registers. It is the operator's own money, it is returned in full when the
         * node deregisters (minus nothing), and it exists so that a Sybil farm must
         * fund every node it creates. Set to 100 OBS: enough to make a farm
         * expensive, small enough that a hobbyist operator can run a node.
         */
        readonly registrationBond: bigint;
        /** Endpoint hint length limits (informational field, never an identity). */
        readonly maxEndpointLength: 120;
    };
    /** Hard cap. Issuance of ANY kind is rejected if it would exceed this. */
    readonly maxSupply: bigint;
    /** One-time genesis allocation reserved for the first protocol-valid miner. */
    readonly genesisAllocation: bigint;
    /**
     * The legacy 3,000,000 OBS genesis allocation is REMOVED and MUST NOT exist.
     * This constant exists purely so the automated compliance checklist can
     * assert its value is zero. Nothing may ever read it for issuance.
     */
    readonly legacyGenesisAllocationRemoved: 0n;
    readonly mining: {
        /** Minimum seconds between two accepted claims by the same wallet. */
        readonly claimIntervalSeconds: number;
        /** Maximum accepted claims per wallet per rolling 24-hour cycle. */
        readonly maxClaimsPerCycle: 6;
        /** Length of the claim cycle in seconds. */
        readonly cycleSeconds: number;
        /** Genesis-era total daily reward across the whole network. */
        readonly initialDailyReward: bigint;
        /** Per-claim reward while the network is at genesis participation. */
        readonly initialClaimReward: bigint;
        /** Owner of a claim must have been registered at least this recent... */
        readonly activeMinerWindowSeconds: number;
        /**
         * Reward reduction: 0.5% per 100,000 active miners.
         * Implemented with exact integer arithmetic (see mining/schedule.ts).
         */
        readonly reductionBasisPointsPerStep: 50;
        readonly reductionStepMiners: 100000;
        /** Absolute floor: 0.0002 OBS per 24 hours. Never crossed. */
        readonly dailyRewardFloor: bigint;
        /**
         * Grace applied to a wallet's very first claim so a miner is never forced
         * to wait for a full interval after registering the wallet on-chain.
         */
        readonly firstClaimGraceSeconds: 0;
        /** Maximum claims accepted from one wallet inside a single block. */
        readonly maxClaimsPerBlockPerWallet: 1;
    };
    readonly gas: {
        /** 0.02% of the transferred amount, in basis points. */
        readonly basisPoints: 2;
        /** Absolute ceiling on gas per transaction: 0.01 OBS. */
        readonly maxGas: bigint;
        /** Minimum gas charged on any value-bearing transaction (anti-spam dust). */
        readonly minGas: 0n;
        /**
         * Gas destination. Protocol rule: gas is remitted to the Mining Pool.
         * The Mining Pool is protocol state, not a wallet; see treasury/pool.ts.
         */
        readonly destination: "MINING_POOL";
    };
    readonly block: {
        /** Target spacing between blocks, seconds. */
        readonly targetBlockSeconds: 5;
        /** Maximum serialized block size in bytes. */
        readonly maxBlockBytes: number;
        /** Maximum number of transactions in one block including the reward claim batch. */
        readonly maxBlockTransactions: 2000;
        /** Allowed future drift for a block timestamp relative to local node time. */
        readonly maxFutureDriftSeconds: 60;
        /** Minimum number of parents considered when computing median time past. */
        readonly medianTimePastWindow: 11;
        /** Blocks after which a transaction is considered buried (soft finality hint). */
        readonly confirmationDepthSoft: 12;
        /** Depth at which an interface may show "final" (irreversible for practical use). */
        readonly confirmationDepthHard: 64;
        /** Emission decade length used by the halving-style issuance cap. */
        readonly issuanceDecadeSeconds: number;
    };
    readonly consensus: {
        /** Slots per producer rotation (proposer = validators[height % validatorCount]). */
        readonly validatorSlotsPerRotation: 1;
        /** A validator must be bonded with at least this much OBS. */
        readonly minValidatorBond: bigint;
        /** Unbonding delay in blocks before bond funds return. */
        readonly unbondingBlocks: 20160;
        /** Missed slots tolerated in a 100-block window before jailing. */
        readonly maxMissedSlotsPerWindow: 40;
        /** Jailing period in blocks. */
        readonly jailBlocks: 10080;
        /**
         * Fork-choice rule, under Proof of Time naming:
         * greatest accumulated PoT Weight, then greatest height (the most verified
         * time in the chain), then the lowest header hash as a deterministic
         * tie-break. There is no "most work" comparison anywhere in the protocol —
         * see /docs/proof-of-time.md and src/consensus/proposer.ts.
         */
        readonly forkChoice: "POT_WEIGHT_THEN_TIME_THEN_LOWEST_HEADER_HASH";
        /** Maximum reorg depth accepted by the node's chain reorganiser. */
        readonly maxReorgDepth: 256;
    };
    readonly tx: {
        /** Replay window: a transaction is invalid if included after this many blocks. */
        readonly expiryBlocks: 240;
        /** Maximum memo length in bytes. */
        readonly maxMemoBytes: 256;
        /** Maximum signed transaction size in bytes. */
        readonly maxTxBytes: number;
        /** Maximum number of out-messages a transaction executor may enqueue. */
        readonly maxEventsPerTx: 64;
        /** Minimum transfer amount enforced by the protocol (anti-dust). */
        readonly minTransfer: 1n;
    };
    readonly ons: {
        readonly minLength: 3;
        readonly maxLength: 63;
        /** Registration fee in USD micro-units, paid in OBS at oracle price. */
        readonly registrationFeeUsd: 5000000n;
        readonly renewalFeeUsd: 5000000n;
        /** Registration grants ownership for this many seconds (1 year). */
        readonly termSeconds: number;
        /** Grace period after expiry before the name returns to the pool. */
        readonly graceSeconds: number;
        /** Protocol-reserved names that can never be registered by users. */
        readonly reserved: readonly ["obs", "www", "admin", "root", "treasury", "foundation", "blackseal", "core", "node", "genesis", "support", "api", "wallet", "explorer", "social", "capsule", "circle", "developer"];
    };
    readonly capsules: {
        /** Minimum OBS commitment. */
        readonly minCommitment: bigint;
        /** Time Travel preview price multiplier (price = 1000 * commitment). */
        readonly timeTravelMultiplier: 1000n;
        /** Preview window, in seconds. */
        readonly previewSeconds: 30;
        /** Minimum lock duration from creation, in seconds (1 hour). */
        readonly minLockSeconds: number;
        /** Maximum lock duration (100 years) — a sanity bound, not a limit on ambition. */
        readonly maxLockSeconds: number;
        /** Maximum encrypted payload size per capsule, in bytes. */
        readonly maxContentBytes: number;
        /** One Time Travel preview per capsule per account. */
        readonly maxPreviewsPerAccount: 1;
    };
    readonly circle: {
        /**
         * Every parcel is 1 square metre at the level of the protocol market:
         * "one plot or one square metre, or less, per protocol transaction".
         */
        readonly parcelSquareMetres: 1;
        /** Protocol purchase and buyback are executed one parcel per transaction. */
        readonly maxParcelsPerProtocolTx: 1;
        /**
         * GLV (Global Location Value) multiplier applied to the location's base
         * value for each protocol purchase: GLV_next = GLV * (1 + step).
         * The buyer of a purchase never retroactively benefits — see docs.
         */
        readonly protocolPurchaseMultiplierBps: 10000;
        /** Step applied to GLV after each protocol purchase, in basis points (0.25%). */
        readonly appreciationStepBps: 25;
        /** Step applied to GLV after each protocol buyback, in basis points (0.25%). */
        readonly depreciationStepBps: 25;
        /** GLV bounds in USD micro-units. */
        readonly minGlvUsd: 100000000n;
        readonly maxGlvUsd: 30000000000n;
        /** A buyback is only permitted when the protocol land reserve can fund it. */
        readonly requireReserveForBuyback: true;
    };
    readonly social: {
        /** Post body limit, bytes. */
        readonly maxPostBytes: number;
        readonly maxCommentBytes: number;
        readonly maxUsernameLength: 24;
        /** Creator monetisation eligibility thresholds. */
        readonly monetisationMinFollowers: 10000;
        readonly monetisationMinMonthlyViews: 100000;
        /** Revenue split in basis points: 70% creator, 30% Obsidian Network. */
        readonly creatorShareBps: 7000;
        readonly networkShareBps: 3000;
        /** Business page activation price in USD micro-units ($50). */
        readonly businessPagePriceUsd: 50000000n;
        /** Tip minimum (one seal). */
        readonly minTip: 1n;
        /** Feed page size ceiling enforced by the node. */
        readonly maxPageSize: 100;
    };
    readonly oracle: {
        /** Price is invalid if older than this many seconds. */
        readonly maxAgeSeconds: number;
        /** Quorum: observations required to form a median price. */
        readonly minSources: 2;
        /** Sanity bound: reject any single observation this far from local median. */
        readonly maxDeviationBps: 2500;
        /** Absolute bounds on OBS/USD price in micro-USD. */
        readonly minPriceUsdMicro: 1n;
        readonly maxPriceUsdMicro: 1000000000000n;
        /** Maximum observation age accepted from a single source, seconds. */
        readonly maxSourceAgeSeconds: number;
    };
    readonly registry: {
        /**
         * Invite-only registration is an APPLICATION policy, never consensus.
         * Each application account may invite at most this many new accounts.
         */
        readonly maxInvitesPerAccount: 5;
        /** New accounts always begin at exactly this balance. */
        readonly newAccountBalance: 0n;
        /**
         * WAC is removed. These constants exist so the compliance checklist can
         * assert the removal programmatically.
         */
        readonly wacPriceUsd: 0n;
        readonly wacEnabled: false;
        readonly miningKycRequired: false;
        readonly miningWithdrawalRequiresWac: false;
        readonly nativeExchangeEnabled: false;
    };
};
/** Convenience: reward floor per claim derived from the daily floor. */
export declare const MIN_CLAIM_REWARD: bigint;
