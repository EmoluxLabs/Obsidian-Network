// web/src/lib/ui.ts
function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) {
    if (value === void 0 || value === false) continue;
    if (key === "class") node.className = String(value);
    else if (key === "text") node.textContent = String(value);
    else if (key === "html") node.innerHTML = String(value);
    else node.setAttribute(key, String(value));
  }
  for (const child of children) {
    if (child === null || child === void 0 || child === false) continue;
    node.append(typeof child === "string" || typeof child === "number" ? String(child) : child);
  }
  return node;
}
function qs(selector, root = document) {
  const found = root.querySelector(selector);
  if (!found) throw new Error(`missing element: ${selector}`);
  return found;
}
function mount(...nodes) {
  const root = qs("#app");
  root.replaceChildren();
  root.append(...nodes.filter((node) => node !== null && node !== void 0 && node !== false).map((node) => typeof node === "number" ? String(node) : node));
}
function obs(value, decimals = 8) {
  if (value === void 0 || value === null) return "\u2014";
  const text = typeof value === "bigint" ? value.toString() : String(value).trim();
  if (text === "" || !/^-?\d+(\.\d+)?$/.test(text)) return "\u2014";
  const negative = text.startsWith("-");
  const digits = negative ? text.slice(1) : text;
  const [wholePart, givenFraction] = digits.split(".");
  let whole;
  let fraction;
  if (givenFraction === void 0) {
    const padded = digits.padStart(19, "0");
    whole = padded.slice(0, padded.length - 18);
    fraction = padded.slice(-18);
  } else {
    whole = wholePart;
    fraction = givenFraction.padEnd(18, "0").slice(0, 18);
  }
  const trimmed = fraction.slice(0, Math.max(0, decimals)).replace(/0+$/, "");
  const grouped = whole.replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${grouped}${trimmed ? `.${trimmed}` : ""}`;
}
function relativeTime(timestampSeconds) {
  if (!timestampSeconds) return "\u2014";
  const delta = Math.floor(Date.now() / 1e3) - timestampSeconds;
  if (delta < 0) return `in ${duration(-delta)}`;
  if (delta < 5) return "just now";
  return `${duration(delta)} ago`;
}
function duration(seconds) {
  if (seconds <= 0) return "now";
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds % 86400 / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  const secs = Math.floor(seconds % 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${secs}s`;
  return `${secs}s`;
}
function when(timestampSeconds) {
  if (!timestampSeconds) return "\u2014";
  return new Date(timestampSeconds * 1e3).toLocaleString();
}
function short(value, size = 10) {
  if (!value) return "\u2014";
  if (value.length <= size * 2 + 1) return value;
  return `${value.slice(0, size)}\u2026${value.slice(-6)}`;
}
var toastTimer;
function toast(message, kind = "info") {
  let host = document.getElementById("toast");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast";
    host.className = "toast-host";
    document.body.append(host);
  }
  const item = el("div", { class: `toast toast-${kind}`, role: "status" }, message);
  host.append(item);
  window.setTimeout(() => item.classList.add("toast-out"), 4200);
  window.setTimeout(() => item.remove(), 5e3);
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => host.replaceChildren(), 5200);
}
function kv(pairs) {
  return el(
    "dl",
    { class: "kv" },
    ...pairs.flatMap(([key, value]) => [el("dt", {}, key), el("dd", {}, value)])
  );
}
function badge(text, kind = "neutral") {
  return el("span", { class: `badge badge-${kind}` }, text);
}
function spinner(label = "Loading\u2026") {
  return el("div", { class: "loading" }, el("span", { class: "dot" }), label);
}
function table(headers, rows) {
  return el(
    "div",
    { class: "table-wrap" },
    el(
      "table",
      {},
      el("thead", {}, el("tr", {}, ...headers.map((header) => el("th", {}, header)))),
      el("tbody", {}, ...rows.map((row) => el("tr", {}, ...row.map((cell) => el("td", {}, cell)))))
    )
  );
}

// web/src/lib/client.ts
var ChainError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var ObsidianClient = class {
  constructor(base = "") {
    this.base = base;
  }
  async request(path, init) {
    const response = await fetch(`${this.base}/api/rpc?path=${encodeURIComponent(path)}`, {
      ...init,
      headers: { "content-type": "application/json", ...init?.headers ?? {} },
      credentials: "same-origin"
    });
    const text = await response.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      payload = { error: text };
    }
    if (!response.ok) {
      const error = payload.error ?? `request failed (${response.status})`;
      const code = payload.code;
      throw new ChainError(error, response.status, code);
    }
    return payload;
  }
  /** Same as `request`, but returns undefined instead of throwing (for optional panels). */
  async requestSafe(path) {
    try {
      return await this.request(path);
    } catch {
      return void 0;
    }
  }
  status() {
    return this.request("/status");
  }
  params() {
    return this.request("/params");
  }
  supply() {
    return this.request("/supply");
  }
  oracle() {
    return this.request("/oracle");
  }
  network() {
    return this.request("/network");
  }
  /**
   * GET /pot. A node that answers with a partial body is treated as not
   * supporting the route: half a PoT state would render as `undefined` in the
   * interface, which is exactly the kind of invented output this project
   * refuses to ship.
   */
  async proofOfTime() {
    const payload = await this.request("/pot");
    if (!payload || typeof payload.consensus !== "string" || typeof payload.shortName !== "string" || !payload.difficulty || !payload.timeRate || !payload.timeAuthority) {
      throw new ChainError("this node did not return a Proof of Time state", 502, "ERR_MALFORMED");
    }
    return payload;
  }
  nodeRegistry(limit = 100) {
    return this.request(`/nodes/registry?limit=${limit}`);
  }
  nodeRewards(limit = 10) {
    return this.request(`/nodes/rewards?limit=${limit}`);
  }
  nodeStatus(nodeId) {
    return this.request(`/nodes/status/${encodeURIComponent(nodeId)}`);
  }
  revenue() {
    return this.request("/revenue");
  }
  miningSchedule() {
    return this.request("/mining/schedule");
  }
  miningStatus(address) {
    return this.request(`/mining/status?address=${encodeURIComponent(address)}`);
  }
  miningClaims(address, limit = 25) {
    const query = new URLSearchParams({ limit: String(limit) });
    if (address) query.set("address", address);
    return this.request(`/mining/claims?${query.toString()}`);
  }
  blocks(limit = 20) {
    return this.request(`/blocks?limit=${limit}`);
  }
  block(idOrHeight) {
    return this.request(`/block/${encodeURIComponent(idOrHeight)}`);
  }
  transaction(txId) {
    return this.request(`/tx/${encodeURIComponent(txId)}`);
  }
  addressHistory(address, limit = 25) {
    return this.request(`/address/${encodeURIComponent(address)}?limit=${limit}`);
  }
  balance(address) {
    return this.request("/wallet/balance", { method: "POST", body: JSON.stringify({ address }) });
  }
  quote(address) {
    return this.request("/wallet/quote", { method: "POST", body: JSON.stringify({ address }) });
  }
  nextNonce(address) {
    return this.request(`/wallet/${encodeURIComponent(address)}/next-nonce`);
  }
  async submit(signedTx) {
    const tx = typeof signedTx === "string" ? signedTx : toHex(signedTx);
    return this.request("/tx/submit", { method: "POST", body: JSON.stringify({ tx }) });
  }
  names(prefix = "") {
    return this.request(`/names${prefix ? `?prefix=${encodeURIComponent(prefix)}` : ""}`);
  }
  name(name) {
    return this.request(`/names/${encodeURIComponent(name)}`);
  }
  landCountries() {
    return this.request("/land/countries");
  }
  landDivisions(countryCode) {
    return this.request(`/land/divisions?country=${encodeURIComponent(countryCode)}`);
  }
  landSearch(query) {
    return this.request(`/land/search?q=${encodeURIComponent(query)}`);
  }
  landParcels(options = {}) {
    const query = new URLSearchParams();
    if (options.divisionId) query.set("divisionId", options.divisionId);
    if (options.owner) query.set("owner", options.owner);
    query.set("limit", String(options.limit ?? 25));
    return this.request(`/land/parcels?${query.toString()}`);
  }
  landParcel(parcelId) {
    return this.request(`/land/parcel/${encodeURIComponent(parcelId)}`);
  }
  landQuote(divisionId) {
    return this.request(`/land/quote/${encodeURIComponent(divisionId)}`);
  }
  capsules(options = {}) {
    const query = new URLSearchParams({ limit: String(options.limit ?? 25) });
    if (options.status) query.set("status", options.status);
    if (options.owner) query.set("owner", options.owner);
    return this.request(`/capsules?${query.toString()}`);
  }
  capsule(id) {
    return this.request(`/capsules/${encodeURIComponent(id)}`);
  }
  socialFeed(limit = 25) {
    return this.request(`/social/feed?limit=${limit}`);
  }
  socialProfile(accountId) {
    return this.request(`/social/profile/${encodeURIComponent(accountId)}`);
  }
  validators() {
    return this.request("/validators");
  }
  /**
   * The interface's own node list (which nodes it is reading from and how far
   * each has synced). A missing or malformed answer is reported as an error with
   * a readable message: an empty node list and a broken one are different states,
   * and the banner must not print a `TypeError` at the user.
   */
  async nodes() {
    const response = await fetch(`${this.base}/api/nodes`);
    if (!response.ok) throw new Error(`the interface could not list its nodes (HTTP ${response.status})`);
    const payload = await response.json().catch(() => void 0);
    if (!payload || !Array.isArray(payload.nodes)) throw new Error("the interface returned an unexpected node list");
    return {
      nodes: payload.nodes,
      consensusHeight: payload.consensusHeight ?? null,
      genesisMismatch: payload.genesisMismatch === true
    };
  }
  peers() {
    return this.request("/peers");
  }
};
function toHex(bytes) {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

// web/src/lib/node-banner.ts
async function renderNodeBanner(host, client2 = new ObsidianClient()) {
  try {
    const [{ nodes, consensusHeight, genesisMismatch }, status] = await Promise.all([client2.nodes(), client2.status()]);
    const healthy = nodes.filter((node) => node.healthy).length;
    const best = nodes.find((node) => node.healthy);
    host.replaceChildren(
      el("span", { class: "node-pill" }, badge(healthy > 0 ? "LIVE" : "NO NODES", healthy > 0 ? "ok" : "bad")),
      el("span", {}, `height ${status.height.toLocaleString()}`),
      el(
        "span",
        {},
        "peers ",
        el("strong", {}, String(status.peers))
      ),
      el("span", {}, healthy > 0 ? `reading from ${short(best?.url ?? "", 22)} (${best?.latencyMs ?? 0} ms)` : "no healthy node"),
      ...consensusHeight !== null ? [el("span", {}, `network height ${consensusHeight.toLocaleString()}`)] : [],
      ...genesisMismatch ? [badge("GENESIS MISMATCH", "bad")] : []
    );
  } catch (error) {
    host.replaceChildren(badge("NODE UNREACHABLE", "bad"), el("span", {}, error.message));
  }
}

// web/src/lib/session.ts
async function api(path, init) {
  const response = await fetch(path, {
    ...init,
    credentials: "same-origin",
    headers: { "content-type": "application/json", ...init?.headers ?? {} }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error ?? `request failed (${response.status})`);
    error.code = payload.code;
    throw error;
  }
  return payload;
}
var session = {
  config() {
    return api("/api/auth/config");
  },
  me() {
    return api("/api/auth/me");
  },
  async current() {
    try {
      return (await this.me()).account;
    } catch {
      return void 0;
    }
  },
  signIn(idToken, inviteCode) {
    return api("/api/auth/google", {
      method: "POST",
      body: JSON.stringify({ idToken, inviteCode })
    });
  },
  signOut() {
    return api("/api/auth/logout", { method: "POST", body: "{}" });
  },
  invites() {
    return api("/api/auth/invites");
  },
  createInvite() {
    return api("/api/auth/invites", { method: "POST", body: "{}" });
  },
  linkWallet(address) {
    return api("/api/wallet/link", { method: "POST", body: JSON.stringify({ address }) });
  }
};

// web/src/lib/shell.ts
var SITES = [
  { id: "mine", href: "/mine/", label: "Mine", blurb: "Protocol mining" },
  { id: "wallet", href: "/wallet/", label: "Wallet", blurb: "Non-custodial keys" },
  { id: "explorer", href: "/explorer/", label: "Explorer", blurb: "Chain data" },
  { id: "ons", href: "/ons/", label: "ONS", blurb: ".obs names" },
  { id: "circle", href: "/circle/", label: "Circle", blurb: "Land registry" },
  { id: "capsule", href: "/capsule/", label: "Capsules", blurb: "Time locks" },
  { id: "social", href: "/social/", label: "Social", blurb: "OBS Social" },
  { id: "node", href: "/node/", label: "Node runners", blurb: "Rewards & registry" },
  { id: "developer", href: "/developer/", label: "Developers", blurb: "Build on OBS" },
  { id: "app", href: "/app/", label: "Account", blurb: "Invites & nodes" }
];
function layout(options) {
  const nav = el(
    "nav",
    { class: "nav" },
    ...SITES.map(
      (site) => el(
        "a",
        { href: site.href, class: site.id === options.current ? "nav-link active" : "nav-link" },
        el("span", { class: "nav-label" }, site.label),
        el("span", { class: "nav-blurb" }, site.blurb)
      )
    )
  );
  const banner = el("div", { class: "node-strip", id: "node-strip" }, el("span", { class: "muted" }, "contacting nodes\u2026"));
  const accountSlot = el("div", { class: "account-slot", id: "account-slot" });
  const header = el(
    "header",
    { class: "masthead" },
    el(
      "div",
      { class: "masthead-inner" },
      el(
        "a",
        { class: "brand", href: "/" },
        // The official OBS coin. Served from /assets so the same file backs the
        // favicon, the manifest icons and every static site shell.
        el("img", {
          class: "brand-mark",
          src: "/assets/logo.svg",
          width: "34",
          height: "34",
          alt: "",
          "aria-hidden": "true",
          decoding: "async"
        }),
        el(
          "span",
          {},
          el("strong", {}, "OBSIDIAN"),
          el("em", {}, "NETWORK")
        )
      ),
      el("div", { class: "headline" }, el("h1", {}, options.title), el("p", {}, options.tagline)),
      accountSlot
    ),
    banner,
    nav
  );
  const main = el("main", { class: "page" }, ...options.children);
  const footer = el(
    "footer",
    { class: "footer" },
    el(
      "div",
      {},
      el("p", {}, "Obsidian Network \u2014 a Proof of Time (PoT) chain with a hard cap of 21,000,000 OBS."),
      el(
        "p",
        { class: "muted" },
        "Every number on this page is read from Obsidian Core nodes. Cloudflare, this website and your browser are caches: none of them can create, move or decide."
      )
    ),
    el(
      "div",
      { class: "footer-links" },
      el("a", { href: "/developer/" }, "Node software & releases"),
      el("a", { href: "/explorer/" }, "Explorer"),
      el("a", { href: "/audit/" }, "Compliance audit"),
      el("a", { href: "/node/" }, "Node runner rewards")
    )
  );
  mount(header, main, footer);
  void renderNodeBanner(banner);
  void renderAccount(accountSlot);
}
async function renderAccount(slot) {
  const account = await session.current();
  drawAccount(slot, account);
}
function drawAccount(slot, account) {
  slot.replaceChildren();
  if (!account) {
    const link = el("a", { class: "pill-link", href: "/app/" }, "Sign in");
    slot.append(link);
    return;
  }
  const initials = (account.displayName ?? account.email).slice(0, 2).toUpperCase();
  slot.append(
    el("a", { class: "pill-link", href: "/app/", title: account.email }, el("span", { class: "avatar" }, initials), "Account"),
    el(
      "span",
      { class: "pill muted", title: `${account.invitesIssued} invites issued` },
      `${account.invitesIssued}/5 invites`
    )
  );
}

// web/src/pages/explorer.ts
var client = new ObsidianClient();
var searchBox = el("input", { id: "explorer-search", placeholder: "Block height, block id, transaction id, .obs name or parcel id", autocomplete: "off" });
var resultPanel = el("section", { class: "card", id: "explorer-result" }, el("p", { class: "muted" }, "Search a block, a transaction, an ONS name or a parcel. Balances are not available here by design."));
var blocksPanel = el("section", { class: "card", id: "blocks" }, spinner());
var statsPanel = el("section", { class: "card", id: "chain-stats" }, spinner());
var searchButton = el("button", { class: "primary", type: "button", id: "explorer-go" }, "Search");
searchButton.addEventListener("click", () => void search(searchBox.value.trim()));
searchBox.addEventListener("keydown", (event) => {
  if (event.key === "Enter") void search(searchBox.value.trim());
});
layout({
  current: "explorer",
  title: "Explorer",
  tagline: "Blocks, transactions, names, parcels and capsules straight from Obsidian Core nodes.",
  children: [
    el("section", { class: "search-bar" }, searchBox, searchButton),
    resultPanel,
    statsPanel,
    blocksPanel
  ]
});
void boot();
async function boot() {
  await Promise.all([loadChainStats(), loadBlocks()]);
  window.setInterval(() => void loadBlocks(), 15e3);
}
async function loadChainStats() {
  try {
    const [status, supply, network, audit, pot] = await Promise.all([
      client.status(),
      client.supply(),
      client.network(),
      client.requestSafe("/audit/decentralization"),
      // Optional: an older node predates /pot, and the explorer must still work
      // against it rather than failing the whole panel. A partial answer counts
      // as "unsupported" — see client.proofOfTime().
      client.proofOfTime().catch(() => void 0)
    ]);
    statsPanel.replaceChildren(
      el("h2", {}, "Chain"),
      kv([
        ["Network", `${status.networkId} \xB7 chain ${status.chainId} \xB7 ${network.network?.addressHrp ?? "obs"}1\u2026`],
        ["Height", status.height.toLocaleString()],
        ["Head block id", el("span", { class: "mono" }, short(status.headHash, 16))],
        ["Genesis id", el("span", { class: "mono" }, status.genesisId)],
        ["Params hash", el("span", { class: "mono" }, short(status.paramsHash, 16))],
        ["Protocol version", status.protocolVersion],
        ["Consensus", pot ? `${pot.consensus.replace(/_/g, " ").toLowerCase()} (${pot.shortName})` : "Proof of Time (PoT)"],
        [
          "PoT difficulty",
          pot ? pot.difficulty.warmingUp ? "warming up \u2014 fewer blocks than the measurement window" : `${(pot.difficulty.difficultyBps / 100).toFixed(2)}% of target \xB7 observed ${(pot.difficulty.observedSpacingMs / 1e3).toFixed(2)}s between blocks` : "\u2014"
        ],
        [
          "Time-Rate",
          pot && pot.timeRate.windowSeconds > 0 ? `${pot.timeRate.blocksPerMinute.toFixed(2)} blocks/min \xB7 ${pot.timeRate.transactionsPerMinute.toFixed(2)} tx/min` : "not measurable yet \u2014 fewer than two blocks in the window"
        ],
        ["Accumulated PoT weight", pot ? el("span", { class: "mono" }, pot.cumulativePotWeight) : "\u2014"],
        ["Supply", `${obs(status.supplyObs)} OBS of ${obs(status.maxSupplyObs)} OBS`],
        ["Mining pool", `${obs(supply.poolBalanceObs)} OBS`],
        ["Peers", String(status.peers)],
        ["Last block", `${relativeTime(status.lastBlockTimestamp)} (${when(status.lastBlockTimestamp)})`],
        [
          "Time authority",
          pot ? `${pot.timeAuthority.authoritative.replace(/_/g, " ").toLowerCase()} \u2014 never your browser clock` : "\u2014"
        ],
        ["Genesis allocation", status.genesis ? `${status.genesis.allocationClaimed ? "claimed" : "unclaimed"} \xB7 ${obs(status.genesis.allocationObs)} OBS` : "\u2014"]
      ]),
      ...audit ? [el("div", {}, el("h3", {}, "Decentralisation"), kv(Object.entries(audit).slice(0, 8).map(([key, value]) => [key, String(value)])))] : [],
      el("p", { class: "fineprint" }, "Every field above is recomputed by each node from the chain. Balances are deliberately absent: the explorer surface never exposes them.")
    );
  } catch (error) {
    statsPanel.replaceChildren(el("h2", {}, "Chain"), el("p", { class: "error" }, error.message));
  }
}
async function loadBlocks() {
  try {
    const { blocks } = await client.blocks(15);
    blocksPanel.replaceChildren(
      el("h2", {}, "Latest blocks"),
      table(
        ["Height", "Block id", "Transactions", "Size", "Age"],
        blocks.map((block) => [
          el("a", { class: "mono link", href: `#/block/${block.height}` }, String(block.height)),
          el("a", { class: "mono link", href: `#/block/${block.hash}` }, short(block.hash, 12)),
          String(block.txCount),
          `${block.size} B`,
          relativeTime(block.timestamp)
        ])
      )
    );
  } catch (error) {
    blocksPanel.replaceChildren(el("h2", {}, "Latest blocks"), el("p", { class: "error" }, error.message));
  }
}
async function search(term) {
  if (!term) return;
  resultPanel.replaceChildren(spinner("asking the nodes\u2026"));
  try {
    if (/^\d+$/.test(term)) return void renderBlock(await client.block(term));
    if (/\.obs$/i.test(term)) {
      const record = await client.name(term.toLowerCase());
      resultPanel.replaceChildren(
        el("h2", {}, `ONS \xB7 ${term.toLowerCase()}`),
        kv([
          ["Resolves to (wallet address)", el("span", { class: "mono" }, short(record.address, 18))],
          ["Registered at height", String(record.registeredAtHeight ?? "\u2014")],
          ["Expires at height", String(record.expiresAt ?? "\u2014")],
          ["Transfers", record.transferCount === 0 ? badge("never transferred", "neutral") : badge(`${record.transferCount} transfers`, "ok")]
        ]),
        el("p", { class: "fineprint" }, "A name maps to exactly one wallet. Transfers are blockchain state transitions, not rows in a company database.")
      );
      return;
    }
    if (/^PAR-|^par-/.test(term) || term.includes("/")) {
      const parcel = await client.landParcel(term);
      resultPanel.replaceChildren(
        el("h2", {}, `Parcel \xB7 ${term}`),
        kv(Object.entries(parcel).slice(0, 10).map(([key, value]) => [key, String(value)]))
      );
      return;
    }
    const tx = await client.transaction(term);
    resultPanel.replaceChildren(
      el("h2", {}, `Transaction ${short(term, 14)}`),
      kv([
        ["Included in block", String(tx.height ?? "mempool")],
        ["Type", String(tx.kind ?? tx.type ?? "\u2014")],
        ["Amount", tx.amount !== void 0 && tx.amount !== null ? `${obs(tx.amount)} OBS` : "\u2014"],
        ["Gas paid", tx.gas !== void 0 ? `${obs(tx.gas)} OBS` : "\u2014"],
        ["Timestamp", tx.timestamp ? `${when(Number(tx.timestamp))}` : "pending"],
        ["Sender (masked by the node)", el("span", { class: "mono" }, short(String(tx.sender ?? "\u2014"), 18))],
        ["Recipient (masked by the node)", el("span", { class: "mono" }, short(String(tx.recipient ?? "\u2014"), 18))],
        ["Confirmations", String(tx.confirmations ?? "\u2014")]
      ]),
      el("p", { class: "fineprint" }, "Addresses shown here are masked by the node before they leave it: an explorer page cannot be used to look up a wallet's holdings.")
    );
  } catch (error) {
    toast(error.message, "error");
    resultPanel.replaceChildren(el("p", { class: "error" }, error.message));
  }
}
async function renderBlock(block) {
  const txs = block.transactions;
  resultPanel.replaceChildren(
    el("h2", {}, `Block ${block.header.height}`),
    kv([
      ["Block id", el("span", { class: "mono" }, short(block.hash, 24))],
      ["Parent", el("span", { class: "mono" }, short(block.header.prevHash, 24))],
      ["Producer", el("span", { class: "mono" }, short(block.header.producer, 18))],
      ["Timestamp", `${when(block.header.timestamp)} (${relativeTime(block.header.timestamp)})`],
      ["Transactions", String(txs.length)],
      ["Size", `${block.summary.size} B`],
      ["State root", el("span", { class: "mono" }, short(block.header.stateRoot, 24))],
      ["Confirmations", String(block.confirmations)]
    ]),
    txs.length > 0 ? table(
      ["Transaction id", "Type", "Gas", "Sender (masked)"],
      txs.map((tx) => [
        el("span", { class: "mono" }, short(tx.id, 18)),
        String(tx.type),
        `${obs(tx.gas)} OBS`,
        el("span", { class: "mono" }, short(tx.sender, 14))
      ])
    ) : el("p", { class: "muted" }, "This block contains no transactions."),
    el("p", { class: "fineprint" }, "Block producers and transaction senders are masked by the node before they leave it.")
  );
}
void (async () => {
  const hash = window.location.hash.replace(/^#\/?/, "");
  if (!hash) return;
  const [kind, ...rest] = hash.split("/");
  const value = rest.join("/");
  if (kind === "block" && value) {
    searchBox.value = value;
    void search(value);
  } else if (kind === "tx" && value) {
    searchBox.value = value;
    void search(value);
  }
})();
//# sourceMappingURL=explorer.js.map
