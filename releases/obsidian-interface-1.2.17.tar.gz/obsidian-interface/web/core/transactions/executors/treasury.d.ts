/**
 * TREASURY — explicit, auditable protocol revenue flows (spec §13, §14, §70).
 *
 * Two rules define this executor:
 *
 *   1. PAY_REVENUE moves funds from the signer's OWN balance into the protocol's
 *      two revenue accounts: 40% to the Node Runner Reward Pool and 60% to the
 *      designated treasury wallet (or, before a treasury wallet exists, to the
 *      recorded unclaimed-revenue account). It can never mint, never overdraw,
 *      and never touch another user's balance.
 *
 *   2. GRANT moves funds from the treasury wallet to a recipient, and must be
 *      signed by the treasury wallet itself. It is the foundation's normal
 *      spending path: transparent, on-chain and auditable.
 *
 * User mining rewards, marketplace proceeds, creator earnings, buyer funds and
 * unrelated transfers are never routed through here — the protocol only sends
 * explicitly platform-owned revenue to the treasury.
 */
import { type TreasuryBody, type TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext } from '../types.js';
export declare function decodeTreasuryBody(body: Uint8Array): TreasuryBody;
export declare function encodeTreasuryBody(body: TreasuryBody): Uint8Array;
export declare function executeTreasury(ctx: ExecutorContext, tx: TxEnvelope): {
    gasBase: bigint;
    detail: Record<string, unknown>;
};
/**
 * GOVERNANCE transactions are reserved and always rejected in this protocol version.
 * Parameter changes require a documented protocol version upgrade because every
 * consensus parameter participates in PARAMS_HASH, which peers verify during
 * the handshake. This is deliberate: no transaction, and no administrator, can
 * silently change consensus rules at runtime.
 */
export declare function executeGovernance(tx: TxEnvelope): never;
