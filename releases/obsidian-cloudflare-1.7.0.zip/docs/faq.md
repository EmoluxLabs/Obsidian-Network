# FAQ

**Is this a real blockchain or a website that pretends to be one?**
There is no database of balances anywhere in this repository. State is derived by
applying blocks; two nodes independently reach the same state root. You can run a
node, restart it, wipe the interface entirely, and the chain is unchanged. The
tests in `obsidian-core/tests` start real chains, produce real blocks and assert
on resulting state.

**Can the website create OBS?**
No. The only issuance paths are the one-time genesis allocation (100,000 OBS to
the first valid mining claim) and mining rewards bounded by a schedule and a
21,000,000 OBS cap. Verify the invariant yourself: `curl -s localhost:8630/supply | jq`.

**What happened to the 3,000,000 OBS signup allocation?**
Removed. A running node reports `legacyGenesisAllocation.present = false` and
`signupAllocation.present = false` at `/audit/compliance`, and registration now
creates an account with **0 OBS**.

**Where did the $5 activation and WAC go?**
They no longer exist in the code. There is no second token, no activation fee and
no WAC gate on withdrawals: withdrawing mined OBS is an ordinary payment with the
ordinary gas fee, and no KYC is involved.

**Who holds my keys?**
You do, in your browser. They are generated locally, encrypted locally with your
passphrase, and never transmitted. Signing happens in the page. The interface
server has no signing endpoint and its store contains no key material.

**What if I lose my passphrase or my phrase?**
You lose the wallet. That is not a policy choice we can reverse for you — there is
no escrow, no recovery service and no admin override. It is the same property that
makes nobody able to freeze your OBS.

**How much does mining pay?**
0.001 OBS per day at launch, split into six claims of 0.000166666666666666 OBS,
reduced 0.5% per 100,000 active miners down to a floor of 0.0002 OBS/day. Not a
typo. Read `docs/mining.md`.

**Why is my mining countdown different from my clock?**
Because the protocol does not use your clock. Eligibility comes from the chain
head's timestamp. If your device clock is wrong, the display is wrong — the claim
is not.

**Do I need an account to mine, or to have a wallet?**
Wallets need only a wallet. **Mining needs an account**: since protocol 1.7.0 a mining claim is valid only with a short-lived certificate that the platform issues to a signed-in, MFA-confirmed account whose single linked wallet is the claiming wallet. Accounts also gate
invites on the interface (5 per account, enforced by the server). Signing up is a Gmail address, a password, an invite
code and then TOTP multi-factor — no third-party login, no email verification,
and no password reset. The recovery codes shown once at registration are the
only way back into an account, which is why the page insists you write them down.

**Is the explorer hiding something?**
It hides wallet balances and masks addresses on purpose, so the chain cannot be
used to look up what someone holds. Block and transaction data, mining claims and
names are all visible. See `docs/explorer.md`.

**What happens if Cloudflare (or this website) disappears?**
Nothing happens to the chain. Nodes keep producing blocks. Run the node and the
interface yourself, or read the RPC directly — the format is documented in
`docs/api.md`.

**What happens if the dollar price feed dies?**
Nothing in the protocol depends on it. ONS registration and renewal (0.05 OBS)
and the validator bond (exactly 20,000 OBS) are priced in OBS by consensus
parameters, so no fee and no state transition reads a dollar price, and an
unavailable feed cannot close a feature. A node may still publish
an OBS/USD observation for reporting (`GET /oracle`), and a consumer that asks
for it gets a stale or thin feed refused rather than replaced with a guess —
but no page and no state transition converts through it. Consensus never
consults it.

**Can Obsidian take a cut of a transfer I make?**
No. User-to-user transfers pay gas and nothing else, and gas funds the Mining
Pool. The protocol's only revenue is the ONS registration and renewal fee —
recorded on chain and split 90/10.

**Where does that revenue go?**
ONS revenue is split the moment it is received: 90% to the Node Runner Reward
Pool, 10% to the treasury wallet designated by the genesis rule. Gas is not
revenue — it funds the Mining Pool and is never treated as ONS revenue. Read
`/revenue` from any node, or see
[node-runner-rewards.md](node-runner-rewards.md).

**Is Obsidian a proof-of-work coin?**
No. It is **Proof of Time**. Nobody earns the right to produce a block by
computing more than anyone else; block production is scheduled and gated by
protocol time. The chain still uses SHA-256 and ECDSA — for block ids, state
roots and signatures — because that is how integrity and identity work, not
because computation buys authority. See [proof-of-time.md](proof-of-time.md).

**Can I earn by running a node?**
Yes: 90% of ONS revenue. You register a reward wallet (proving
you control it), stay online, stay in sync, and let other nodes attest that they
saw you. You cannot tell the protocol how well you did — there is no field for
it. See [node-runner-rewards.md](node-runner-rewards.md).

**Is there an exchange inside the product?**
No. There is no native exchange, no order book and no custody. Price discovery
happens on external markets, and the protocol only consumes a price for its own
dollar-denominated features.

**Which networks can I run?**
Mainnet (7777), testnet (7778), staging (7779) and devnet (7780). Each has its own
genesis document and id, ports and address prefix, and a node refuses to mix them.

**Is it production ready?**
Read the current [CHANGELOG](../CHANGELOG.md) entry and [LAUNCH-GUIDE.md](LAUNCH-GUIDE.md)
for what this release verifies. [security-model.md](security-model.md) states
plainly which parts are exercised by automated tests, which are only structurally
validated (the Docker recipes) and where the honest limitations are.
