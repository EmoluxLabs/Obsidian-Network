/**
 * GATE_AUTHORITY — rotate or revoke the mining gate issuer keys (protocol 1.8.0).
 *
 * The rules live in `mining/gate-authority.ts`; this executor only runs them against the world state and records
 * the result. The transaction carries no value and no gas: it is authorised by the issuers' signatures inside it,
 * not by whoever pays for block space, and pricing it would put a fee between an operator and the removal of a
 * stolen key.
 */
import type { TxEnvelope } from '../../protocol/types.js';
import type { ExecutorContext, ExecutorResult } from '../types.js';
export declare function executeGateAuthority(ctx: ExecutorContext, tx: TxEnvelope): ExecutorResult;
