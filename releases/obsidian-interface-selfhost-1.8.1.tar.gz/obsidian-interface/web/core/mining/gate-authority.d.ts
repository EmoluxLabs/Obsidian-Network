/**
 * Mining gate authority: rotating and revoking the issuer keys, in consensus (protocol 1.8.0).
 *
 * WHY THIS EXISTS
 *   Through 1.7.0 the issuer set was fixed by the genesis id. A leaked or lost issuer key could only be handled by
 *   starting a new network. A key that can open the mining gate for anyone must be removable, and an operator must
 *   be able to replace one without restarting the chain.
 *
 * THE RULE (everything the chain checks, and nothing more)
 *   An update names the epoch it creates (current + 1), the keys to add and the keys to remove, and carries
 *   approvals: compact signatures, by keys of the CURRENT active set, over one fixed message. It applies when
 *     - epoch = current epoch + 1                (an update can be applied once, and in order)
 *     - approvals come from distinct current keys and are at least a strict majority: floor(n/2) + 1
 *     - every signature is valid                 (a bad one rejects the update; it is never skipped)
 *     - every key removed is active, every key added is a valid new key that is neither active nor ever revoked
 *     - the result has between 1 and `maxIssuers` keys, and the revoked list stays within `maxRevoked`
 *   Who submits it, and with which account, decides nothing: the transaction carries no gas and its sender is only
 *   the party that signed the envelope.
 *
 * WHAT THIS DOES AND DOES NOT PROTECT
 *   - With n >= 3 keys held by separate people or machines, one stolen key cannot change the set, and the other
 *     holders can revoke it. A stolen key still mints certificates until the update is included; certificates live
 *     15 minutes, so the exposure is bounded by how fast the holders act.
 *   - With a single key (n = 1), that key IS the majority: whoever holds it can replace it. It is valid, and it is
 *     the weakest setting. Run three or more.
 *   - If a majority of keys is lost, nobody can sign an update. The chain cannot recover itself from that: the way
 *     out is a new genesis. That is a property of any threshold scheme, stated here so it is never a surprise.
 *   - An update cannot empty the set (that would close mining for ever), cannot exceed the maximum, and cannot
 *     re-admit a revoked key.
 *
 * Certificates are checked against the ACTIVE set at the block that includes the claim, so a certificate signed by a
 * key before its revocation stops working as soon as the revoking update is in the chain, wherever the claim is.
 */
import { type GateApproval, type GateAuthorityBody } from '../protocol/types.js';
export interface GateAuthorityState {
    active: readonly string[];
    revoked: readonly string[];
    epoch: number;
}
export interface GateAuthorityContext {
    networkId: string;
    chainId: number;
}
export interface GateUpdateOutcome {
    active: string[];
    revoked: string[];
    epoch: number;
    added: string[];
    removed: string[];
    approvedBy: string[];
}
/** Strict majority of `n` keys. n = 0 has no majority: a chain with no issuer cannot be updated. */
export declare function gateQuorum(n: number): number;
/**
 * Fewest gate keys a MAINNET may be created with. Operational policy, not a consensus rule (the chain accepts 1..8):
 * with one key, that key alone can replace the whole set and nothing protects it; with two, the quorum is 2 of 2, so
 * losing either key freezes all further rotation. Three is the smallest set where one key can be lost or compromised
 * and the other two can still revoke it (quorum 2 of 3).
 */
export declare const MIN_GATE_KEYS_MAINNET = 3;
/** Operator-facing warning codes for a given active key count. Pure; shared by the CLI, /gate and /readyz. */
export declare function gateWarnings(activeKeys: number): string[];
/** A lowercase compressed secp256k1 public key that is a real curve point, or a protocol rejection. */
export declare function normalizeGateKey(raw: unknown): string;
/** The exact bytes every approver signs. Lists are sorted so the same change has one message. */
export declare function gateUpdateMessage(ctx: GateAuthorityContext, epoch: number, add: readonly string[], remove: readonly string[]): Uint8Array;
/** Sign an update as one issuer. Used by operator tooling and tests; never by a node. */
export declare function approveGateUpdate(issuerPrivateKeyHex: string, issuerPublicKeyHex: string, ctx: GateAuthorityContext, epoch: number, add: readonly string[], remove: readonly string[]): GateApproval;
export declare function encodeGateAuthorityBody(body: GateAuthorityBody): Uint8Array;
export declare function decodeGateAuthorityBody(bytes: Uint8Array): GateAuthorityBody;
export interface GateUpdatePlan {
    add: string[];
    remove: string[];
    nextActive: string[];
    nextRevoked: string[];
}
/**
 * Every rule that does not need a signature. Operator tooling runs it before asking anyone to sign, so nobody signs
 * a change the chain would refuse; the verifier runs it first so a bad update costs nothing.
 */
export declare function planGateUpdate(state: GateAuthorityState, change: {
    epoch: number;
    add: readonly string[];
    remove: readonly string[];
}): GateUpdatePlan;
/**
 * Decide whether `body` is a valid update of `state`, and return the state it produces. Pure: it reads nothing but
 * its arguments, so a block executor and the mempool gate give the same answer. Cheap checks run before any
 * signature is verified, so a malformed or stale update costs almost nothing.
 */
export declare function verifyGateUpdate(state: GateAuthorityState, body: GateAuthorityBody, ctx: GateAuthorityContext): GateUpdateOutcome;
