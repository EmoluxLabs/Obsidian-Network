# Protocol assumptions and verification needed

## Repository audit
The public page https://github.com/EmoluxLabs/Obsidian-Network showed one commit and only `README.md` ("Obsidian Seal Project"). The folders named in the brief (`obsidian-core/`, `obsidian-interface/`, `validator.ts`, consensus, protocol, RPC routes, wallet code) were NOT visible, so none were inspected. Nothing below is verified against code.

## Assumptions used in the designs (all unverified)
- Validator bond is shown as 20,000 OBS because the brief says an inspected implementation used it. The UI must read it from network parameters at runtime.
- Validator states shown: eligible/unregistered, registration pending, active, unbonding, claimable. Jailed and slashed states are NOT designed until the protocol is confirmed to have them.
- Unbonding delay is shown as "read from protocol parameters"; no number is invented.
- Block height, peers, uptime, hashes, balances, fees and event logs are placeholder data.
- Node controls (start, stop, restart) assume the desktop app manages a local node process. Pause-sync and peer-disconnect controls are not shown.
- No RPC route names are used or implied.

## Needs a real source before implementation
Chain head and target height, peer list, validator state per account, bond and unbonding parameters, transaction status and fees, wallet/keystore API, supported network list.
