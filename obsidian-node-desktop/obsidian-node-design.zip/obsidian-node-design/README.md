# Obsidian Node Desktop — design package (batch 1)

DESIGN PREVIEW. All values are simulated. Nothing here connects to a node, signs a transaction or reads a blockchain.

## Preview locally
Open `index.html` in any browser (no server, no network needed). Open `index.html#splash` for the animated splash. Open `catalog.html` for thumbnails of every PNG in `screens/`.
Try: Start Node (stopped → starting → syncing → synced), Stop Node (confirmation), the network selector (switch confirmation), Validator Centre (use the "Preview state" selector, or Become a Validator → Authorize (demo)).

## Contents
- `index.html` interactive prototype with shared shell, tokens and components
- `screens/` 1440 × 1000 PNG renders of the prototype (same source, so image and HTML match)
- `screen-inventory.md`, `interaction-inventory.md`, `protocol-assumptions.md`
- `assets/images/obsidian-logo.png` the logo supplied for the Obsidian mobile project, reused here. Confirm you have rights to it.

## Not done in this batch
Only 16 of the 58 listed screens plus the design-system page are built. See `screen-inventory.md`. No ZIP-ready image exists for the rest.
