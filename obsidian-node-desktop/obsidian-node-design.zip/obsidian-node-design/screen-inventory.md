# Screen inventory (batch 1)
Built (PNG in `screens/`, state in `index.html`): 00 design system · 01 splash · 04 collapsed sidebar · 05 network selector menu · 07 main dashboard (synced) · 08 node stopped · 09 node starting · 10 synchronization · 14 stop confirmation · 19 validator overview · 22 registration review · 23 registration pending · 24 validator active · 26 unbonding review · 27 unbonding in progress · 28 claim stake · 50 network switch confirmation.
Not built: 02–03, 06, 11–13, 15–18, 20–21, 25, 29–49, 51–58 (placeholders in the sidebar list the IDs per section).
Screen 11 (fully synchronized) is the same state as 07 and is not a separate image.
