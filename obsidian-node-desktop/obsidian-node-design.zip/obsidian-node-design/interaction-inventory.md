# Interaction inventory (built controls)
| Screen | Control | Action | Confirmation | Result (preview) | Real capability required |
|---|---|---|---|---|---|
| 07/08 | Start Node | Start local node | No | stopped → starting → syncing → synced (timers) | Node process control |
| 09 | Cancel | Abort startup | No | → stopped | Node process control |
| 07 | Stop Node | Safe shutdown | Yes (14) | → stopped; does not unbond funds | Node process control |
| 07 | Restart | Restart node | No | toast only | Node process control |
| Title bar | Network selector | Switch network | Yes (50) | badge changes | Per-network data dirs and wallets |
| 19 | Become a Validator | Open review | Disabled unless node synced | opens 22 | Validator registration tx |
| 22 | Authorize (demo) | Simulated sign | Yes | pending → active after simulated delay; no tx sent | Wallet signing, tx status |
| 24 | Request Unbonding | Open review | Yes (26) | → unbonding | Unbond tx, parameters |
| 27 | Not yet claimable | Disabled | n/a | n/a | Maturity height |
| 28 | Claim Stake | Open review | Yes | → unregistered; simulated | Claim tx |
Security: no secrets are handled; Authorize is demo-only.
