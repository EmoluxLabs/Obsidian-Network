# Obsidian Network — browser extension (design preview)

Manifest V3 extension: sign up (invite code required), mine with 4-hour claim cycles, wallet send/receive, explorer search, ONS, Edge Node toggle, API page. A toolbar badge and notification tell you when a claim is ready.

## Install
- **Chrome / Edge / Brave (PC):** open `chrome://extensions`, turn on Developer mode, click Load unpacked, choose this folder.
- **Firefox (PC):** open `about:debugging#/runtime/this-firefox`, click Load Temporary Add-on, choose `manifest.json`. Temporary add-ons are removed on restart; a permanent install needs the add-on to be signed on addons.mozilla.org.
- **Phone:** Kiwi Browser (Android) can load the same unpacked folder or a ZIP. Firefox for Android needs a signed, published add-on. Chrome on Android and iOS Safari do not support this extension format. As a fallback, open `popup.html` as a page: it is fluid and fits phone screens.
- **Full tab:** Menu → OPEN IN FULL TAB.

## Demo limits (read before publishing)
- Accounts, balances, invite codes (`OBS-FOUN-D001`, `OBS-TIME-2026`, `OBS-BETA-0001`) and sign-in are all local to the browser. Sign-in does not verify the password. Replace with server-side auth and invite validation.
- The 4-hour timer uses the device clock; the server must own session times.
- Explorer, API and node figures are placeholders. Not connected to the blockchain.
- The wallet has no keys; it is not a real wallet.
- The logo is the one you supplied; confirm you have the rights before publishing.

## Files
`manifest.json`, `popup.html/css/js` (the UI), `background.js` (claim alarm, badge, notification), `icons/`.
