const X=typeof browser!=='undefined'?browser:chrome,SESS=14400000;
X.runtime.onMessage.addListener(m=>{
  if(!m||m.t!=='sync')return;
  X.alarms.clear('claim');
  if(m.mine&&m.mine+SESS<=Date.now()){X.action.setBadgeText({text:'1'});X.action.setBadgeBackgroundColor({color:'#C8A85A'})}
  else{X.action.setBadgeText({text:''});if(m.mine)X.alarms.create('claim',{when:m.mine+SESS})}
});
X.alarms.onAlarm.addListener(a=>{
  if(a.name!=='claim')return;
  X.action.setBadgeText({text:'1'});X.action.setBadgeBackgroundColor({color:'#C8A85A'});
  X.notifications.create('claim',{type:'basic',iconUrl:'icons/icon128.png',title:'Obsidian Network',message:'Your 4-hour mining claim is ready.'});
});
